import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { getProductBySlug, getRelatedProducts, getSessionUser } from "@/lib/data";
import { createClient } from "@/lib/supabase/server";
import { effectivePrice, formatBDT } from "@/lib/format";
import { isInStock } from "@/lib/product-utils";
import { publicUrl } from "@/lib/storage-url";
import { publicEnv } from "@/lib/env";
import { AddToCart } from "@/components/product/add-to-cart";
import { WishlistButton } from "@/components/product/wishlist-button";
import { ProductCard } from "@/components/product/product-card";
import { ReviewForm } from "@/components/product/review-form";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  if (!p) return {};
  const img = p.images[0];
  return {
    title: p.seo_title || p.name,
    description: p.seo_description || p.description.slice(0, 160),
    alternates: { canonical: `/products/${p.slug}` },
    openGraph: { title: p.seo_title || p.name, type: "website", images: img ? [publicUrl("product-images", img.storage_path)] : undefined },
  };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [related, user] = await Promise.all([getRelatedProducts(product.category_id, product.id), getSessionUser()]);
  const supabase = await createClient();
  const { data: reviews } = await supabase
    .from("reviews").select("id, rating, title, body, created_at").eq("product_id", product.id).eq("is_approved", true).order("created_at", { ascending: false }).limit(10);
  let wished = false;
  if (user) {
    const { data } = await supabase.from("wishlists").select("product_id").eq("user_id", user.id).eq("product_id", product.id).maybeSingle();
    wished = Boolean(data);
  }

  const price = effectivePrice(product);
  const inStock = isInStock(product);
  const firstImage = product.images[0];
  const jsonLd = {
    "@context": "https://schema.org", "@type": "Product", name: product.name, sku: product.sku,
    description: product.description || undefined,
    image: product.images.map((i) => publicUrl("product-images", i.storage_path)),
    material: product.material || undefined,
    offers: {
      "@type": "Offer", priceCurrency: "BDT", price, url: `${publicEnv.siteUrl}/products/${product.slug}`,
      availability: inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    ...(reviews && reviews.length ? { aggregateRating: { "@type": "AggregateRating", ratingValue: reviews.reduce((s, r) => s + r.rating, 0) / reviews.length, reviewCount: reviews.length } } : {}),
  };

  const specs: [string, string | null][] = [
    ["SKU", product.sku], ["Material", product.material], ["Dimensions", product.dimensions],
    ["Weight", product.weight_grams ? `${product.weight_grams} g` : null],
    ["Production time", product.production_days != null ? `${product.production_days} day${product.production_days === 1 ? "" : "s"}` : null],
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <div className="relative aspect-square overflow-hidden rounded-[var(--radius-card)] bg-champagne/40">
            {firstImage ? (
              <Image src={publicUrl("product-images", firstImage.storage_path)} alt={firstImage.alt_text || product.name} fill priority sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" />
            ) : <div className="flex h-full items-center justify-center text-ink-soft">No photo yet</div>}
          </div>
          {product.images.length > 1 && (
            <ul className="mt-3 grid grid-cols-4 gap-3">
              {product.images.slice(1, 9).map((img) => (
                <li key={img.id ?? img.storage_path} className="relative aspect-square overflow-hidden rounded-lg bg-champagne/40">
                  <Image src={publicUrl("product-images", img.storage_path)} alt={img.alt_text || product.name} fill sizes="12vw" className="object-cover" loading="lazy" />
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          {product.category && <p className="text-xs uppercase tracking-widest text-gold-deep">{product.category.name}</p>}
          <h1 className="mt-2 text-4xl leading-tight">{product.name}</h1>
          {product.is_sample && <p className="mt-2 inline-block rounded-full bg-ink px-3 py-1 text-xs text-ivory">Sample content — not a real listing</p>}
          <p className="mt-4 flex items-baseline gap-3">
            <span className="text-2xl">{formatBDT(price)}</span>
            {product.discount_price_bdt != null && <s className="text-ink-soft">{formatBDT(product.price_bdt)}</s>}
          </p>
          <p className={`mt-1 text-sm ${inStock ? "text-ok" : "text-danger"}`}>
            {inStock ? (product.track_stock ? `${product.stock_qty} in stock` : "Made to order") : "Out of stock"}
          </p>
          <div className="mt-6">
            <AddToCart
              productId={product.id} slug={product.slug} name={product.name}
              imageUrl={firstImage ? publicUrl("product-images", firstImage.storage_path) : null}
              basePrice={price} variants={product.variants} trackStock={product.track_stock} stockQty={product.stock_qty}
              isCustomizable={product.is_customizable}
            />
          </div>
          <div className="mt-4"><WishlistButton productId={product.id} initiallyWished={wished} /></div>

          {product.description && <p className="mt-8 whitespace-pre-line leading-relaxed text-ink-soft">{product.description}</p>}
          <dl className="mt-8 divide-y divide-champagne border-y border-champagne text-sm">
            {specs.filter(([, v]) => v).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 py-2"><dt className="text-ink-soft">{k}</dt><dd>{v}</dd></div>
            ))}
          </dl>
        </div>
      </div>

      {reviews && reviews.length > 0 && (
        <section className="mt-16" aria-labelledby="reviews-h">
          <h2 id="reviews-h" className="text-2xl">Customer reviews</h2>
          <ul className="mt-4 space-y-4">
            {reviews.map((r) => (
              <li key={r.id} className="card p-4">
                <p aria-label={`${r.rating} out of 5 stars`}>{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</p>
                {r.title && <p className="mt-1 font-medium">{r.title}</p>}
                {r.body && <p className="mt-1 text-sm text-ink-soft">{r.body}</p>}
              </li>
            ))}
          </ul>
        </section>
      )}

      {user && <section className="mt-10" aria-label="Write a review"><ReviewForm productId={product.id} /></section>}

      {related.length > 0 && (
        <section className="mt-16" aria-labelledby="related-h">
          <h2 id="related-h" className="mb-6 text-2xl">You may also like</h2>
          <ul className="grid grid-cols-2 gap-4 lg:grid-cols-4">{related.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}</ul>
        </section>
      )}
    </div>
  );
}
