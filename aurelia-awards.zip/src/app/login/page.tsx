import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/auth-forms";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const { next, error } = await searchParams;
  return (
    <AuthShell title="Sign in" footer={<>New here? <Link className="underline" href={`/register${next ? `?next=${encodeURIComponent(next)}` : ""}`}>Create an account</Link></>}>
      {error === "link" && <p role="alert" className="mb-4 text-sm text-danger">That link has expired or was already used. Please try again.</p>}
      <LoginForm next={next} />
    </AuthShell>
  );
}
