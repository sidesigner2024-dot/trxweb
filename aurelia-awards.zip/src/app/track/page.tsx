import type { Metadata } from "next";
import { TrackForm } from "@/components/order/track-form";

export const metadata: Metadata = { title: "Track your order", alternates: { canonical: "/track" } };

export default function TrackPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
      <h1 className="mb-6 text-4xl">Track your order</h1>
      <TrackForm />
    </div>
  );
}
