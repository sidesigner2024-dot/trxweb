"use server";
import { headers } from "next/headers";
import { createAdminClient } from "@/lib/supabase/admin";
import { isSupabaseConfigured } from "@/lib/env";
import { trackSchema } from "@/lib/validation";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export type TrackResult =
  | { ok: true; order: { number: string; status: string; placedAt: string; carrier: string | null; trackingNumber: string | null; trackingUrl: string | null; events: { status: string; at: string }[] } }
  | { ok: false; error: string };

const normalizePhone = (p: string) => p.replace(/^\+?88/, "");

/** Guest tracking: order number AND the phone used at checkout must both match. Returns status data only. */
export async function trackOrder(input: unknown): Promise<TrackResult> {
  if (!isSupabaseConfigured() || !process.env.SUPABASE_SERVICE_ROLE_KEY) return { ok: false, error: "Order tracking is not available yet." };
  const parsed = trackSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Check the details." };
  const ip = clientIp(await headers());
  if (!rateLimit(`track:${ip}`, 10, 10 * 60_000).ok) return { ok: false, error: "Too many lookups. Please try again in a few minutes." };

  const db = createAdminClient();
  const { data: order } = await db.from("orders")
    .select("id, order_number, status, created_at, customer_phone").eq("order_number", parsed.data.order_number).maybeSingle();
  const notFound: TrackResult = { ok: false, error: "No order found with those details." };
  if (!order || normalizePhone(order.customer_phone as string) !== normalizePhone(parsed.data.phone)) return notFound;

  const [{ data: events }, { data: ship }] = await Promise.all([
    db.from("order_events").select("to_status, created_at").eq("order_id", order.id).order("created_at"),
    db.from("shipments").select("carrier, tracking_number, tracking_url").eq("order_id", order.id).maybeSingle(),
  ]);
  return {
    ok: true,
    order: {
      number: order.order_number as string, status: order.status as string, placedAt: order.created_at as string,
      carrier: (ship?.carrier as string) ?? null, trackingNumber: (ship?.tracking_number as string) ?? null,
      trackingUrl: ship?.tracking_url && /^https?:\/\//.test(ship.tracking_url as string) ? (ship.tracking_url as string) : null,
      events: (events ?? []).map((e) => ({ status: e.to_status as string, at: e.created_at as string })),
    },
  };
}
