import type { MetadataRoute } from "next";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured, publicEnv } from "@/lib/env";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = publicEnv.siteUrl.replace(/\/$/, "");
  const fixed = ["", "/showroom", "/products", "/categories", "/customize", "/about", "/contact", "/faq", "/track", "/privacy", "/terms", "/returns"]
    .map((p) => ({ url: `${base}${p}` }));
  if (!isSupabaseConfigured()) return fixed;
  const supabase = await createClient();
  const [{ data: products }, { data: cats }] = await Promise.all([
    supabase.from("products").select("slug, updated_at").eq("is_active", true).limit(5000),
    supabase.from("categories").select("slug").eq("is_active", true),
  ]);
  return [
    ...fixed,
    ...(cats ?? []).map((c) => ({ url: `${base}/categories/${c.slug}` })),
    ...(products ?? []).map((p) => ({ url: `${base}/products/${p.slug}`, lastModified: p.updated_at as string })),
  ];
}
