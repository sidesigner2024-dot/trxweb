import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCategories } from "@/lib/data";
import { ProductListing } from "@/components/product/product-listing";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const cat = (await getCategories()).find((c) => c.slug === slug);
  return cat ? { title: cat.name, description: cat.description ?? undefined, alternates: { canonical: `/categories/${slug}` } } : {};
}

export default async function CategoryPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const cats = await getCategories();
  const cat = cats.find((c) => c.slug === slug);
  if (!cat && cats.length > 0) notFound();
  const sp = await searchParams;
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="text-4xl">{cat?.name ?? "Category"}</h1>
      {cat?.description && <p className="mt-2 max-w-2xl text-ink-soft">{cat.description}</p>}
      <div className="mt-8"><ProductListing params={sp} basePath={`/categories/${slug}`} fixedCategory={slug} /></div>
    </div>
  );
}
