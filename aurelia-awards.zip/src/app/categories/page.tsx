import type { Metadata } from "next";
import Link from "next/link";
import { getCategories } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/env";
import { NotConfigured } from "@/components/not-configured";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Categories", alternates: { canonical: "/categories" } };

export default async function CategoriesPage() {
  const categories = (await getCategories()).filter((c) => !c.parent_id);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-8 text-4xl">Categories</h1>
      {!isSupabaseConfigured() ? <NotConfigured what="categories" /> : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => (
            <li key={c.id}>
              <Link href={`/categories/${c.slug}`} className="card block p-6 transition-shadow hover:shadow-lg">
                <h2 className="text-2xl">{c.name}</h2>
                {c.description && <p className="mt-2 text-sm text-ink-soft">{c.description}</p>}
                <span className="mt-4 inline-block text-sm text-gold-deep">View collection →</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
