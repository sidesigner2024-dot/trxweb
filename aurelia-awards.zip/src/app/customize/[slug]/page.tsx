import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { getProductBySlug, getSessionUser } from "@/lib/data";
import { effectivePrice } from "@/lib/format";
import { publicUrl } from "@/lib/storage-url";
import { Studio } from "@/components/customize/studio";

export const metadata: Metadata = { title: "Customisation studio", robots: { index: false } };

export default async function StudioPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ variant?: string }> }) {
  const { slug } = await params;
  const { variant } = await searchParams;
  const product = await getProductBySlug(slug);
  if (!product) notFound();
  if (!product.is_customizable) redirect(`/products/${slug}`);
  const user = await getSessionUser();
  const img = product.images[0];
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <p className="text-xs uppercase tracking-widest text-gold-deep">Customisation studio</p>
      <h1 className="mb-8 mt-1 text-4xl">{product.name}</h1>
      {product.options.length === 0 && !product.allows_logo ? (
        <p className="card p-6 text-ink-soft">Personalisation options for this product have not been configured yet. Please contact us to arrange it.</p>
      ) : (
        <Studio
          product={{ id: product.id, slug: product.slug, name: product.name, imageUrl: img ? publicUrl("product-images", img.storage_path) : null, basePrice: effectivePrice(product), allowsLogo: product.allows_logo, trackStock: product.track_stock, stockQty: product.stock_qty }}
          variants={product.variants} options={product.options} initialVariant={variant} signedIn={Boolean(user)}
        />
      )}
    </div>
  );
}
