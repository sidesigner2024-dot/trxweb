import type { Metadata } from "next";
import { listProducts } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/env";
import { NotConfigured } from "@/components/not-configured";
import { ProductCard } from "@/components/product/product-card";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Customisation studio", alternates: { canonical: "/customize" } };

export default async function CustomizePage() {
  const { items } = isSupabaseConfigured() ? await listProducts({ customizable: true, limit: 24 }) : { items: [] };
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="text-4xl">Customisation studio</h1>
      <p className="mt-2 max-w-2xl text-ink-soft">Choose a piece to personalise with names, dates, messages and your logo.</p>
      <div className="mt-8">
        {!isSupabaseConfigured() ? <NotConfigured what="the studio" /> : items.length === 0 ? (
          <p className="card p-8 text-center text-ink-soft">No personalisable products are available yet.</p>
        ) : (
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">{items.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}</ul>
        )}
      </div>
    </div>
  );
}
