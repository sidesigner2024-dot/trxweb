"use server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

export async function toggleWishlist(productId: string): Promise<{ ok: true; wished: boolean } | { ok: false; needsLogin?: boolean; error?: string }> {
  const id = z.uuid().safeParse(productId);
  if (!id.success) return { ok: false, error: "Invalid product." };
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { ok: false, needsLogin: true };

  const { data: existing } = await supabase
    .from("wishlists").select("product_id").eq("user_id", auth.user.id).eq("product_id", id.data).maybeSingle();
  if (existing) {
    const { error } = await supabase.from("wishlists").delete().eq("user_id", auth.user.id).eq("product_id", id.data);
    return error ? { ok: false, error: "Could not update your wishlist." } : { ok: true, wished: false };
  }
  const { error } = await supabase.from("wishlists").insert({ user_id: auth.user.id, product_id: id.data });
  return error ? { ok: false, error: "Could not update your wishlist." } : { ok: true, wished: true };
}
