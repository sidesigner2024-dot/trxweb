"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

export type ReviewState = { ok?: boolean; error?: string } | undefined;

export async function submitReview(_: ReviewState, form: FormData): Promise<ReviewState> {
  const parsed = z.object({
    product_id: z.uuid(), rating: z.coerce.number().int().min(1).max(5),
    title: z.string().trim().max(120), body: z.string().trim().max(2000),
  }).safeParse({ product_id: form.get("product_id"), rating: form.get("rating"), title: form.get("title") ?? "", body: form.get("body") ?? "" });
  if (!parsed.success) return { error: "Choose a rating from 1 to 5." };
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { error: "Please sign in to leave a review." };
  const { error } = await supabase.from("reviews").insert({
    product_id: parsed.data.product_id, user_id: auth.user.id, rating: parsed.data.rating,
    title: parsed.data.title || null, body: parsed.data.body || null, is_approved: false,
  });
  if (error) {
    if (error.code === "23505") return { error: "You have already reviewed this product." };
    return { error: "Only customers with a delivered order of this product can review it." }; // RLS decides eligibility
  }
  revalidatePath("/products");
  return { ok: true };
}
