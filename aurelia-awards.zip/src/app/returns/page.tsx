import type { Metadata } from "next";
import { ProsePage } from "@/components/prose-page";

export const metadata: Metadata = { title: "Return and refund policy", alternates: { canonical: "/returns" } };

export default function ReturnsPage() {
  return (
    <ProsePage title="Return and refund policy" draft>
      <h2>Cancellations</h2>
      <p>Orders can be cancelled online while Pending. Once production has started, please contact us.</p>
      <h2>Damaged or incorrect items</h2>
      <p>If an item arrives damaged or does not match your approved design, contact us with your order number and photos.</p>
      <h2>Personalised items</h2>
      <p>The owner must state here whether personalised items can be returned, and the return window. This text is intentionally left for the business to decide.</p>
      <h2>Refunds</h2>
      <p>The owner must state refund timelines and methods here.</p>
    </ProsePage>
  );
}
