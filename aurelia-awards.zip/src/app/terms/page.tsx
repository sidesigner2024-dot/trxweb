import type { Metadata } from "next";
import { ProsePage } from "@/components/prose-page";

export const metadata: Metadata = { title: "Terms and conditions", alternates: { canonical: "/terms" } };

export default function TermsPage() {
  return (
    <ProsePage title="Terms and conditions" draft>
      <h2>Orders</h2>
      <p>An order is accepted when we confirm it. Prices are in Bangladeshi Taka (BDT) and are checked again when you place the order.</p>
      <h2>Personalised items</h2>
      <p>Personalised items are made from the details you provide. Please check spelling and dates carefully. The on-screen preview is a guide only.</p>
      <h2>Payment</h2>
      <p>Cash on Delivery is collected when the order is delivered.</p>
      <h2>Contact</h2>
      <p>Questions about these terms can be sent through the contact page.</p>
    </ProsePage>
  );
}
