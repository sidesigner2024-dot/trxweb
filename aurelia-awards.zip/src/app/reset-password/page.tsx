import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthShell } from "@/components/auth/auth-shell";
import { ResetForm } from "@/components/auth/auth-forms";
import { getSessionUser } from "@/lib/data";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false } };

export default async function ResetPage() {
  if (!(await getSessionUser())) redirect("/login?error=link");
  return <AuthShell title="Choose a new password"><ResetForm /></AuthShell>;
}
