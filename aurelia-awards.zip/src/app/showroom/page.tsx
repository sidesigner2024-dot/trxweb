import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/env";
import { publicUrl } from "@/lib/storage-url";
import { NotConfigured } from "@/components/not-configured";
import { ShowroomClient } from "@/components/showroom/showroom-client";
import type { DisplayType, ShowroomRoom } from "@/components/showroom/types";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Virtual showroom",
  description: "Walk through our virtual gallery and inspect trophies, crests, plaques and gifts.",
  alternates: { canonical: "/showroom" },
};

type Row = {
  id: string; slug: string; name: string; description: string | null;
  displays: {
    id: string; display_type: DisplayType; pos_x: number | string; pos_y: number | string; pos_z: number | string;
    rotation_y: number | string; scale: number | string; is_active: boolean;
    product: null | {
      id: string; slug: string; name: string; price_bdt: number | string; discount_price_bdt: number | string | null;
      stock_qty: number; track_stock: boolean; is_customizable: boolean; is_sample: boolean; material: string | null; dimensions: string | null;
      images: { storage_path: string; alt_text: string; sort_order: number }[];
      model: { storage_path: string; scale: number | string }[] | { storage_path: string; scale: number | string } | null;
    };
  }[];
};

async function loadRooms(): Promise<ShowroomRoom[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("showroom_rooms")
    .select(
      "id, slug, name, description, displays:showroom_displays(id, display_type, pos_x, pos_y, pos_z, rotation_y, scale, is_active," +
        " product:products(id, slug, name, price_bdt, discount_price_bdt, stock_qty, track_stock, is_customizable, is_sample, material, dimensions," +
        " images:product_images(storage_path, alt_text, sort_order), model:product_models(storage_path, scale)))",
    )
    .eq("is_active", true)
    .order("sort_order");
  return ((data ?? []) as unknown as Row[]).map((r) => ({
    id: r.id, slug: r.slug, name: r.name, description: r.description,
    items: r.displays.filter((d) => d.is_active && d.product).map((d) => {
      const p = d.product!;
      const img = [...p.images].sort((a, b) => a.sort_order - b.sort_order)[0];
      const model = Array.isArray(p.model) ? p.model[0] : p.model;
      return {
        id: d.id, slug: p.slug, name: p.name,
        priceBdt: Number(p.discount_price_bdt ?? p.price_bdt), listPriceBdt: p.discount_price_bdt != null ? Number(p.price_bdt) : null,
        imageUrl: img ? publicUrl("product-images", img.storage_path) : null, imageAlt: img?.alt_text || p.name,
        modelUrl: model ? publicUrl("product-models", model.storage_path) : null, modelScale: model ? Number(model.scale) : 1,
        type: d.display_type, pos: [Number(d.pos_x), Number(d.pos_y), Number(d.pos_z)] as [number, number, number],
        rotY: Number(d.rotation_y), scale: Number(d.scale),
        inStock: !p.track_stock || p.stock_qty > 0, customizable: p.is_customizable,
        material: p.material, dimensions: p.dimensions, sample: p.is_sample,
      };
    }),
  }));
}

export default async function ShowroomPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="mb-4 text-4xl">The showroom</h1>
      {!isSupabaseConfigured() ? <NotConfigured what="the showroom" /> : <ShowroomClient rooms={await loadRooms()} />}
    </div>
  );
}
