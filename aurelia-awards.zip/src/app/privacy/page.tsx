import type { Metadata } from "next";
import { ProsePage } from "@/components/prose-page";

export const metadata: Metadata = { title: "Privacy policy", alternates: { canonical: "/privacy" } };

export default function PrivacyPage() {
  return (
    <ProsePage title="Privacy policy" draft>
      <h2>What we collect</h2>
      <p>Account details (name, email, mobile), delivery addresses, order history, and files you upload for personalisation (such as a logo).</p>
      <h2>How we use it</h2>
      <ul><li>To process and deliver your orders and contact you about them.</li><li>To review and produce personalised items.</li><li>To answer your messages.</li></ul>
      <h2>Who can see it</h2>
      <p>Your orders and uploaded files are visible to you and to authorised staff. Uploaded artwork is stored privately.</p>
      <h2>Your choices</h2>
      <p>You can edit your profile and addresses in your account. To request deletion of your data, contact us.</p>
    </ProsePage>
  );
}
