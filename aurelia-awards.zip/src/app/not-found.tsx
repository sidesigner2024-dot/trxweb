import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-5xl">Page not found</h1>
      <p className="mt-4 text-ink-soft">That page does not exist or is no longer available.</p>
      <Link href="/products" className="btn btn-primary mt-8">Browse the shop</Link>
    </div>
  );
}
