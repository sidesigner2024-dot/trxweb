"use server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

export type VerifiedLine = { productId: string; variantId: string | null; available: boolean; unitPrice: number; stockLimit: number | null; name: string };

/** Looks up the current price and availability for cart lines. Display only: checkout re-prices on the server. */
export async function verifyCart(input: unknown): Promise<VerifiedLine[]> {
  const parsed = z.array(z.object({ productId: z.uuid(), variantId: z.uuid().nullable() })).max(50).safeParse(input);
  if (!parsed.success) return [];
  const supabase = await createClient();
  const ids = [...new Set(parsed.data.map((l) => l.productId))];
  const { data: products } = await supabase
    .from("products")
    .select("id, name, price_bdt, discount_price_bdt, stock_qty, track_stock, variants:product_variants(id, name, price_delta_bdt, stock_qty, is_active)")
    .in("id", ids);
  const byId = new Map((products ?? []).map((p) => [p.id as string, p]));
  return parsed.data.map((l) => {
    const p = byId.get(l.productId);
    if (!p) return { productId: l.productId, variantId: l.variantId, available: false, unitPrice: 0, stockLimit: null, name: "" };
    const base = Number(p.discount_price_bdt ?? p.price_bdt);
    const variants = (p.variants ?? []) as { id: string; price_delta_bdt: number; stock_qty: number; is_active: boolean }[];
    const v = l.variantId ? variants.find((x) => x.id === l.variantId && x.is_active) : undefined;
    const needsVariant = variants.some((x) => x.is_active);
    if (needsVariant && !v) return { productId: l.productId, variantId: l.variantId, available: false, unitPrice: 0, stockLimit: null, name: p.name as string };
    const stock = v ? v.stock_qty : (p.stock_qty as number);
    return {
      productId: l.productId, variantId: l.variantId, available: !p.track_stock || stock > 0,
      unitPrice: base + Number(v?.price_delta_bdt ?? 0), stockLimit: p.track_stock ? stock : null, name: p.name as string,
    };
  });
}
