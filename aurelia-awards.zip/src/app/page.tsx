import Image from "next/image";
import Link from "next/link";
import { getBanners, getCategories, listProducts } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/env";
import { publicUrl } from "@/lib/storage-url";
import { ProductCard } from "@/components/product/product-card";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export default async function HomePage() {
  const configured = isSupabaseConfigured();
  const [banners, categories, featured] = configured
    ? await Promise.all([getBanners(), getCategories(), listProducts({ featured: true, limit: 8 })])
    : [[], [], { items: [] }];
  const banner = banners.find((b) => b.image_path);
  return (
    <>
      <section className="relative overflow-hidden border-b border-champagne bg-champagne/30">
        {banner?.image_path && <Image src={publicUrl("banners", banner.image_path)} alt="" fill priority sizes="100vw" className="object-cover opacity-40" />}
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-deep">Awards · Crests · Memorials · Gifts</p>
          <h1 className="mt-4 max-w-3xl text-5xl leading-[1.05] sm:text-7xl">{banner?.title ?? "Step into the gallery."}</h1>
          <p className="mt-6 max-w-xl text-lg text-ink-soft">{banner?.subtitle ?? "Walk through our virtual showroom, inspect each piece, and personalise it with your own engraving, logo and message."}</p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link href="/showroom" className="btn btn-primary">Enter the showroom</Link>
            <Link href={banner?.link_url ?? "/products"} className="btn btn-ghost">Browse without 3D</Link>
          </div>
        </div>
      </section>

      {categories.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6" aria-labelledby="cats">
          <h2 id="cats" className="mb-6 text-3xl">Collections</h2>
          <ul className="flex flex-wrap gap-3">{categories.filter((c) => !c.parent_id).map((c) => (
            <li key={c.id}><Link href={`/categories/${c.slug}`} className="btn btn-ghost">{c.name}</Link></li>))}</ul>
        </section>
      )}

      {featured.items.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-8 sm:px-6" aria-labelledby="feat">
          <h2 id="feat" className="mb-6 text-3xl">Featured</h2>
          <ul className="grid grid-cols-2 gap-4 lg:grid-cols-4">{featured.items.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}</ul>
        </section>
      )}
    </>
  );
}
