import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";

export const metadata: Metadata = { title: "Audit log" };

export default async function AdminAudit() {
  const { supabase } = await requireAdminPage("admin");
  const { data } = await supabase.from("audit_logs").select("id, action, entity, entity_id, details, created_at, actor:profiles(full_name)").order("created_at", { ascending: false }).limit(200);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Audit log</h1>
      <p className="text-sm text-ink-soft">The latest 200 staff actions. Entries cannot be edited from the website.</p>
      <div className="overflow-x-auto"><table className="w-full text-left text-sm">
        <thead><tr className="border-b border-champagne text-ink-soft"><th className="py-2">When</th><th>Who</th><th>Action</th><th>Target</th><th>Details</th></tr></thead>
        <tbody>{(data ?? []).map((a) => {
          const actor = (Array.isArray(a.actor) ? a.actor[0] : a.actor) as { full_name?: string } | null;
          return <tr key={a.id as string} className="border-b border-champagne/60 align-top"><td className="whitespace-nowrap py-2">{new Date(a.created_at as string).toLocaleString("en-GB")}</td><td>{actor?.full_name || "—"}</td><td>{a.action as string}</td><td>{a.entity as string}</td><td className="max-w-xs break-words text-xs text-ink-soft">{a.details ? JSON.stringify(a.details) : ""}</td></tr>;
        })}</tbody></table></div>
    </div>
  );
}
