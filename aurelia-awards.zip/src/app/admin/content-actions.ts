"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { audit, bool, dbMessage, guardAction, num, slugify, str, type Result } from "@/lib/admin";
import { ROOM } from "@/components/showroom/types";

const uuid = z.uuid();
const orNull = (s: string) => (s === "" ? null : s);
const done = (...paths: string[]): Result => { paths.forEach((p) => revalidatePath(p)); return { ok: true }; };

/* ---------- categories ---------- */
export async function saveCategory(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  const name = str(form, "name");
  const parsed = z.object({
    id: uuid.optional(), name: z.string().min(1).max(80), slug: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Slug: lowercase letters, numbers, dashes"),
    description: z.string().max(500).nullable(), parent_id: uuid.nullable(), sort_order: z.number().int(), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, name, slug: str(form, "slug") || slugify(name), description: orNull(str(form, "description")),
    parent_id: orNull(str(form, "parent_id")), sort_order: num(form, "sort_order") ?? 0, is_active: bool(form, "is_active") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the fields." };
  const { id, ...row } = parsed.data;
  if (id && row.parent_id === id) return { error: "A category cannot be its own parent." };
  const { error } = id ? await g.ctx.supabase.from("categories").update(row).eq("id", id) : await g.ctx.supabase.from("categories").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "category.update" : "category.create", "category", id ?? null, { name: row.name });
  return done("/admin/categories", "/categories", "/products");
}
export async function deleteCategory(id: string): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid category." };
  const { error } = await g.ctx.supabase.from("categories").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "category.delete", "category", id);
  return done("/admin/categories", "/categories");
}

/* ---------- banners ---------- */
export async function saveBanner(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  const parsed = z.object({
    id: uuid.optional(), title: z.string().min(1).max(120), subtitle: z.string().max(240).nullable(),
    link_url: z.string().max(500).regex(/^(\/|https?:\/\/)/, "Link must start with / or https://").nullable(), sort_order: z.number().int(), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, title: str(form, "title"), subtitle: orNull(str(form, "subtitle")), link_url: orNull(str(form, "link_url")), sort_order: num(form, "sort_order") ?? 0, is_active: bool(form, "is_active") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the fields." };
  const { id, ...row } = parsed.data;
  const { error } = id ? await g.ctx.supabase.from("banners").update(row).eq("id", id) : await g.ctx.supabase.from("banners").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "banner.update" : "banner.create", "banner", id ?? null, { title: row.title });
  return done("/admin/banners", "/");
}
export async function deleteBanner(id: string): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid banner." };
  const { data: b } = await g.ctx.supabase.from("banners").select("image_path").eq("id", id).maybeSingle();
  const { error } = await g.ctx.supabase.from("banners").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  if (b?.image_path) await g.ctx.supabase.storage.from("banners").remove([b.image_path as string]);
  await audit(g.ctx, "banner.delete", "banner", id);
  return done("/admin/banners", "/");
}

/* ---------- coupons & shipping (admin only) ---------- */
export async function saveCoupon(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  const date = (k: string) => { const v = str(form, k); return v ? new Date(v).toISOString() : null; };
  const parsed = z.object({
    id: uuid.optional(), code: z.string().regex(/^[A-Z0-9_-]{3,32}$/, "Code: 3–32 letters, numbers, - or _"), type: z.enum(["percent", "fixed"]),
    value: z.number().positive(), min_subtotal_bdt: z.number().min(0), max_uses: z.number().int().positive().nullable(), is_active: z.boolean(),
    starts_at: z.string().nullable(), expires_at: z.string().nullable(),
  }).refine((c) => c.type !== "percent" || c.value <= 100, { message: "Percent discounts cannot exceed 100.", path: ["value"] })
    .safeParse({ id: str(form, "id") || undefined, code: str(form, "code").toUpperCase(), type: str(form, "type"), value: num(form, "value") ?? NaN,
      min_subtotal_bdt: num(form, "min_subtotal_bdt") ?? 0, max_uses: num(form, "max_uses"), is_active: bool(form, "is_active"), starts_at: date("starts_at"), expires_at: date("expires_at") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the fields." };
  const { id, ...row } = parsed.data;
  const { error } = id ? await g.ctx.supabase.from("coupons").update(row).eq("id", id) : await g.ctx.supabase.from("coupons").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "coupon.update" : "coupon.create", "coupon", id ?? null, { code: row.code });
  return done("/admin/coupons");
}
export async function deleteCoupon(id: string): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid coupon." };
  const { error } = await g.ctx.supabase.from("coupons").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "coupon.delete", "coupon", id);
  return done("/admin/coupons");
}

export async function saveShippingZone(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  const parsed = z.object({
    id: uuid.optional(), name: z.string().min(1).max(80), fee_bdt: z.number().min(0), free_over_bdt: z.number().positive().nullable(),
    districts: z.array(z.string().min(1).max(80)).max(70), is_default: z.boolean(), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, name: str(form, "name"), fee_bdt: num(form, "fee_bdt") ?? NaN, free_over_bdt: num(form, "free_over_bdt"),
    districts: str(form, "districts").split(",").map((d) => d.trim()).filter(Boolean), is_default: bool(form, "is_default"), is_active: bool(form, "is_active") });
  if (!parsed.success) return { error: "Enter a name and a delivery fee." };
  const { id, ...row } = parsed.data;
  if (row.is_default) await g.ctx.supabase.from("shipping_zones").update({ is_default: false }).eq("is_default", true);
  const { error } = id ? await g.ctx.supabase.from("shipping_zones").update(row).eq("id", id) : await g.ctx.supabase.from("shipping_zones").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "shipping.update" : "shipping.create", "shipping_zone", id ?? null, { name: row.name, fee: row.fee_bdt });
  return done("/admin/shipping");
}
export async function deleteShippingZone(id: string): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid zone." };
  const { error } = await g.ctx.supabase.from("shipping_zones").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "shipping.delete", "shipping_zone", id);
  return done("/admin/shipping");
}

/* ---------- showroom ---------- */
export async function saveRoom(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  const name = str(form, "name");
  const parsed = z.object({
    id: uuid.optional(), name: z.string().min(1).max(80), slug: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Slug: lowercase letters, numbers, dashes"),
    description: z.string().max(500).nullable(), sort_order: z.number().int(), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, name, slug: str(form, "slug") || slugify(name), description: orNull(str(form, "description")), sort_order: num(form, "sort_order") ?? 0, is_active: bool(form, "is_active") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the fields." };
  const { id, ...row } = parsed.data;
  const { error } = id ? await g.ctx.supabase.from("showroom_rooms").update(row).eq("id", id) : await g.ctx.supabase.from("showroom_rooms").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "room.update" : "room.create", "showroom_room", id ?? null, { name: row.name });
  return done("/admin/showroom", "/showroom");
}
export async function deleteRoom(id: string): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid room." };
  const { error } = await g.ctx.supabase.from("showroom_rooms").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "room.delete", "showroom_room", id);
  return done("/admin/showroom", "/showroom");
}

const maxX = ROOM.width / 2 - 0.5, maxZ = ROOM.depth / 2 - 0.5;
export async function saveDisplay(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  const parsed = z.object({
    id: uuid.optional(), room_id: uuid, product_id: uuid, display_type: z.enum(["pedestal", "cabinet", "wall", "shelf"]),
    pos_x: z.number().min(-maxX).max(maxX), pos_y: z.number().min(0).max(ROOM.height - 1), pos_z: z.number().min(-maxZ).max(maxZ),
    rotation_y: z.number().min(-7).max(7), scale: z.number().min(0.2).max(3), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, room_id: str(form, "room_id"), product_id: str(form, "product_id"), display_type: str(form, "display_type"),
    pos_x: num(form, "pos_x") ?? 0, pos_y: num(form, "pos_y") ?? 0, pos_z: num(form, "pos_z") ?? 0, rotation_y: num(form, "rotation_y") ?? 0, scale: num(form, "scale") ?? 1,
    is_active: form.has("is_active") ? bool(form, "is_active") : true });
  if (!parsed.success) return { error: `Positions must stay inside the room: X ±${maxX}, Z ±${maxZ}, height 0–${ROOM.height - 1} (metres).` };
  const { id, ...row } = parsed.data;
  const { error } = id ? await g.ctx.supabase.from("showroom_displays").update(row).eq("id", id) : await g.ctx.supabase.from("showroom_displays").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "display.update" : "display.create", "showroom_room", row.room_id, { product: row.product_id });
  return done("/admin/showroom", "/showroom");
}
export async function deleteDisplay(id: string): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid display." };
  const { error } = await g.ctx.supabase.from("showroom_displays").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "display.delete", "showroom_display", id);
  return done("/admin/showroom", "/showroom");
}

/* ---------- messages & reviews ---------- */
export async function setMessageStatus(id: string, status: "new" | "read" | "replied"): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success || !["new", "read", "replied"].includes(status)) return { error: "Invalid request." };
  const { error } = await g.ctx.supabase.from("contact_messages").update({ status }).eq("id", id);
  return error ? { error: dbMessage(error) } : done("/admin/messages", "/admin");
}
export async function setReviewApproval(id: string, approved: boolean): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid review." };
  const { error } = await g.ctx.supabase.from("reviews").update({ is_approved: approved }).eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, approved ? "review.approve" : "review.unapprove", "review", id);
  return done("/admin/reviews");
}
export async function deleteReview(id: string): Promise<Result> {
  const g = await guardAction(); if ("error" in g) return g;
  if (!uuid.safeParse(id).success) return { error: "Invalid review." };
  const { error } = await g.ctx.supabase.from("reviews").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "review.delete", "review", id);
  return done("/admin/reviews");
}

/* ---------- roles & settings (admin only) ---------- */
export async function setRole(userId: string, role: "customer" | "staff" | "admin"): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  if (!uuid.safeParse(userId).success || !["customer", "staff", "admin"].includes(role)) return { error: "Invalid request." };
  if (userId === g.ctx.userId) return { error: "You cannot change your own role. Ask another admin." };
  const { error } = await g.ctx.supabase.from("profiles").update({ role }).eq("id", userId);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "role.change", "profile", userId, { role });
  return done("/admin/customers");
}

const SETTING_KEYS = { general: ["site_name", "tagline"], contact: ["phone", "email", "whatsapp", "address"], social: ["facebook", "instagram", "youtube"], about: ["body"] } as const;
export async function saveSettings(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction("admin"); if ("error" in g) return g;
  const key = str(form, "key") as keyof typeof SETTING_KEYS;
  if (!(key in SETTING_KEYS)) return { error: "Unknown settings group." };
  const value: Record<string, string> = {};
  for (const f of SETTING_KEYS[key]) {
    const v = str(form, f).slice(0, key === "about" ? 5000 : 300);
    if (key === "social" && v && !/^https?:\/\//.test(v)) return { error: "Social links must start with https://" };
    if (f === "whatsapp" && v && !/^\+?\d{8,15}$/.test(v)) return { error: "WhatsApp number: digits only, with country code (e.g. 8801XXXXXXXXX)." };
    value[f] = v;
  }
  const { error } = await g.ctx.supabase.from("site_settings").upsert({ key, value, updated_by: g.ctx.userId }, { onConflict: "key" });
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "settings.update", "site_settings", key);
  return done("/admin/settings", "/", "/contact", "/about");
}
