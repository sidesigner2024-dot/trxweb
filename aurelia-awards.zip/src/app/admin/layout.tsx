import type { Metadata } from "next";
import Link from "next/link";
import { requireAdminPage } from "@/lib/admin";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: { default: "Admin", template: "%s | Admin" }, robots: { index: false, follow: false } };

const NAV: { href: string; label: string; adminOnly?: boolean }[] = [
  { href: "/admin", label: "Overview" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/showroom", label: "Showroom" },
  { href: "/admin/banners", label: "Banners" },
  { href: "/admin/customers", label: "Customers & staff" },
  { href: "/admin/messages", label: "Messages" },
  { href: "/admin/reviews", label: "Reviews" },
  { href: "/admin/coupons", label: "Coupons", adminOnly: true },
  { href: "/admin/shipping", label: "Shipping", adminOnly: true },
  { href: "/admin/reports", label: "Reports" },
  { href: "/admin/settings", label: "Settings", adminOnly: true },
  { href: "/admin/audit", label: "Audit log", adminOnly: true },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const ctx = await requireAdminPage("staff");
  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 md:grid-cols-[200px_1fr]">
      <nav aria-label="Admin" className="flex gap-3 overflow-x-auto text-sm md:flex-col md:gap-1">
        {NAV.filter((n) => !n.adminOnly || ctx.role === "admin").map((n) => (
          <Link key={n.href} href={n.href} className="whitespace-nowrap rounded-lg px-3 py-2 hover:bg-champagne/60">{n.label}</Link>
        ))}
        <p className="hidden px-3 pt-4 text-xs text-ink-soft md:block">Signed in as {ctx.role}</p>
      </nav>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
