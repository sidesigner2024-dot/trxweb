import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { deleteShippingZone, saveShippingZone } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Shipping" };

type Z = { id: string; name: string; districts: string[]; fee_bdt: number | string; free_over_bdt: number | string | null; is_default: boolean; is_active: boolean };

function Fields({ z }: { z?: Z }) {
  return (
    <>
      {z && <input type="hidden" name="id" value={z.id} />}
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="label">Zone name</label><input name="name" defaultValue={z?.name} className="field" required /></div>
        <div><label className="label">Delivery fee (BDT)</label><input name="fee_bdt" type="number" min="0" step="0.01" defaultValue={z ? Number(z.fee_bdt) : ""} className="field" required /></div>
        <div className="sm:col-span-2"><label className="label">Districts (comma-separated; leave empty for the default zone)</label><input name="districts" defaultValue={z?.districts.join(", ")} className="field" placeholder="Sylhet, Moulvibazar" /></div>
        <div><label className="label">Free delivery over (BDT, optional)</label><input name="free_over_bdt" type="number" min="1" defaultValue={z?.free_over_bdt ?? ""} className="field" /></div>
      </div>
      <div className="flex gap-6 text-sm">
        <label className="flex items-center gap-2"><input type="checkbox" name="is_default" defaultChecked={z?.is_default} className="size-4 accent-[#9c8355]" />Default zone (used for all other districts)</label>
        <label className="flex items-center gap-2"><input type="checkbox" name="is_active" defaultChecked={z?.is_active ?? true} className="size-4 accent-[#9c8355]" />Active</label>
      </div>
    </>
  );
}

export default async function AdminShipping() {
  const { supabase } = await requireAdminPage("admin");
  const { data } = await supabase.from("shipping_zones").select("*").order("name");
  const zones = (data ?? []) as Z[];
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Shipping zones</h1>
      {!zones.some((z) => z.is_default && z.is_active) && (
        <p role="alert" className="rounded-lg border border-danger p-3 text-sm text-danger">No active default zone: customers cannot check out until you add one. Fees are your business decision, so none are pre-filled.</p>
      )}
      <ul className="space-y-3">{zones.map((z) => (
        <li key={z.id} className="card p-4"><ActionForm action={saveShippingZone} submitLabel="Save" className="space-y-3"><Fields z={z} /></ActionForm>
          <div className="mt-2"><ActionButton danger label="Delete" confirmText={`Delete zone “${z.name}”?`} action={deleteShippingZone.bind(null, z.id)} /></div></li>))}</ul>
      <section aria-labelledby="add"><h2 id="add" className="mb-3 text-xl">Add a zone</h2><ActionForm action={saveShippingZone} submitLabel="Add zone" className="card space-y-3 p-4"><Fields /></ActionForm></section>
    </div>
  );
}
