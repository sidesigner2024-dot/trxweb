import type { Metadata } from "next";
import Image from "next/image";
import { requireAdminPage } from "@/lib/admin";
import { publicUrl } from "@/lib/storage-url";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Uploader } from "@/components/admin/uploader";
import { deleteBanner, saveBanner } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Banners" };

type B = { id: string; title: string; subtitle: string | null; image_path: string | null; link_url: string | null; sort_order: number; is_active: boolean };

function Fields({ b }: { b?: B }) {
  return (
    <>
      {b && <input type="hidden" name="id" value={b.id} />}
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="label">Title</label><input name="title" defaultValue={b?.title} className="field" required /></div>
        <div><label className="label">Subtitle</label><input name="subtitle" defaultValue={b?.subtitle ?? ""} className="field" /></div>
        <div><label className="label">Link (e.g. /products or https://…)</label><input name="link_url" defaultValue={b?.link_url ?? ""} className="field" /></div>
        <div><label className="label">Sort order</label><input name="sort_order" type="number" defaultValue={b?.sort_order ?? 0} className="field" /></div>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={b?.is_active ?? true} className="size-4 accent-[#9c8355]" />Active</label>
    </>
  );
}

export default async function AdminBanners() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("banners").select("*").order("sort_order");
  const banners = (data ?? []) as B[];
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Homepage banners</h1>
      <ul className="space-y-4">
        {banners.map((b) => (
          <li key={b.id} className="card space-y-3 p-4">
            {b.image_path && <div className="relative h-32 overflow-hidden rounded-lg bg-champagne/40"><Image src={publicUrl("banners", b.image_path)} alt={b.title} fill sizes="600px" className="object-cover" /></div>}
            <ActionForm action={saveBanner} submitLabel="Save" className="space-y-3"><Fields b={b} /></ActionForm>
            <Uploader kind="banner" targetId={b.id} accept="image/jpeg,image/png,image/webp,image/avif" label={b.image_path ? "Replace image" : "Upload image"} hint="JPG, PNG, WebP or AVIF up to 5 MB. Wide images (about 3:1) work best." />
            <ActionButton danger label="Delete banner" confirmText="Delete this banner?" action={deleteBanner.bind(null, b.id)} />
          </li>
        ))}
      </ul>
      <section aria-labelledby="add"><h2 id="add" className="mb-3 text-xl">Add a banner</h2>
        <ActionForm action={saveBanner} submitLabel="Add banner" className="card space-y-3 p-4"><Fields /></ActionForm>
        <p className="mt-2 text-xs text-ink-soft">After adding, upload its image from its card above.</p></section>
    </div>
  );
}
