import Link from "next/link";
import { requireAdminPage } from "@/lib/admin";
import { formatBDT, ORDER_STATUS_LABELS } from "@/lib/format";

const daysAgoISO = (d: number) => new Date(Date.now() - d * 86400_000).toISOString();

export default async function AdminHome() {
  const { supabase } = await requireAdminPage();
  const since = daysAgoISO(30);
  const [orders, lowStock, msgs, designs, staffNotes] = await Promise.all([
    supabase.from("orders").select("status, total_bdt, created_at").gte("created_at", since).limit(5000),
    supabase.from("products").select("id, name, sku, stock_qty").eq("track_stock", true).lte("stock_qty", 3).eq("is_active", true).order("stock_qty").limit(10),
    supabase.from("contact_messages").select("id", { count: "exact", head: true }).eq("status", "new"),
    supabase.from("custom_designs").select("id", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("notifications").select("id, title, body, link, created_at").eq("audience", "staff").order("created_at", { ascending: false }).limit(6),
  ]);
  const rows = orders.data ?? [];
  const counted = rows.filter((o) => !["cancelled", "refunded"].includes(o.status as string));
  const revenue = counted.reduce((s, o) => s + Number(o.total_bdt), 0);
  const byStatus = rows.reduce<Record<string, number>>((m, o) => { m[o.status as string] = (m[o.status as string] ?? 0) + 1; return m; }, {});
  const stat = (label: string, value: string, href?: string) => (
    <div className="card p-4"><p className="text-xs uppercase tracking-widest text-ink-soft">{label}</p><p className="mt-1 text-2xl">{href ? <Link href={href}>{value}</Link> : value}</p></div>
  );
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Overview</h1>
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Last 30 days">
        {stat("Orders (30 days)", String(rows.length), "/admin/orders")}
        {stat("Order value (30 days)", formatBDT(revenue))}
        {stat("Designs to review", String(designs.count ?? 0), "/admin/orders")}
        {stat("New messages", String(msgs.count ?? 0), "/admin/messages")}
      </section>
      <p className="text-xs text-ink-soft">Order value counts all orders except cancelled and refunded, including Cash on Delivery orders not yet paid.</p>
      <section aria-labelledby="st"><h2 id="st" className="mb-2 text-xl">Orders by status</h2>
        <ul className="flex flex-wrap gap-2 text-sm">{Object.entries(byStatus).map(([s, n]) => <li key={s} className="rounded-full bg-champagne/60 px-3 py-1">{ORDER_STATUS_LABELS[s]}: {n}</li>)}{rows.length === 0 && <li className="text-ink-soft">No orders in the last 30 days.</li>}</ul>
      </section>
      <section aria-labelledby="ls"><h2 id="ls" className="mb-2 text-xl">Low stock</h2>
        {(lowStock.data ?? []).length === 0 ? <p className="text-sm text-ink-soft">Nothing is running low.</p> : (
          <ul className="space-y-1 text-sm">{lowStock.data!.map((p) => <li key={p.id as string}><Link className="underline" href={`/admin/products/${p.id}`}>{p.name as string}</Link> ({p.sku as string}) — {p.stock_qty as number} left</li>)}</ul>
        )}
      </section>
      <section aria-labelledby="al"><h2 id="al" className="mb-2 text-xl">Alerts</h2>
        {(staffNotes.data ?? []).length === 0 ? <p className="text-sm text-ink-soft">No alerts.</p> : (
          <ul className="space-y-1 text-sm">{staffNotes.data!.map((n) => <li key={n.id as string}>{n.link ? <Link className="underline" href={n.link as string}>{n.title as string}</Link> : (n.title as string)}{n.body ? ` — ${n.body}` : ""}</li>)}</ul>
        )}
      </section>
    </div>
  );
}
