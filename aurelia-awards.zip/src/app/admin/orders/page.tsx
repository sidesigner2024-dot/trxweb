import type { Metadata } from "next";
import Link from "next/link";
import { requireAdminPage } from "@/lib/admin";
import { formatBDT, ORDER_STATUS_LABELS } from "@/lib/format";

export const metadata: Metadata = { title: "Orders" };

export default async function AdminOrders({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const { supabase } = await requireAdminPage();
  const { status = "", q = "" } = await searchParams;
  let req = supabase.from("orders").select("id, order_number, status, payment_method, payment_status, total_bdt, customer_name, customer_phone, created_at").order("created_at", { ascending: false }).limit(100);
  if (status in ORDER_STATUS_LABELS) req = req.eq("status", status);
  const term = q.replace(/[,()%*\\:"']/g, " ").trim().slice(0, 40);
  if (term) req = req.or(`order_number.ilike.%${term}%,customer_name.ilike.%${term}%,customer_phone.ilike.%${term}%`);
  const { data } = await req;
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Orders</h1>
      <form className="flex flex-wrap gap-2">
        <input name="q" defaultValue={q} placeholder="Order no., name or phone" aria-label="Search orders" className="field !w-64" />
        <select name="status" defaultValue={status} aria-label="Filter by status" className="field !w-52"><option value="">All statuses</option>{Object.entries(ORDER_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <button className="btn btn-ghost">Filter</button>
        <a className="btn btn-ghost" href="/api/admin/orders-csv">Export CSV</a>
      </form>
      <div className="overflow-x-auto"><table className="w-full text-left text-sm">
        <thead><tr className="border-b border-champagne text-ink-soft"><th className="py-2">Order</th><th>Date</th><th>Customer</th><th>Status</th><th>Payment</th><th>Total</th></tr></thead>
        <tbody>{(data ?? []).map((o) => (
          <tr key={o.id as string} className="border-b border-champagne/60">
            <td className="py-2"><Link className="underline" href={`/admin/orders/${o.id}`}>{o.order_number as string}</Link></td>
            <td>{new Date(o.created_at as string).toLocaleDateString("en-GB")}</td><td>{o.customer_name as string}<br /><span className="text-ink-soft">{o.customer_phone as string}</span></td>
            <td>{ORDER_STATUS_LABELS[o.status as string]}</td><td>{o.payment_method === "cod" ? "COD" : "Online"} · {o.payment_status as string}</td><td>{formatBDT(o.total_bdt as string)}</td>
          </tr>))}</tbody>
      </table>{(data ?? []).length === 0 && <p className="py-6 text-ink-soft">No orders match.</p>}</div>
    </div>
  );
}
