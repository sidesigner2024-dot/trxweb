"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { audit, dbMessage, guardAction, str, type Result } from "@/lib/admin";
import { describeDbError } from "@/lib/db-errors";

const STATUSES = ["pending", "confirmed", "customization_review", "production", "ready_to_ship", "shipped", "delivered", "cancelled", "refunded"] as const;

/** The database state machine is the real authority; this only forwards the request. */
export async function changeStatus(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const parsed = z.object({ order_id: z.uuid(), to: z.enum(STATUSES), note: z.string().max(1000) })
    .safeParse({ order_id: str(form, "order_id"), to: str(form, "to"), note: str(form, "note") });
  if (!parsed.success) return { error: "Choose a status." };
  const { error } = await g.ctx.supabase.rpc("set_order_status", { p_order_id: parsed.data.order_id, p_to: parsed.data.to, p_note: parsed.data.note || null });
  if (error) return { error: describeDbError(error.message) };
  revalidatePath(`/admin/orders/${parsed.data.order_id}`); revalidatePath("/admin/orders");
  return { ok: true };
}

export async function saveShipment(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const parsed = z.object({
    order_id: z.uuid(), carrier: z.string().max(80), tracking_number: z.string().max(80), note: z.string().max(500),
    tracking_url: z.string().max(500).refine((u) => u === "" || /^https?:\/\//.test(u), "Tracking link must start with http:// or https://"),
  }).safeParse({ order_id: str(form, "order_id"), carrier: str(form, "carrier"), tracking_number: str(form, "tracking_number"), tracking_url: str(form, "tracking_url"), note: str(form, "note") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the shipping details." };
  const v = parsed.data;
  const { error } = await g.ctx.supabase.from("shipments").upsert(
    { order_id: v.order_id, carrier: v.carrier || null, tracking_number: v.tracking_number || null, tracking_url: v.tracking_url || null, note: v.note || null },
    { onConflict: "order_id" });
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "shipment.update", "order", v.order_id, { carrier: v.carrier, tracking: v.tracking_number });
  revalidatePath(`/admin/orders/${v.order_id}`);
  return { ok: true };
}

export async function reviewDesign(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const parsed = z.object({ design_id: z.uuid(), order_id: z.uuid(), decision: z.enum(["approved", "revision_requested"]), note: z.string().max(1000) })
    .safeParse({ design_id: str(form, "design_id"), order_id: str(form, "order_id"), decision: str(form, "decision"), note: str(form, "note") });
  if (!parsed.success) return { error: "Choose approve or request changes." };
  if (parsed.data.decision === "revision_requested" && !parsed.data.note) return { error: "Tell the customer what to change." };
  const { error } = await g.ctx.supabase.from("custom_designs").update({ status: parsed.data.decision, admin_note: parsed.data.note || null }).eq("id", parsed.data.design_id);
  if (error) return { error: dbMessage(error) };
  const { data: order } = await g.ctx.supabase.from("orders").select("user_id, order_number").eq("id", parsed.data.order_id).maybeSingle();
  if (order) {
    await g.ctx.supabase.from("notifications").insert({
      user_id: order.user_id, audience: "user", link: `/account/orders/${parsed.data.order_id}`,
      title: parsed.data.decision === "approved" ? `Design approved for ${order.order_number}` : `Changes needed for ${order.order_number}`,
      body: parsed.data.note || null,
    }).then(() => undefined);
  }
  await audit(g.ctx, `design.${parsed.data.decision}`, "order", parsed.data.order_id, { design: parsed.data.design_id });
  revalidatePath(`/admin/orders/${parsed.data.order_id}`);
  return { ok: true };
}
