import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { requireAdminPage } from "@/lib/admin";
import { formatBDT, ORDER_STATUS_LABELS } from "@/lib/format";
import { ActionForm } from "@/components/admin/action-form";
import { changeStatus, reviewDesign, saveShipment } from "@/app/admin/orders/actions";

export const metadata: Metadata = { title: "Order" };

/** Mirrors the SQL state machine so only valid buttons are offered. The database enforces it regardless. */
const NEXT: Record<string, string[]> = {
  pending: ["confirmed", "cancelled"], confirmed: ["customization_review", "production", "cancelled"],
  customization_review: ["confirmed", "production", "cancelled"], production: ["ready_to_ship", "cancelled"],
  ready_to_ship: ["shipped", "cancelled"], shipped: ["delivered"], delivered: ["refunded"],
};

export default async function AdminOrder({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const { supabase } = await requireAdminPage();
  const { data: o } = await supabase.from("orders").select("*").eq("id", id).maybeSingle();
  if (!o) notFound();
  const [{ data: items }, { data: events }, { data: ship }, { data: pays }] = await Promise.all([
    supabase.from("order_items").select("id, product_name, variant_name, sku, quantity, unit_price_bdt, line_total_bdt, design:custom_designs(id, status, data, logo_path, admin_note)").eq("order_id", id),
    supabase.from("order_events").select("id, to_status, note, created_at").eq("order_id", id).order("created_at"),
    supabase.from("shipments").select("*").eq("order_id", id).maybeSingle(),
    supabase.from("payments").select("id, provider, amount_bdt, status, created_at").eq("order_id", id).order("created_at"),
  ]);

  // Private customer logos: short-lived signed links, created only for staff here.
  const logoLinks: Record<string, string> = {};
  for (const it of items ?? []) {
    const d = (Array.isArray(it.design) ? it.design[0] : it.design) as { logo_path: string | null } | null;
    if (d?.logo_path) {
      const { data } = await supabase.storage.from("customer-artwork").createSignedUrl(d.logo_path, 600);
      if (data?.signedUrl) logoLinks[d.logo_path] = data.signedUrl;
    }
  }
  const addr = o.shipping_address as Record<string, string>;
  const next = NEXT[o.status as string] ?? [];

  return (
    <div className="space-y-8">
      <div><h1 className="text-3xl">Order {o.order_number as string}</h1>
        <p className="text-sm text-ink-soft">{new Date(o.created_at as string).toLocaleString("en-GB")} · {o.payment_method === "cod" ? "Cash on Delivery" : "Online"} · payment {o.payment_status as string} · status <strong>{ORDER_STATUS_LABELS[o.status as string]}</strong></p></div>

      <section className="card space-y-1 p-4 text-sm"><h2 className="text-lg">Customer</h2>
        <p>{o.customer_name as string} · {o.customer_phone as string}{o.customer_email ? ` · ${o.customer_email}` : ""}</p>
        <p>{addr.recipient_name}, {addr.phone}<br />{addr.line1}{addr.line2 ? `, ${addr.line2}` : ""}, {addr.city}, {addr.district} {addr.postal_code ?? ""}</p>
        {o.notes ? <p className="text-ink-soft">Note: {o.notes as string}</p> : null}</section>

      <section aria-labelledby="its" className="space-y-3"><h2 id="its" className="text-xl">Items</h2>
        {(items ?? []).map((it) => {
          const d = (Array.isArray(it.design) ? it.design[0] : it.design) as { id: string; status: string; data: Record<string, string>; logo_path: string | null; admin_note: string | null } | null;
          return (
            <div key={it.id as string} className="card space-y-3 p-4 text-sm">
              <div className="flex justify-between gap-3"><span>{it.product_name as string}{it.variant_name ? ` — ${it.variant_name}` : ""} ({it.sku as string}) × {it.quantity as number}</span><span>{formatBDT(it.line_total_bdt as string)}</span></div>
              {d && (
                <div className="rounded-lg bg-champagne/40 p-3">
                  <p className="font-medium">Custom design · {d.status.replace("_", " ")}</p>
                  <ul className="mt-1 list-disc pl-5">{Object.entries(d.data).map(([k, v]) => <li key={k}><span className="text-ink-soft">{k}:</span> {String(v)}</li>)}</ul>
                  {d.logo_path && (logoLinks[d.logo_path] ? <p className="mt-1"><a className="underline" href={logoLinks[d.logo_path]} target="_blank" rel="noopener noreferrer">Open uploaded logo</a> <span className="text-xs text-ink-soft">(link expires in 10 minutes)</span></p> : <p className="mt-1 text-danger">Logo file could not be opened.</p>)}
                  {d.admin_note && <p className="mt-1 text-ink-soft">Note to customer: {d.admin_note}</p>}
                  <ActionForm action={reviewDesign} hideSubmit className="mt-3 space-y-2">
                    <input type="hidden" name="design_id" value={d.id} /><input type="hidden" name="order_id" value={id} />
                    <label className="sr-only" htmlFor={`n-${d.id}`}>Note to customer</label>
                    <input id={`n-${d.id}`} name="note" className="field" placeholder="Note to customer (required when asking for changes)" />
                    <div className="flex gap-2"><button name="decision" value="approved" className="btn btn-primary">Approve</button><button name="decision" value="revision_requested" className="btn btn-ghost">Request changes</button></div>
                  </ActionForm>
                </div>
              )}
            </div>
          );
        })}
        <dl className="card space-y-1 p-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatBDT(o.subtotal_bdt as string)}</dd></div>
          <div className="flex justify-between"><dt>Discount{o.coupon_code ? ` (${o.coupon_code})` : ""}</dt><dd>−{formatBDT(o.discount_bdt as string)}</dd></div>
          <div className="flex justify-between"><dt>Delivery</dt><dd>{formatBDT(o.shipping_bdt as string)}</dd></div>
          <div className="flex justify-between border-t border-champagne pt-2 font-medium"><dt>Total</dt><dd>{formatBDT(o.total_bdt as string)}</dd></div>
        </dl>
      </section>

      <section aria-labelledby="stt" className="space-y-3"><h2 id="stt" className="text-xl">Change status</h2>
        {next.length === 0 ? <p className="text-sm text-ink-soft">No further status changes are possible.</p> : (
          <ActionForm action={changeStatus} hideSubmit className="card space-y-3 p-4">
            <input type="hidden" name="order_id" value={id} />
            <label className="sr-only" htmlFor="st-note">Note</label><input id="st-note" name="note" className="field" placeholder="Optional note (kept in the order history)" />
            <div className="flex flex-wrap gap-2">{next.map((s) => <button key={s} name="to" value={s} className={`btn ${s === "cancelled" ? "btn-ghost !border-danger !text-danger" : "btn-primary"}`}>{ORDER_STATUS_LABELS[s]}</button>)}</div>
            <p className="text-xs text-ink-soft">Cancelling returns stock. Marking a COD order Delivered records the cash payment. The customer is notified in-app.</p>
          </ActionForm>
        )}
      </section>

      <section aria-labelledby="shp" className="space-y-3"><h2 id="shp" className="text-xl">Delivery &amp; tracking</h2>
        <ActionForm action={saveShipment} submitLabel="Save delivery details" className="card grid gap-3 p-4 sm:grid-cols-2">
          <input type="hidden" name="order_id" value={id} />
          <div><label className="label" htmlFor="carrier">Courier</label><input id="carrier" name="carrier" className="field" defaultValue={(ship?.carrier as string) ?? ""} /></div>
          <div><label className="label" htmlFor="tn">Tracking number</label><input id="tn" name="tracking_number" className="field" defaultValue={(ship?.tracking_number as string) ?? ""} /></div>
          <div className="sm:col-span-2"><label className="label" htmlFor="tu">Tracking link</label><input id="tu" name="tracking_url" type="url" className="field" defaultValue={(ship?.tracking_url as string) ?? ""} /></div>
          <div className="sm:col-span-2"><label className="label" htmlFor="sn">Note</label><input id="sn" name="note" className="field" defaultValue={(ship?.note as string) ?? ""} /></div>
        </ActionForm>
      </section>

      <section aria-labelledby="pay"><h2 id="pay" className="mb-2 text-xl">Payments</h2>
        {(pays ?? []).length === 0 ? <p className="text-sm text-ink-soft">No payment records yet.</p> : <ul className="text-sm">{pays!.map((p) => <li key={p.id as string}>{new Date(p.created_at as string).toLocaleString("en-GB")} — {p.provider as string}: {formatBDT(p.amount_bdt as string)} ({p.status as string})</li>)}</ul>}
      </section>
      <section aria-labelledby="hist"><h2 id="hist" className="mb-2 text-xl">Activity</h2>
        <ul className="space-y-1 text-sm">{(events ?? []).map((e) => <li key={e.id as string}>{new Date(e.created_at as string).toLocaleString("en-GB")} — {ORDER_STATUS_LABELS[e.to_status as string]}{e.note ? ` (${e.note})` : ""}</li>)}</ul></section>
    </div>
  );
}
