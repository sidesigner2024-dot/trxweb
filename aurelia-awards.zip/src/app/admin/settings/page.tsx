import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionForm } from "@/components/admin/action-form";
import { saveSettings } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Settings" };

export default async function AdminSettings() {
  const { supabase } = await requireAdminPage("admin");
  const { data } = await supabase.from("site_settings").select("key, value");
  const s = Object.fromEntries((data ?? []).map((r) => [r.key as string, r.value as Record<string, string>]));
  const f = (group: string, name: string, label: string, opts: { type?: string; ph?: string } = {}) => (
    <div><label className="label" htmlFor={`${group}-${name}`}>{label}</label><input id={`${group}-${name}`} name={name} type={opts.type ?? "text"} placeholder={opts.ph} defaultValue={s[group]?.[name] ?? ""} className="field" /></div>
  );
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Website settings</h1>
      <p className="text-sm text-ink-soft">Empty fields are simply not shown on the site. Nothing here is pre-filled with made-up business details.</p>
      <ActionForm action={saveSettings} submitLabel="Save" className="card space-y-3 p-4"><input type="hidden" name="key" value="general" /><h2 className="text-xl">General</h2>{f("general", "site_name", "Site name")}{f("general", "tagline", "Tagline")}</ActionForm>
      <ActionForm action={saveSettings} submitLabel="Save" className="card space-y-3 p-4"><input type="hidden" name="key" value="contact" /><h2 className="text-xl">Contact information</h2>{f("contact", "phone", "Phone")}{f("contact", "email", "Email", { type: "email" })}{f("contact", "whatsapp", "WhatsApp number", { ph: "8801XXXXXXXXX" })}{f("contact", "address", "Address")}</ActionForm>
      <ActionForm action={saveSettings} submitLabel="Save" className="card space-y-3 p-4"><input type="hidden" name="key" value="social" /><h2 className="text-xl">Social media</h2>{f("social", "facebook", "Facebook URL", { ph: "https://" })}{f("social", "instagram", "Instagram URL", { ph: "https://" })}{f("social", "youtube", "YouTube URL", { ph: "https://" })}</ActionForm>
      <ActionForm action={saveSettings} submitLabel="Save" className="card space-y-3 p-4"><input type="hidden" name="key" value="about" /><h2 className="text-xl">About page text</h2><label className="label" htmlFor="about-body">Your story</label><textarea id="about-body" name="body" rows={8} defaultValue={s.about?.body ?? ""} className="field" /></ActionForm>
    </div>
  );
}
