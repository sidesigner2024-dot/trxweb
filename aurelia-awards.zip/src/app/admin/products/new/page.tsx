import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ProductForm } from "@/components/admin/product-form";

export const metadata: Metadata = { title: "New product" };

export default async function NewProduct() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("categories").select("id, name").order("sort_order");
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">New product</h1>
      <p className="text-sm text-ink-soft">Save first, then add photos, a 3D model, variants and personalisation options on the next screen.</p>
      <ProductForm categories={(data ?? []) as { id: string; name: string }[]} />
    </div>
  );
}
