"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { audit, bool, dbMessage, guardAction, num, slugify, str, type Result } from "@/lib/admin";
import { productInputSchema } from "@/lib/validation";

const orNull = (s: string) => (s === "" ? null : s);

export async function saveProduct(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const id = str(form, "id");
  const name = str(form, "name");
  const parsed = productInputSchema.safeParse({
    sku: str(form, "sku"), name, slug: str(form, "slug") || slugify(name), description: str(form, "description"),
    category_id: orNull(str(form, "category_id")), subcategory_id: orNull(str(form, "subcategory_id")),
    price_bdt: num(form, "price_bdt") ?? NaN, discount_price_bdt: num(form, "discount_price_bdt"),
    material: orNull(str(form, "material")), dimensions: orNull(str(form, "dimensions")),
    weight_grams: num(form, "weight_grams"), stock_qty: num(form, "stock_qty") ?? 0, track_stock: bool(form, "track_stock"),
    production_days: num(form, "production_days"), is_customizable: bool(form, "is_customizable"), allows_logo: bool(form, "allows_logo"),
    is_featured: bool(form, "is_featured"), is_active: bool(form, "is_active"),
    seo_title: orNull(str(form, "seo_title")), seo_description: orNull(str(form, "seo_description")),
  });
  if (!parsed.success) return { error: parsed.error.issues.map((i) => `${i.path.join(".") || "form"}: ${i.message}`).slice(0, 3).join(" · ") };
  const row = { ...parsed.data, is_sample: bool(form, "is_sample") };

  if (id) {
    if (!z.uuid().safeParse(id).success) return { error: "Invalid product." };
    const { error } = await g.ctx.supabase.from("products").update(row).eq("id", id);
    if (error) return { error: dbMessage(error) };
    await audit(g.ctx, "product.update", "product", id, { sku: row.sku, price: row.price_bdt, stock: row.stock_qty });
    revalidatePath("/admin/products"); revalidatePath(`/products/${row.slug}`);
    return { ok: true };
  }
  const { data, error } = await g.ctx.supabase.from("products").insert(row).select("id").single();
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "product.create", "product", data.id as string, { sku: row.sku });
  revalidatePath("/admin/products");
  redirect(`/admin/products/${data.id}`);
}

export async function deleteProduct(id: string): Promise<Result> {
  const g = await guardAction("admin");
  if ("error" in g) return g;
  if (!z.uuid().safeParse(id).success) return { error: "Invalid product." };
  const { error } = await g.ctx.supabase.from("products").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "product.delete", "product", id);
  redirect("/admin/products");
}

export async function saveVariant(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const parsed = z.object({
    id: z.uuid().optional(), product_id: z.uuid(), name: z.string().min(1).max(120),
    price_delta_bdt: z.number().min(-1_000_000).max(1_000_000), stock_qty: z.number().int().min(0), is_active: z.boolean(),
  }).safeParse({ id: str(form, "id") || undefined, product_id: str(form, "product_id"), name: str(form, "name"),
    price_delta_bdt: num(form, "price_delta_bdt") ?? 0, stock_qty: num(form, "stock_qty") ?? 0, is_active: form.has("is_active") ? bool(form, "is_active") : true });
  if (!parsed.success) return { error: "Enter a name, a price change and a whole-number stock." };
  const { id, ...row } = parsed.data;
  const { error } = id ? await g.ctx.supabase.from("product_variants").update(row).eq("id", id) : await g.ctx.supabase.from("product_variants").insert(row);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, id ? "variant.update" : "variant.create", "product", row.product_id, { name: row.name, stock: row.stock_qty });
  revalidatePath(`/admin/products/${row.product_id}`);
  return { ok: true };
}

export async function deleteVariant(id: string, productId: string): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  if (!z.uuid().safeParse(id).success) return { error: "Invalid variant." };
  const { error } = await g.ctx.supabase.from("product_variants").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "variant.delete", "product", productId, { variant: id });
  revalidatePath(`/admin/products/${productId}`);
  return { ok: true };
}

export async function saveOption(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const type = str(form, "field_type");
  const choices = str(form, "choices").split(",").map((c) => c.trim()).filter(Boolean);
  const parsed = z.object({
    product_id: z.uuid(), field_key: z.string().regex(/^[a-z][a-z0-9_]{0,30}$/, "Key: lowercase letters, numbers, underscore"),
    label: z.string().min(1).max(80), field_type: z.enum(["text", "date", "message", "font", "color"]),
    max_length: z.number().int().min(1).max(500), is_required: z.boolean(), sort_order: z.number().int(),
  }).safeParse({ product_id: str(form, "product_id"), field_key: str(form, "field_key"), label: str(form, "label"), field_type: type,
    max_length: num(form, "max_length") ?? 60, is_required: bool(form, "is_required"), sort_order: num(form, "sort_order") ?? 0 });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the fields." };
  if ((type === "font" || type === "color") && choices.length === 0) return { error: "Font and colour fields need a comma-separated list of choices." };
  if (type === "color" && choices.some((c) => !/^#[0-9a-fA-F]{6}$/.test(c))) return { error: "Colour choices must be hex codes like #C5AA7A." };
  const { error } = await g.ctx.supabase.from("customization_options").insert({ ...parsed.data, choices: choices.length ? choices : null });
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "option.create", "product", parsed.data.product_id, { key: parsed.data.field_key });
  revalidatePath(`/admin/products/${parsed.data.product_id}`);
  return { ok: true };
}

export async function deleteOption(id: string, productId: string): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  if (!z.uuid().safeParse(id).success) return { error: "Invalid option." };
  const { error } = await g.ctx.supabase.from("customization_options").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  await audit(g.ctx, "option.delete", "product", productId, { option: id });
  revalidatePath(`/admin/products/${productId}`);
  return { ok: true };
}

export async function updateImage(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const parsed = z.object({ id: z.uuid(), product_id: z.uuid(), alt_text: z.string().max(200), sort_order: z.number().int() })
    .safeParse({ id: str(form, "id"), product_id: str(form, "product_id"), alt_text: str(form, "alt_text"), sort_order: num(form, "sort_order") ?? 0 });
  if (!parsed.success) return { error: "Alt text is limited to 200 characters." };
  const { error } = await g.ctx.supabase.from("product_images").update({ alt_text: parsed.data.alt_text, sort_order: parsed.data.sort_order }).eq("id", parsed.data.id);
  if (error) return { error: dbMessage(error) };
  revalidatePath(`/admin/products/${parsed.data.product_id}`);
  return { ok: true };
}

export async function deleteImage(id: string, productId: string): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  if (!z.uuid().safeParse(id).success) return { error: "Invalid image." };
  const { data: img } = await g.ctx.supabase.from("product_images").select("storage_path").eq("id", id).maybeSingle();
  const { error } = await g.ctx.supabase.from("product_images").delete().eq("id", id);
  if (error) return { error: dbMessage(error) };
  if (img?.storage_path) await g.ctx.supabase.storage.from("product-images").remove([img.storage_path as string]);
  await audit(g.ctx, "image.delete", "product", productId, { image: id });
  revalidatePath(`/admin/products/${productId}`);
  return { ok: true };
}

export async function deleteModel(productId: string): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  if (!z.uuid().safeParse(productId).success) return { error: "Invalid product." };
  const { data: m } = await g.ctx.supabase.from("product_models").select("storage_path").eq("product_id", productId).maybeSingle();
  const { error } = await g.ctx.supabase.from("product_models").delete().eq("product_id", productId);
  if (error) return { error: dbMessage(error) };
  if (m?.storage_path) await g.ctx.supabase.storage.from("product-models").remove([m.storage_path as string]);
  await audit(g.ctx, "model.delete", "product", productId);
  revalidatePath(`/admin/products/${productId}`);
  return { ok: true };
}

export async function updateModelScale(_: Result, form: FormData): Promise<Result> {
  const g = await guardAction();
  if ("error" in g) return g;
  const productId = str(form, "product_id");
  const scale = num(form, "scale");
  if (!z.uuid().safeParse(productId).success || scale == null || scale <= 0 || scale > 5) return { error: "Scale must be between 0 and 5." };
  const { error } = await g.ctx.supabase.from("product_models").update({ scale }).eq("product_id", productId);
  if (error) return { error: dbMessage(error) };
  revalidatePath(`/admin/products/${productId}`);
  return { ok: true };
}
