import type { Metadata } from "next";
import Link from "next/link";
import { requireAdminPage } from "@/lib/admin";
import { formatBDT } from "@/lib/format";

export const metadata: Metadata = { title: "Products" };

export default async function AdminProducts({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { supabase } = await requireAdminPage();
  const { q = "" } = await searchParams;
  const term = q.replace(/[,()%*\\:"']/g, " ").trim().slice(0, 60);
  let req = supabase.from("products").select("id, name, sku, price_bdt, stock_qty, track_stock, is_active, is_sample, category:categories!products_category_id_fkey(name)").order("created_at", { ascending: false }).limit(100);
  if (term) req = req.or(`name.ilike.%${term}%,sku.ilike.%${term}%`);
  const { data } = await req;
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-3xl">Products</h1><Link href="/admin/products/new" className="btn btn-primary">Add product</Link></div>
      <form className="flex gap-2"><input name="q" defaultValue={q} placeholder="Search name or SKU" aria-label="Search products" className="field" /><button className="btn btn-ghost">Search</button></form>
      <div className="overflow-x-auto"><table className="w-full text-left text-sm">
        <thead><tr className="border-b border-champagne text-ink-soft"><th className="py-2">Name</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead>
        <tbody>{(data ?? []).map((p) => {
          const cat = Array.isArray(p.category) ? p.category[0] : p.category;
          return (
            <tr key={p.id as string} className="border-b border-champagne/60">
              <td className="py-2"><Link className="underline" href={`/admin/products/${p.id}`}>{p.name as string}</Link>{p.is_sample ? <span className="ml-2 rounded-full bg-ink px-2 text-[11px] text-ivory">sample</span> : null}</td>
              <td>{p.sku as string}</td><td>{(cat as { name?: string } | null)?.name ?? "—"}</td><td>{formatBDT(p.price_bdt as string)}</td>
              <td>{p.track_stock ? (p.stock_qty as number) : "made to order"}</td><td>{p.is_active ? "Visible" : "Hidden"}</td>
            </tr>
          );
        })}</tbody>
      </table>{(data ?? []).length === 0 && <p className="py-6 text-ink-soft">No products found.</p>}</div>
    </div>
  );
}
