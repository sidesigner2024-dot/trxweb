import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { z } from "zod";
import { requireAdminPage } from "@/lib/admin";
import { publicUrl } from "@/lib/storage-url";
import { ProductForm } from "@/components/admin/product-form";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Uploader } from "@/components/admin/uploader";
import { deleteImage, deleteModel, deleteOption, deleteProduct, deleteVariant, saveOption, saveVariant, updateImage, updateModelScale } from "@/app/admin/products/actions";

export const metadata: Metadata = { title: "Edit product" };

export default async function EditProduct({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const { supabase, role } = await requireAdminPage();
  const { data: p } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
  if (!p) notFound();
  const [{ data: cats }, { data: images }, { data: model }, { data: variants }, { data: options }] = await Promise.all([
    supabase.from("categories").select("id, name").order("sort_order"),
    supabase.from("product_images").select("*").eq("product_id", id).order("sort_order"),
    supabase.from("product_models").select("*").eq("product_id", id).maybeSingle(),
    supabase.from("product_variants").select("*").eq("product_id", id).order("sort_order"),
    supabase.from("customization_options").select("*").eq("product_id", id).order("sort_order"),
  ]);
  const hidden = (name: string, value: string) => <input type="hidden" name={name} value={value} />;

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl">{p.name as string}</h1>
        {role === "admin" && <ActionButton danger label="Delete product" confirmText="Delete this product permanently? Past orders keep their own copy of the details. Consider hiding it instead." action={deleteProduct.bind(null, id)} />}
      </div>
      <ProductForm product={p} categories={(cats ?? []) as { id: string; name: string }[]} />

      <section aria-labelledby="img-h" className="space-y-4">
        <h2 id="img-h" className="text-2xl">Photos</h2>
        <p className="text-sm text-ink-soft">The image with the lowest sort number is the main photo. JPG, PNG, WebP or AVIF up to 5 MB.</p>
        <ul className="grid gap-4 sm:grid-cols-2">
          {(images ?? []).map((img) => (
            <li key={img.id as string} className="card flex gap-3 p-3">
              <div className="relative size-24 shrink-0 overflow-hidden rounded-lg bg-champagne/40"><Image src={publicUrl("product-images", img.storage_path as string)} alt={(img.alt_text as string) || ""} fill sizes="96px" className="object-cover" /></div>
              <div className="flex-1 space-y-2">
                <ActionForm action={updateImage} className="space-y-2" submitLabel="Update">
                  {hidden("id", img.id as string)}{hidden("product_id", id)}
                  <input name="alt_text" aria-label="Alt text" defaultValue={img.alt_text as string} placeholder="Alt text" className="field" maxLength={200} />
                  <input name="sort_order" type="number" aria-label="Sort order" defaultValue={img.sort_order as number} className="field !w-24" />
                </ActionForm>
                <ActionButton danger label="Delete" confirmText="Delete this photo?" action={deleteImage.bind(null, img.id as string, id)} />
              </div>
            </li>
          ))}
        </ul>
        <Uploader kind="image" targetId={id} accept="image/jpeg,image/png,image/webp,image/avif" label="Add a photo" withAlt />
      </section>

      <section aria-labelledby="model-h" className="space-y-4">
        <h2 id="model-h" className="text-2xl">3D model</h2>
        <p className="text-sm text-ink-soft">Upload a binary glTF (.glb) up to 25 MB. Keep it light: aim for under 50,000 triangles and compressed textures so it loads on phones. Without a model, the showroom shows a photo plaque and labels it “Photo preview”.</p>
        {model ? (
          <div className="card space-y-3 p-4 text-sm">
            <p>Current model: {Math.round(Number(model.file_size_bytes ?? 0) / 1024)} KB. Uploading a new file replaces it.</p>
            <ActionForm action={updateModelScale} submitLabel="Update scale" className="flex items-end gap-3">
              {hidden("product_id", id)}
              <div><label className="label" htmlFor="scale">Display scale</label><input id="scale" name="scale" type="number" step="0.05" min="0.05" max="5" defaultValue={Number(model.scale)} className="field !w-28" /></div>
            </ActionForm>
            <ActionButton danger label="Remove model" confirmText="Remove the 3D model from this product?" action={deleteModel.bind(null, id)} />
          </div>
        ) : <p className="text-sm">No 3D model yet.</p>}
        <Uploader kind="model" targetId={id} accept=".glb,model/gltf-binary" label="Upload .glb model" />
      </section>

      <section aria-labelledby="var-h" className="space-y-4">
        <h2 id="var-h" className="text-2xl">Variants</h2>
        <p className="text-sm text-ink-soft">If a product has active variants, customers must pick one and stock is tracked per variant.</p>
        <ul className="space-y-2">
          {(variants ?? []).map((v) => (
            <li key={v.id as string} className="card p-3">
              <ActionForm action={saveVariant} submitLabel="Update" className="flex flex-wrap items-end gap-3">
                {hidden("id", v.id as string)}{hidden("product_id", id)}
                <div><label className="label">Name</label><input name="name" defaultValue={v.name as string} className="field" required /></div>
                <div><label className="label">Price ±</label><input name="price_delta_bdt" type="number" step="0.01" defaultValue={Number(v.price_delta_bdt)} className="field !w-28" /></div>
                <div><label className="label">Stock</label><input name="stock_qty" type="number" min={0} defaultValue={v.stock_qty as number} className="field !w-24" /></div>
                <label className="flex items-center gap-2 pb-3 text-sm"><input type="checkbox" name="is_active" defaultChecked={v.is_active as boolean} className="size-4 accent-[#9c8355]" />Active</label>
              </ActionForm>
              <ActionButton danger label="Delete variant" confirmText="Delete this variant?" action={deleteVariant.bind(null, v.id as string, id)} />
            </li>
          ))}
        </ul>
        <ActionForm action={saveVariant} submitLabel="Add variant" className="card flex flex-wrap items-end gap-3 p-3">
          {hidden("product_id", id)}
          <div><label className="label" htmlFor="nv-name">New variant</label><input id="nv-name" name="name" className="field" placeholder="e.g. Large, 30 cm" required /></div>
          <div><label className="label" htmlFor="nv-p">Price ±</label><input id="nv-p" name="price_delta_bdt" type="number" step="0.01" defaultValue={0} className="field !w-28" /></div>
          <div><label className="label" htmlFor="nv-s">Stock</label><input id="nv-s" name="stock_qty" type="number" min={0} defaultValue={0} className="field !w-24" /></div>
        </ActionForm>
      </section>

      <section aria-labelledby="opt-h" className="space-y-4">
        <h2 id="opt-h" className="text-2xl">Personalisation fields</h2>
        <p className="text-sm text-ink-soft">These appear in the customisation studio. The product must also be ticked “Can be personalised”. Orders are checked against these rules on the server.</p>
        <ul className="space-y-2 text-sm">
          {(options ?? []).map((o) => (
            <li key={o.id as string} className="card flex flex-wrap items-center justify-between gap-2 p-3">
              <span><strong>{o.label as string}</strong> · {o.field_type as string} · key “{o.field_key as string}” · max {o.max_length as number}{o.is_required ? " · required" : ""}{o.choices ? ` · ${(o.choices as string[]).join(", ")}` : ""}</span>
              <ActionButton danger label="Delete" confirmText="Delete this field?" action={deleteOption.bind(null, o.id as string, id)} />
            </li>
          ))}
        </ul>
        <ActionForm action={saveOption} submitLabel="Add field" className="card grid gap-3 p-3 sm:grid-cols-3">
          {hidden("product_id", id)}
          <div><label className="label" htmlFor="o-label">Label</label><input id="o-label" name="label" className="field" placeholder="Recipient name" required /></div>
          <div><label className="label" htmlFor="o-key">Key</label><input id="o-key" name="field_key" className="field" placeholder="recipient" pattern="[a-z][a-z0-9_]{0,30}" required /></div>
          <div><label className="label" htmlFor="o-type">Type</label><select id="o-type" name="field_type" className="field"><option value="text">Short text</option><option value="message">Message</option><option value="date">Date</option><option value="font">Font choice</option><option value="color">Colour choice</option></select></div>
          <div><label className="label" htmlFor="o-max">Max length</label><input id="o-max" name="max_length" type="number" min={1} max={500} defaultValue={60} className="field" /></div>
          <div className="sm:col-span-2"><label className="label" htmlFor="o-ch">Choices (font/colour; comma-separated)</label><input id="o-ch" name="choices" className="field" placeholder="Serif, Script, Sans   or   #C5AA7A, #3A352D" /></div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_required" className="size-4 accent-[#9c8355]" />Required</label>
        </ActionForm>
      </section>
    </div>
  );
}
