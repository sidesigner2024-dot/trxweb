import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { formatBDT } from "@/lib/format";

export const metadata: Metadata = { title: "Reports" };
const daysAgoISO = (d: number) => new Date(Date.now() - d * 86400_000).toISOString();

export default async function AdminReports() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("orders").select("created_at, status, total_bdt, payment_status").gte("created_at", daysAgoISO(30)).limit(10000);
  const rows = (data ?? []).filter((o) => !["cancelled", "refunded"].includes(o.status as string));
  const byDay = new Map<string, { n: number; total: number }>();
  for (const o of rows) {
    const day = new Date(new Date(o.created_at as string).getTime() + 6 * 3600_000).toISOString().slice(0, 10); // Bangladesh date
    const d = byDay.get(day) ?? { n: 0, total: 0 }; d.n++; d.total += Number(o.total_bdt); byDay.set(day, d);
  }
  const days = [...byDay.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  const paid = rows.filter((o) => o.payment_status === "paid").reduce((s, o) => s + Number(o.total_bdt), 0);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Sales report</h1>
      <p className="text-sm text-ink-soft">Last 30 days, excluding cancelled and refunded orders. “Collected” counts only orders marked paid (COD orders become paid when marked Delivered).</p>
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="card p-4"><p className="text-xs uppercase tracking-widest text-ink-soft">Orders</p><p className="text-2xl">{rows.length}</p></div>
        <div className="card p-4"><p className="text-xs uppercase tracking-widest text-ink-soft">Order value</p><p className="text-2xl">{formatBDT(rows.reduce((s, o) => s + Number(o.total_bdt), 0))}</p></div>
        <div className="card p-4"><p className="text-xs uppercase tracking-widest text-ink-soft">Collected</p><p className="text-2xl">{formatBDT(paid)}</p></div>
      </div>
      <table className="w-full text-left text-sm"><thead><tr className="border-b border-champagne text-ink-soft"><th className="py-2">Date</th><th>Orders</th><th>Value</th></tr></thead>
        <tbody>{days.map(([d, v]) => <tr key={d} className="border-b border-champagne/60"><td className="py-2">{d}</td><td>{v.n}</td><td>{formatBDT(v.total)}</td></tr>)}</tbody></table>
      {days.length === 0 && <p className="text-ink-soft">No orders in this period.</p>}
      <form action="/api/admin/orders-csv" className="card flex flex-wrap items-end gap-3 p-4">
        <div><label className="label" htmlFor="from">From</label><input id="from" name="from" type="date" className="field" /></div>
        <div><label className="label" htmlFor="to">To</label><input id="to" name="to" type="date" className="field" /></div>
        <button className="btn btn-primary">Download orders CSV</button>
      </form>
    </div>
  );
}
