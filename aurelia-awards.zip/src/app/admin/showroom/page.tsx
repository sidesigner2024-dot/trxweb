import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ROOM } from "@/components/showroom/types";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { deleteDisplay, deleteRoom, saveDisplay, saveRoom } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Showroom" };

type Room = { id: string; name: string; slug: string; description: string | null; sort_order: number; is_active: boolean };
type Disp = { id: string; room_id: string; product_id: string; display_type: string; pos_x: number | string; pos_y: number | string; pos_z: number | string; rotation_y: number | string; scale: number | string; is_active: boolean; product: { name: string } | { name: string }[] | null };

function RoomFields({ r }: { r?: Room }) {
  return (<>
    {r && <input type="hidden" name="id" value={r.id} />}
    <div className="grid gap-3 sm:grid-cols-3">
      <div><label className="label">Room name</label><input name="name" defaultValue={r?.name} className="field" required /></div>
      <div><label className="label">Slug</label><input name="slug" defaultValue={r?.slug} className="field" placeholder="auto" /></div>
      <div><label className="label">Sort</label><input name="sort_order" type="number" defaultValue={r?.sort_order ?? 0} className="field" /></div>
      <div className="sm:col-span-3"><label className="label">Description</label><input name="description" defaultValue={r?.description ?? ""} className="field" /></div>
    </div>
    <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={r?.is_active ?? true} className="size-4 accent-[#9c8355]" />Open to visitors</label>
  </>);
}

function DisplayFields({ roomId, d, products }: { roomId: string; d?: Disp; products: { id: string; name: string }[] }) {
  const n = (v: unknown, def = 0) => (v == null ? def : Number(v));
  return (<>
    {d && <input type="hidden" name="id" value={d.id} />}<input type="hidden" name="room_id" value={roomId} />
    <div className="grid gap-3 sm:grid-cols-4">
      <div className="sm:col-span-2"><label className="label">Product</label><select name="product_id" defaultValue={d?.product_id} className="field" required><option value="">Choose…</option>{products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
      <div><label className="label">Display</label><select name="display_type" defaultValue={d?.display_type ?? "pedestal"} className="field"><option value="pedestal">Pedestal</option><option value="cabinet">Glass cabinet</option><option value="shelf">Shelf</option><option value="wall">Wall mount</option></select></div>
      <div><label className="label">Scale</label><input name="scale" type="number" step="0.1" defaultValue={n(d?.scale, 1)} className="field" /></div>
      <div><label className="label">X (left–right)</label><input name="pos_x" type="number" step="0.1" defaultValue={n(d?.pos_x)} className="field" /></div>
      <div><label className="label">Z (front–back)</label><input name="pos_z" type="number" step="0.1" defaultValue={n(d?.pos_z)} className="field" /></div>
      <div><label className="label">Height Y</label><input name="pos_y" type="number" step="0.1" defaultValue={n(d?.pos_y)} className="field" /></div>
      <div><label className="label">Rotation (rad)</label><input name="rotation_y" type="number" step="0.1" defaultValue={n(d?.rotation_y)} className="field" /></div>
    </div>
    {d && <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={d.is_active} className="size-4 accent-[#9c8355]" />Shown</label>}
  </>);
}

export default async function AdminShowroom() {
  const { supabase } = await requireAdminPage();
  const [{ data: rooms }, { data: displays }, { data: products }] = await Promise.all([
    supabase.from("showroom_rooms").select("*").order("sort_order"),
    supabase.from("showroom_displays").select("*, product:products(name)").order("sort_order"),
    supabase.from("products").select("id, name").eq("is_active", true).order("name").limit(500),
  ]);
  const prods = (products ?? []) as { id: string; name: string }[];
  return (
    <div className="space-y-10">
      <h1 className="text-3xl">Showroom</h1>
      <p className="text-sm text-ink-soft">Place products by coordinates in metres. The room is {ROOM.width} m wide (X from −{ROOM.width / 2} to {ROOM.width / 2}) and {ROOM.depth} m deep (Z from −{ROOM.depth / 2} at the back wall to {ROOM.depth / 2} at the entrance). Visitors start at the front looking toward the back wall. Products with a 3D model appear as models; others appear as a labelled photo plaque. For wall mounts, set Y to about 1.5 and place them near a wall.</p>
      {((rooms ?? []) as Room[]).map((r) => (
        <section key={r.id} className="space-y-4" aria-label={r.name}>
          <h2 className="text-2xl">{r.name}</h2>
          <ActionForm action={saveRoom} submitLabel="Save room" className="card space-y-3 p-4"><RoomFields r={r} /></ActionForm>
          <ActionButton danger label="Delete room (and its placements)" confirmText="Delete this room and all placements in it?" action={deleteRoom.bind(null, r.id)} />
          <ul className="space-y-3">
            {((displays ?? []) as Disp[]).filter((d) => d.room_id === r.id).map((d) => {
              const pn = (Array.isArray(d.product) ? d.product[0] : d.product)?.name ?? "Product";
              return (<li key={d.id} className="card p-4"><p className="mb-2 font-medium">{pn}</p>
                <ActionForm action={saveDisplay} submitLabel="Save placement" className="space-y-3"><DisplayFields roomId={r.id} d={d} products={prods} /></ActionForm>
                <div className="mt-2"><ActionButton danger label="Remove from room" confirmText="Remove this product from the room?" action={deleteDisplay.bind(null, d.id)} /></div></li>);
            })}
          </ul>
          <div><h3 className="mb-2 text-lg">Place a product</h3><ActionForm action={saveDisplay} submitLabel="Place product" className="card space-y-3 p-4"><DisplayFields roomId={r.id} products={prods} /></ActionForm></div>
        </section>
      ))}
      <section aria-labelledby="nr"><h2 id="nr" className="mb-3 text-xl">Add a room</h2><ActionForm action={saveRoom} submitLabel="Add room" className="card space-y-3 p-4"><RoomFields /></ActionForm></section>
    </div>
  );
}
