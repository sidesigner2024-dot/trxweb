import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { RoleSelect } from "@/components/admin/role-select";

export const metadata: Metadata = { title: "Customers & staff" };

export default async function AdminCustomers({ searchParams }: { searchParams: Promise<{ q?: string; role?: string }> }) {
  const { supabase, role, userId } = await requireAdminPage();
  const { q = "", role: roleFilter = "" } = await searchParams;
  let req = supabase.from("profiles").select("id, full_name, phone, role, created_at").order("created_at", { ascending: false }).limit(100);
  const term = q.replace(/[,()%*\\:"']/g, " ").trim().slice(0, 40);
  if (term) req = req.or(`full_name.ilike.%${term}%,phone.ilike.%${term}%`);
  if (["customer", "staff", "admin"].includes(roleFilter)) req = req.eq("role", roleFilter);
  const { data } = await req;
  const ids = (data ?? []).map((p) => p.id as string);
  const { data: orders } = ids.length ? await supabase.from("orders").select("user_id, total_bdt, status").in("user_id", ids) : { data: [] };
  const stats = new Map<string, { n: number }>();
  for (const o of orders ?? []) { const s = stats.get(o.user_id as string) ?? { n: 0 }; s.n++; stats.set(o.user_id as string, s); }
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Customers &amp; staff</h1>
      {role === "admin" ? <p className="text-sm text-ink-soft">Staff can manage products, orders, showroom, messages and reviews. Only admins can change roles, coupons, shipping and settings. You cannot change your own role.</p> : <p className="text-sm text-ink-soft">Only admins can change roles.</p>}
      <form className="flex flex-wrap gap-2"><input name="q" defaultValue={q} placeholder="Name or phone" aria-label="Search" className="field !w-60" /><select name="role" defaultValue={roleFilter} aria-label="Role" className="field !w-40"><option value="">All roles</option><option value="customer">Customers</option><option value="staff">Staff</option><option value="admin">Admins</option></select><button className="btn btn-ghost">Filter</button></form>
      <div className="overflow-x-auto"><table className="w-full text-left text-sm">
        <thead><tr className="border-b border-champagne text-ink-soft"><th className="py-2">Name</th><th>Phone</th><th>Joined</th><th>Orders</th><th>Role</th></tr></thead>
        <tbody>{(data ?? []).map((p) => (
          <tr key={p.id as string} className="border-b border-champagne/60">
            <td className="py-2">{(p.full_name as string) || "—"}</td><td>{(p.phone as string) ?? "—"}</td><td>{new Date(p.created_at as string).toLocaleDateString("en-GB")}</td><td>{stats.get(p.id as string)?.n ?? 0}</td>
            <td>{role === "admin" && p.id !== userId ? <RoleSelect userId={p.id as string} role={p.role as "customer" | "staff" | "admin"} /> : (p.role as string)}</td>
          </tr>))}</tbody>
      </table></div>
    </div>
  );
}
