import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { deleteCategory, saveCategory } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Categories" };

type Cat = { id: string; name: string; slug: string; description: string | null; parent_id: string | null; sort_order: number; is_active: boolean };

function CategoryFields({ c, all }: { c?: Cat; all: Cat[] }) {
  return (
    <>
      {c && <input type="hidden" name="id" value={c.id} />}
      <div className="grid gap-3 sm:grid-cols-3">
        <div><label className="label">Name</label><input name="name" defaultValue={c?.name} className="field" required /></div>
        <div><label className="label">Slug</label><input name="slug" defaultValue={c?.slug} className="field" placeholder="auto from name" /></div>
        <div><label className="label">Parent (makes it a subcategory)</label>
          <select name="parent_id" defaultValue={c?.parent_id ?? ""} className="field"><option value="">None</option>{all.filter((x) => x.id !== c?.id).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></div>
        <div className="sm:col-span-2"><label className="label">Description</label><input name="description" defaultValue={c?.description ?? ""} className="field" /></div>
        <div><label className="label">Sort order</label><input name="sort_order" type="number" defaultValue={c?.sort_order ?? 0} className="field" /></div>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={c?.is_active ?? true} className="size-4 accent-[#9c8355]" />Visible in the shop</label>
    </>
  );
}

export default async function AdminCategories() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("categories").select("*").order("sort_order");
  const cats = (data ?? []) as Cat[];
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Categories</h1>
      <ul className="space-y-3">
        {cats.map((c) => (
          <li key={c.id} className="card p-4">
            <ActionForm action={saveCategory} submitLabel="Save" className="space-y-3"><CategoryFields c={c} all={cats} /></ActionForm>
            <div className="mt-2"><ActionButton danger label="Delete" confirmText={`Delete “${c.name}”? Products in it will become uncategorised.`} action={deleteCategory.bind(null, c.id)} /></div>
          </li>
        ))}
      </ul>
      <section aria-labelledby="add"><h2 id="add" className="mb-3 text-xl">Add a category</h2>
        <ActionForm action={saveCategory} submitLabel="Add category" className="card space-y-3 p-4"><CategoryFields all={cats} /></ActionForm></section>
    </div>
  );
}
