import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { deleteCoupon, saveCoupon } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Coupons" };

type C = { id: string; code: string; type: "percent" | "fixed"; value: number | string; min_subtotal_bdt: number | string; max_uses: number | null; used_count: number; starts_at: string | null; expires_at: string | null; is_active: boolean };
const local = (iso: string | null) => (iso ? new Date(new Date(iso).getTime() + 6 * 3600_000).toISOString().slice(0, 16) : "");

function Fields({ c }: { c?: C }) {
  return (
    <>
      {c && <input type="hidden" name="id" value={c.id} />}
      <div className="grid gap-3 sm:grid-cols-3">
        <div><label className="label">Code</label><input name="code" defaultValue={c?.code} className="field uppercase" required /></div>
        <div><label className="label">Type</label><select name="type" defaultValue={c?.type ?? "percent"} className="field"><option value="percent">Percent off</option><option value="fixed">Fixed amount (BDT)</option></select></div>
        <div><label className="label">Value</label><input name="value" type="number" step="0.01" min="0.01" defaultValue={c ? Number(c.value) : ""} className="field" required /></div>
        <div><label className="label">Minimum subtotal (BDT)</label><input name="min_subtotal_bdt" type="number" min="0" defaultValue={c ? Number(c.min_subtotal_bdt) : 0} className="field" /></div>
        <div><label className="label">Max uses (blank = unlimited)</label><input name="max_uses" type="number" min="1" defaultValue={c?.max_uses ?? ""} className="field" /></div>
        <div />
        <div><label className="label">Starts (Bangladesh time)</label><input name="starts_at" type="datetime-local" defaultValue={local(c?.starts_at ?? null)} className="field" /></div>
        <div><label className="label">Expires</label><input name="expires_at" type="datetime-local" defaultValue={local(c?.expires_at ?? null)} className="field" /></div>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={c?.is_active ?? true} className="size-4 accent-[#9c8355]" />Active</label>
    </>
  );
}

export default async function AdminCoupons() {
  const { supabase } = await requireAdminPage("admin");
  const { data } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Coupons</h1>
      <p className="text-sm text-ink-soft">Coupons are validated on the server at checkout (dates, minimum, usage limit). Discounts cannot be changed from the browser.</p>
      <ul className="space-y-3">
        {((data ?? []) as C[]).map((c) => (
          <li key={c.id} className="card p-4"><p className="mb-2 text-sm text-ink-soft">Used {c.used_count}{c.max_uses ? ` of ${c.max_uses}` : ""} times</p>
            <ActionForm action={saveCoupon} submitLabel="Save" className="space-y-3"><Fields c={c} /></ActionForm>
            <div className="mt-2"><ActionButton danger label="Delete" confirmText={`Delete coupon ${c.code}?`} action={deleteCoupon.bind(null, c.id)} /></div></li>
        ))}
      </ul>
      <section aria-labelledby="add"><h2 id="add" className="mb-3 text-xl">New coupon</h2><ActionForm action={saveCoupon} submitLabel="Create coupon" className="card space-y-3 p-4"><Fields /></ActionForm></section>
    </div>
  );
}
