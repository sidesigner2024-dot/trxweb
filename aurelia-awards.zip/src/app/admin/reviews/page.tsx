import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionButton } from "@/components/admin/action-form";
import { deleteReview, setReviewApproval } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Reviews" };

export default async function AdminReviews() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("reviews").select("id, rating, title, body, is_approved, created_at, product:products(name)").order("is_approved").order("created_at", { ascending: false }).limit(100);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Reviews</h1>
      <p className="text-sm text-ink-soft">Only customers with a delivered order can leave a review. Reviews appear in the shop after you approve them.</p>
      {(data ?? []).length === 0 && <p className="text-ink-soft">No reviews yet.</p>}
      <ul className="space-y-3">{(data ?? []).map((r) => {
        const p = (Array.isArray(r.product) ? r.product[0] : r.product) as { name?: string } | null;
        return (<li key={r.id as string} className="card space-y-1 p-4 text-sm">
          <p><strong>{p?.name ?? "Product"}</strong> · {"★".repeat(r.rating as number)} · {r.is_approved ? "Approved" : "Waiting"}</p>
          {r.title ? <p className="font-medium">{r.title as string}</p> : null}{r.body ? <p className="text-ink-soft">{r.body as string}</p> : null}
          <p className="flex gap-4"><ActionButton label={r.is_approved ? "Unapprove" : "Approve"} action={setReviewApproval.bind(null, r.id as string, !r.is_approved)} /><ActionButton danger label="Delete" confirmText="Delete this review?" action={deleteReview.bind(null, r.id as string)} /></p>
        </li>);
      })}</ul>
    </div>
  );
}
