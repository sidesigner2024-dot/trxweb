import type { Metadata } from "next";
import { requireAdminPage } from "@/lib/admin";
import { ActionButton } from "@/components/admin/action-form";
import { setMessageStatus } from "@/app/admin/content-actions";

export const metadata: Metadata = { title: "Messages" };

export default async function AdminMessages() {
  const { supabase } = await requireAdminPage();
  const { data } = await supabase.from("contact_messages").select("*").order("created_at", { ascending: false }).limit(100);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Customer messages</h1>
      {(data ?? []).length === 0 && <p className="text-ink-soft">No messages yet.</p>}
      <ul className="space-y-3">{(data ?? []).map((m) => (
        <li key={m.id as string} className="card space-y-2 p-4 text-sm">
          <p className="flex flex-wrap justify-between gap-2"><strong>{m.name as string}{m.subject ? ` — ${m.subject}` : ""}</strong><span className="text-ink-soft">{new Date(m.created_at as string).toLocaleString("en-GB")} · {m.status as string}</span></p>
          <p className="text-ink-soft">{m.email ? <a className="underline" href={`mailto:${m.email}`}>{m.email as string}</a> : null}{m.email && m.phone ? " · " : ""}{m.phone ? <a className="underline" href={`tel:${m.phone}`}>{m.phone as string}</a> : null}</p>
          <p className="whitespace-pre-line">{m.message as string}</p>
          <p className="flex gap-4"><ActionButton label="Mark read" action={setMessageStatus.bind(null, m.id as string, "read")} /><ActionButton label="Mark replied" action={setMessageStatus.bind(null, m.id as string, "replied")} /></p>
        </li>))}</ul>
    </div>
  );
}
