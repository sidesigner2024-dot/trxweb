import type { Metadata } from "next";
import { ProsePage } from "@/components/prose-page";
import { getSettings } from "@/lib/data";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "About us", alternates: { canonical: "/about" } };

export default async function AboutPage() {
  const s = await getSettings();
  const about = s.about?.body;
  return (
    <ProsePage title="About us">
      {about ? <p className="whitespace-pre-line">{about}</p> : (
        <p>Our story has not been added yet. The owner can write it in Admin → Settings.</p>
      )}
    </ProsePage>
  );
}
