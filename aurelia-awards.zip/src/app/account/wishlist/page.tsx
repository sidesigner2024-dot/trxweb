import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { ProductCard } from "@/components/product/product-card";
import type { ProductSummary } from "@/lib/types";

export const metadata: Metadata = { title: "Wishlist", robots: { index: false } };

export default async function WishlistPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("wishlists").select(
    "product:products(id, slug, sku, name, price_bdt, discount_price_bdt, stock_qty, track_stock, is_customizable, is_sample, is_featured, category:categories!products_category_id_fkey(name, slug), images:product_images(storage_path, alt_text, sort_order), model:product_models(id))"
  ).order("created_at", { ascending: false });
  const products = (data ?? []).map((r) => (Array.isArray(r.product) ? r.product[0] : r.product)).filter(Boolean) as unknown as ProductSummary[];
  return (
    <div>
      <h1 className="mb-6 text-3xl">Wishlist</h1>
      {products.length === 0 ? <p className="text-ink-soft">Nothing saved yet. Use “Add to wishlist” on any product.</p> : (
        <ul className="grid grid-cols-2 gap-4 lg:grid-cols-3">{products.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}</ul>
      )}
    </div>
  );
}
