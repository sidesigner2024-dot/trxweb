import type { Metadata } from "next";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatBDT, ORDER_STATUS_LABELS } from "@/lib/format";

export const metadata: Metadata = { title: "My orders", robots: { index: false } };

export default async function OrdersPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("orders").select("id, order_number, status, total_bdt, created_at").order("created_at", { ascending: false }).limit(50);
  return (
    <div>
      <h1 className="mb-6 text-3xl">My orders</h1>
      {(data ?? []).length === 0 ? <p className="text-ink-soft">You have not placed any orders yet.</p> : (
        <ul className="space-y-3">
          {data!.map((o) => (
            <li key={o.id as string}>
              <Link href={`/account/orders/${o.id}`} className="card flex flex-wrap items-center justify-between gap-2 p-4 hover:shadow-lg">
                <span className="font-medium">{o.order_number as string}</span>
                <span className="text-sm text-ink-soft">{new Date(o.created_at as string).toLocaleDateString("en-GB")}</span>
                <span className="text-sm">{ORDER_STATUS_LABELS[o.status as string]}</span>
                <span>{formatBDT(o.total_bdt as string)}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
