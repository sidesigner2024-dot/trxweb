import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { formatBDT, ORDER_STATUS_LABELS } from "@/lib/format";
import { OrderTimeline } from "@/components/order/order-timeline";
import { CancelOrderButton } from "@/components/account/account-forms";

export const metadata: Metadata = { title: "Order details", robots: { index: false } };

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const supabase = await createClient();
  const { data: order } = await supabase.from("orders").select("*").eq("id", id).maybeSingle(); // RLS: owner or staff
  if (!order) notFound();
  const [{ data: items }, { data: events }, { data: shipment }] = await Promise.all([
    supabase.from("order_items").select("id, product_name, variant_name, quantity, unit_price_bdt, line_total_bdt, customization, design:custom_designs(status, admin_note)").eq("order_id", id),
    supabase.from("order_events").select("id, to_status, note, created_at").eq("order_id", id).order("created_at"),
    supabase.from("shipments").select("carrier, tracking_number, tracking_url").eq("order_id", id).maybeSingle(),
  ]);
  const addr = order.shipping_address as Record<string, string>;
  return (
    <div className="space-y-8">
      <div><h1 className="text-3xl">Order {order.order_number}</h1><p className="text-sm text-ink-soft">Placed {new Date(order.created_at).toLocaleString("en-GB")} · {order.payment_method === "cod" ? "Cash on Delivery" : "Online"} · {order.payment_status}</p></div>
      <OrderTimeline status={order.status} />
      {shipment?.tracking_number && (
        <p className="card p-4 text-sm">Courier: {shipment.carrier ?? "—"} · Tracking: {shipment.tracking_url && /^https?:\/\//.test(shipment.tracking_url) ? <a className="underline" href={shipment.tracking_url} rel="noopener noreferrer" target="_blank">{shipment.tracking_number}</a> : shipment.tracking_number}</p>
      )}
      <ul className="space-y-3">
        {(items ?? []).map((it) => {
          const d = (Array.isArray(it.design) ? it.design[0] : it.design) as { status: string; admin_note: string | null } | null;
          return (
            <li key={it.id as string} className="card p-4 text-sm">
              <div className="flex justify-between gap-3"><span>{it.product_name as string}{it.variant_name ? ` — ${it.variant_name}` : ""} × {it.quantity as number}</span><span>{formatBDT(it.line_total_bdt as string)}</span></div>
              {d && <p className="mt-2 text-ink-soft">Design: {d.status === "pending" ? "awaiting review" : d.status === "approved" ? "approved" : "revision requested"}{d.admin_note ? ` — “${d.admin_note}”` : ""}</p>}
            </li>
          );
        })}
      </ul>
      <dl className="card space-y-1 p-4 text-sm">
        <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatBDT(order.subtotal_bdt)}</dd></div>
        {Number(order.discount_bdt) > 0 && <div className="flex justify-between"><dt>Discount</dt><dd>−{formatBDT(order.discount_bdt)}</dd></div>}
        <div className="flex justify-between"><dt>Delivery</dt><dd>{formatBDT(order.shipping_bdt)}</dd></div>
        <div className="flex justify-between border-t border-champagne pt-2 text-base font-medium"><dt>Total</dt><dd>{formatBDT(order.total_bdt)}</dd></div>
      </dl>
      <p className="text-sm text-ink-soft">Deliver to: {addr.recipient_name}, {addr.line1}, {addr.city}, {addr.district}</p>
      <section aria-labelledby="hist"><h2 id="hist" className="mb-2 text-xl">History</h2>
        <ul className="space-y-1 text-sm">{(events ?? []).map((e) => <li key={e.id as string}>{new Date(e.created_at as string).toLocaleString("en-GB")} — {ORDER_STATUS_LABELS[e.to_status as string]}{e.note ? ` (${e.note})` : ""}</li>)}</ul>
      </section>
      {order.status === "pending" && <CancelOrderButton orderId={order.id} />}
    </div>
  );
}
