import type { Metadata } from "next";
import { getSessionUser } from "@/lib/data";
import { createClient } from "@/lib/supabase/server";
import { AddressForm, DeleteAddressButton, ProfileForm } from "@/components/account/account-forms";

export const metadata: Metadata = { title: "My account", robots: { index: false } };

export default async function AccountPage() {
  const user = (await getSessionUser())!;
  const supabase = await createClient();
  const [{ data: addresses }, { data: notes }] = await Promise.all([
    supabase.from("addresses").select("id, recipient_name, phone, line1, city, district").eq("user_id", user.id),
    supabase.from("notifications").select("id, title, body, link, created_at, read_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(8),
  ]);
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Hello{user.fullName ? `, ${user.fullName}` : ""}</h1>
      <ProfileForm fullName={user.fullName} phone={user.phone ?? ""} />
      <section aria-labelledby="addr-h" className="space-y-3">
        <h2 id="addr-h" className="text-xl">Saved addresses</h2>
        {(addresses ?? []).length === 0 && <p className="text-sm text-ink-soft">No saved addresses yet.</p>}
        <ul className="space-y-2">
          {(addresses ?? []).map((a) => (
            <li key={a.id as string} className="card flex items-start justify-between gap-3 p-4 text-sm">
              <span>{a.recipient_name as string}, {a.phone as string}<br />{a.line1 as string}, {a.city as string}, {a.district as string}</span>
              <DeleteAddressButton id={a.id as string} />
            </li>
          ))}
        </ul>
        <AddressForm />
      </section>
      <section aria-labelledby="note-h" className="space-y-3">
        <h2 id="note-h" className="text-xl">Notifications</h2>
        {(notes ?? []).length === 0 && <p className="text-sm text-ink-soft">Nothing yet.</p>}
        <ul className="space-y-2">
          {(notes ?? []).map((n) => (
            <li key={n.id as string} className="card p-4 text-sm"><p className="font-medium">{n.title as string}</p>{n.body ? <p className="text-ink-soft">{n.body as string}</p> : null}</li>
          ))}
        </ul>
        <p className="text-xs text-ink-soft">In-app notifications only. Email notifications are not enabled until an email provider is configured.</p>
      </section>
    </div>
  );
}
