"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { addressSchema, bdPhone } from "@/lib/validation";
import { describeDbError } from "@/lib/db-errors";

export type FormState = { ok?: boolean; error?: string } | undefined;

export async function updateProfile(_: FormState, form: FormData): Promise<FormState> {
  const parsed = z.object({ full_name: z.string().trim().min(1).max(120), phone: bdPhone.or(z.literal("")) })
    .safeParse({ full_name: form.get("full_name"), phone: form.get("phone") ?? "" });
  if (!parsed.success) return { error: "Please enter your name and a valid mobile number." };
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { error: "Please sign in." };
  const { error } = await supabase.from("profiles")
    .update({ full_name: parsed.data.full_name, phone: parsed.data.phone || null }).eq("id", auth.user.id);
  if (error) return { error: "Could not save your profile." };
  revalidatePath("/account");
  return { ok: true };
}

export async function addAddress(_: FormState, form: FormData): Promise<FormState> {
  const parsed = addressSchema.safeParse(Object.fromEntries(form));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Check the address." };
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { error: "Please sign in." };
  const { error } = await supabase.from("addresses").insert({ ...parsed.data, user_id: auth.user.id });
  if (error) return { error: "Could not save the address." };
  revalidatePath("/account");
  return { ok: true };
}

export async function deleteAddress(id: string) {
  if (!z.uuid().safeParse(id).success) return;
  const supabase = await createClient();
  await supabase.from("addresses").delete().eq("id", id); // RLS limits this to the owner
  revalidatePath("/account");
}

export async function cancelOrder(orderId: string): Promise<FormState> {
  if (!z.uuid().safeParse(orderId).success) return { error: "Invalid order." };
  const supabase = await createClient();
  const { error } = await supabase.rpc("cancel_my_order", { p_order_id: orderId });
  if (error) return { error: describeDbError(error.message) };
  revalidatePath(`/account/orders/${orderId}`);
  return { ok: true };
}
