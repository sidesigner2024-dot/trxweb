import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/data";
import { signOut } from "@/app/auth/actions";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/account");
  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[200px_1fr]">
      <nav aria-label="Account" className="flex gap-4 text-sm md:flex-col">
        <Link href="/account" className="hover:text-gold-deep">Overview</Link>
        <Link href="/account/orders" className="hover:text-gold-deep">Orders</Link>
        <Link href="/account/wishlist" className="hover:text-gold-deep">Wishlist</Link>
        {user.role !== "customer" && <Link href="/admin" className="text-gold-deep">Admin</Link>}
        <form action={signOut}><button className="text-ink-soft underline">Sign out</button></form>
      </nav>
      <div>{children}</div>
    </div>
  );
}
