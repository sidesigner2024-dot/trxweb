"use server";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured, publicEnv } from "@/lib/env";
import { loginSchema, registerSchema } from "@/lib/validation";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { safeNext } from "@/lib/safe-redirect";
import { z } from "zod";

export type AuthState = { error?: string; message?: string; fieldErrors?: Record<string, string[]> } | undefined;

async function guard(kind: string, limit: number): Promise<string | null> {
  const ip = clientIp(await headers());
  const r = rateLimit(`${kind}:${ip}`, limit, 10 * 60_000);
  return r.ok ? null : `Too many attempts. Please try again in ${Math.ceil(r.retryAfterSec / 60)} minute(s).`;
}

export async function signIn(_: AuthState, form: FormData): Promise<AuthState> {
  if (!isSupabaseConfigured()) return { error: "The store is not connected to its database yet." };
  const limited = await guard("login", 15);
  if (limited) return { error: limited };
  const parsed = loginSchema.safeParse({ email: form.get("email"), password: form.get("password") });
  if (!parsed.success) return { error: "Enter your email and password." };
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return { error: "Incorrect email or password." }; // same message for every failure: no account enumeration
  redirect(safeNext(String(form.get("next") ?? "")));
}

export async function signUp(_: AuthState, form: FormData): Promise<AuthState> {
  if (!isSupabaseConfigured()) return { error: "The store is not connected to its database yet." };
  const limited = await guard("register", 8);
  if (limited) return { error: limited };
  const parsed = registerSchema.safeParse({ full_name: form.get("full_name"), email: form.get("email"), password: form.get("password") });
  if (!parsed.success) return { error: "Please check your details.", fieldErrors: parsed.error.flatten((i) => i.message).fieldErrors as Record<string, string[]> };
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email, password: parsed.data.password,
    options: { data: { full_name: parsed.data.full_name }, emailRedirectTo: `${publicEnv.siteUrl}/auth/callback` },
  });
  if (error) return { error: "We could not create that account. If you already have one, try signing in." };
  if (data.session) redirect(safeNext(String(form.get("next") ?? "")));
  return { message: "Check your email to confirm your account, then sign in." };
}

export async function requestPasswordReset(_: AuthState, form: FormData): Promise<AuthState> {
  if (!isSupabaseConfigured()) return { error: "The store is not connected to its database yet." };
  const limited = await guard("reset", 5);
  if (limited) return { error: limited };
  const email = z.email().safeParse(form.get("email"));
  if (!email.success) return { error: "Enter a valid email address." };
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email.data, { redirectTo: `${publicEnv.siteUrl}/auth/callback?next=/reset-password` });
  return { message: "If an account exists for that email, a reset link is on its way." };
}

export async function updatePassword(_: AuthState, form: FormData): Promise<AuthState> {
  const pw = z.string().min(8, "Use at least 8 characters").max(72).safeParse(form.get("password"));
  if (!pw.success) return { error: pw.error.issues[0].message };
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: pw.data });
  if (error) return { error: "Could not update your password. Request a new reset link and try again." };
  redirect("/account");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
