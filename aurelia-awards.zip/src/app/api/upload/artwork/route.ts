import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { validateUpload } from "@/lib/validation";

/**
 * Customer artwork upload. Runs as the signed-in user, so storage RLS decides where they may write
 * (only into their own "<user id>/" folder of the private customer-artwork bucket).
 * The server checks size, extension and file signature; the bucket enforces limits again.
 */
export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return NextResponse.json({ error: "Please sign in to upload a logo." }, { status: 401 });
  if (!rateLimit(`upload:${auth.user.id}:${clientIp(request.headers)}`, 20, 10 * 60_000).ok)
    return NextResponse.json({ error: "Too many uploads. Please wait a few minutes." }, { status: 429 });

  let file: File | null = null;
  try {
    const form = await request.formData();
    const f = form.get("file");
    file = f instanceof File ? f : null;
  } catch {
    return NextResponse.json({ error: "The upload could not be read." }, { status: 400 });
  }
  if (!file) return NextResponse.json({ error: "No file was attached." }, { status: 400 });
  if (file.size > 10 * 1024 * 1024) return NextResponse.json({ error: "File is too large (max 10 MB)." }, { status: 413 });

  const bytes = new Uint8Array(await file.arrayBuffer());
  const check = validateUpload("customer-artwork", { name: file.name, size: file.size, bytes });
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: 415 });

  const path = `${auth.user.id}/${crypto.randomUUID()}.${check.ext}`;
  const { error } = await supabase.storage.from("customer-artwork").upload(path, bytes, { contentType: check.mime, upsert: false });
  if (error) return NextResponse.json({ error: "The upload failed. Please try again." }, { status: 500 });
  return NextResponse.json({ path });
}
