import { NextResponse, type NextRequest } from "next/server";
import { getAdminCtx } from "@/lib/admin";
import { toCsv } from "@/lib/csv";

/** Staff-only CSV export of orders (optionally ?from=YYYY-MM-DD&to=YYYY-MM-DD). */
export async function GET(request: NextRequest) {
  const ctx = await getAdminCtx("staff");
  if (!ctx) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  const sp = request.nextUrl.searchParams;
  const ok = (v: string | null) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);
  const from = ok(sp.get("from")), to = ok(sp.get("to"));
  let req = ctx.supabase.from("orders")
    .select("order_number, created_at, status, payment_method, payment_status, customer_name, customer_phone, subtotal_bdt, discount_bdt, shipping_bdt, total_bdt, coupon_code")
    .order("created_at", { ascending: false }).limit(10000);
  if (from) req = req.gte("created_at", `${from}T00:00:00+06:00`);
  if (to) req = req.lte("created_at", `${to}T23:59:59+06:00`);
  const { data, error } = await req;
  if (error) return NextResponse.json({ error: "Could not build the report." }, { status: 500 });
  const header = ["Order", "Date", "Status", "Payment method", "Payment status", "Customer", "Phone", "Subtotal", "Discount", "Delivery", "Total", "Coupon"];
  const rows = (data ?? []).map((o) => [o.order_number, o.created_at, o.status, o.payment_method, o.payment_status, o.customer_name, o.customer_phone, o.subtotal_bdt, o.discount_bdt, o.shipping_bdt, o.total_bdt, o.coupon_code ?? ""]);
  return new NextResponse(toCsv([header, ...rows]), {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="orders-${new Date().toISOString().slice(0, 10)}.csv"`, "Cache-Control": "no-store" },
  });
}
