import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, getAdminCtx } from "@/lib/admin";
import { rateLimit } from "@/lib/rate-limit";
import { validateUpload } from "@/lib/validation";

export const maxDuration = 60;

const KINDS = { image: "product-images", model: "product-models", banner: "banners" } as const;

/**
 * Staff-only upload for product photos, GLB models and banners.
 * Runs as the signed-in staff member so storage RLS applies too. File replacement is safe: the new file
 * is uploaded and linked first; the old file is removed only afterwards.
 */
export async function POST(request: NextRequest) {
  const ctx = await getAdminCtx("staff");
  if (!ctx) return NextResponse.json({ error: "Not allowed." }, { status: 403 });
  if (!rateLimit(`adminupload:${ctx.userId}`, 60, 10 * 60_000).ok) return NextResponse.json({ error: "Too many uploads. Slow down." }, { status: 429 });

  const form = await request.formData().catch(() => null);
  const file = form?.get("file");
  const kind = String(form?.get("kind") ?? "");
  const targetId = String(form?.get("target_id") ?? "");
  if (!form || !(file instanceof File) || !(kind in KINDS)) return NextResponse.json({ error: "Bad request." }, { status: 400 });
  if (!z.uuid().safeParse(targetId).success) return NextResponse.json({ error: "Missing target." }, { status: 400 });

  const bucket = KINDS[kind as keyof typeof KINDS];
  const bytes = new Uint8Array(await file.arrayBuffer());
  const check = validateUpload(bucket, { name: file.name, size: file.size, bytes });
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: 415 });

  const path = `${targetId}/${crypto.randomUUID()}.${check.ext}`;
  const contentType = kind === "model" ? "model/gltf-binary" : check.mime;
  const up = await ctx.supabase.storage.from(bucket).upload(path, bytes, { contentType, upsert: false });
  if (up.error) return NextResponse.json({ error: "Upload failed. Please try again." }, { status: 500 });

  const cleanup = () => ctx.supabase.storage.from(bucket).remove([path]);

  if (kind === "image") {
    const { count } = await ctx.supabase.from("product_images").select("id", { count: "exact", head: true }).eq("product_id", targetId);
    if ((count ?? 0) >= 12) { await cleanup(); return NextResponse.json({ error: "A product can have at most 12 images." }, { status: 400 }); }
    const alt = String(form.get("alt") ?? "").slice(0, 200);
    const { error } = await ctx.supabase.from("product_images").insert({ product_id: targetId, storage_path: path, alt_text: alt, sort_order: count ?? 0 });
    if (error) { await cleanup(); return NextResponse.json({ error: "Could not attach the image to the product." }, { status: 400 }); }
    await audit(ctx, "image.upload", "product", targetId, { path });
  } else if (kind === "model") {
    const { data: old } = await ctx.supabase.from("product_models").select("storage_path").eq("product_id", targetId).maybeSingle();
    const { error } = await ctx.supabase.from("product_models").upsert({ product_id: targetId, storage_path: path, file_size_bytes: file.size }, { onConflict: "product_id" });
    if (error) { await cleanup(); return NextResponse.json({ error: "Could not attach the model to the product." }, { status: 400 }); }
    if (old?.storage_path) await ctx.supabase.storage.from(bucket).remove([old.storage_path as string]);
    await audit(ctx, "model.upload", "product", targetId, { path, bytes: file.size });
  } else {
    const { data: old } = await ctx.supabase.from("banners").select("image_path").eq("id", targetId).maybeSingle();
    const { error } = await ctx.supabase.from("banners").update({ image_path: path }).eq("id", targetId);
    if (error) { await cleanup(); return NextResponse.json({ error: "Could not attach the image to the banner." }, { status: 400 }); }
    if (old?.image_path) await ctx.supabase.storage.from(bucket).remove([old.image_path as string]);
    await audit(ctx, "banner.image", "banner", targetId, { path });
  }
  return NextResponse.json({ ok: true, path });
}
