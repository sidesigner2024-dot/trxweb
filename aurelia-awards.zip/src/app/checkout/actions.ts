"use server";
import { checkoutSchema, quoteSchema } from "@/lib/validation";
import { describeDbError } from "@/lib/db-errors";
import { rateLimit } from "@/lib/rate-limit";
import { createClient } from "@/lib/supabase/server";

type Line = { product_id: string; variant_id?: string | null; qty: number; customization?: unknown };
const toDbItems = (items: Line[]) =>
  items.map((i) => ({ product_id: i.product_id, variant_id: i.variant_id ?? null, qty: i.qty, customization: i.customization ?? null }));

export type Quote = {
  lines: { product_id: string; name: string; variant_name: string | null; unit_price: number; qty: number; line_total: number }[];
  subtotal: number; discount: number; shipping: number; total: number; coupon_code: string | null; zone: string;
};

/** Server-calculated totals for display. The same SQL pricing function runs again when the order is placed. */
export async function quoteCheckout(input: unknown): Promise<{ ok: true; quote: Quote } | { ok: false; error: string }> {
  const parsed = quoteSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Your cart could not be read. Please refresh the page." };
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { ok: false, error: "Please sign in to continue." };
  if (!rateLimit(`quote:${auth.user.id}`, 30, 60_000).ok) return { ok: false, error: "Too many requests. Please wait a moment." };

  const { items, coupon_code, district } = parsed.data;
  const { data, error } = await supabase.rpc("quote_order", {
    p_items: toDbItems(items), p_coupon: coupon_code ?? null, p_district: district ?? "",
  });
  if (error) return { ok: false, error: describeDbError(error.message) };
  const q = data as Record<string, unknown>;
  return {
    ok: true,
    quote: {
      lines: (q.lines as Record<string, unknown>[]).map((l) => ({
        product_id: l.product_id as string, name: l.name as string, variant_name: (l.variant_name as string | null) ?? null,
        unit_price: Number(l.unit_price), qty: Number(l.qty), line_total: Number(l.line_total),
      })),
      subtotal: Number(q.subtotal), discount: Number(q.discount), shipping: Number(q.shipping), total: Number(q.total),
      coupon_code: (q.coupon_code as string | null) ?? null, zone: q.zone as string,
    },
  };
}

export async function placeOrder(input: unknown): Promise<
  { ok: true; orderNumber: string; orderId: string } | { ok: false; error: string; fieldErrors?: Record<string, string[]> }
> {
  const parsed = checkoutSchema.safeParse(input);
  if (!parsed.success) {
    const fe = parsed.error.flatten((i) => i.message).fieldErrors as Record<string, string[]>;
    return { ok: false, error: "Please check the highlighted details.", fieldErrors: fe };
  }
  const supabase = await createClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { ok: false, error: "Please sign in to place your order." };
  if (!rateLimit(`order:${auth.user.id}`, 10, 60_000).ok) return { ok: false, error: "Too many attempts. Please wait a minute and try again." };

  const v = parsed.data;
  const { data, error } = await supabase.rpc("place_order", {
    p_payload: {
      idempotency_key: v.idempotency_key,
      customer_name: v.customer_name,
      customer_phone: v.customer_phone,
      customer_email: v.customer_email || null,
      payment_method: v.payment_method,
      coupon_code: v.coupon_code || null,
      notes: v.notes || null,
      address: v.address,
      items: toDbItems(v.items),
    },
  });
  if (error) return { ok: false, error: describeDbError(error.message) };
  const r = data as { order_id: string; order_number: string };
  return { ok: true, orderNumber: r.order_number, orderId: r.order_id };
}
