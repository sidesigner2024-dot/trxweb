import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Order received", robots: { index: false } };

export default async function SuccessPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order } = await searchParams;
  const safe = order && /^AW-\d{3,10}$/.test(order) ? order : null;
  return (
    <div className="mx-auto max-w-xl px-4 py-20 text-center">
      <h1 className="text-4xl">Thank you</h1>
      {safe ? (
        <p className="mt-4 text-ink-soft">Your order <strong>{safe}</strong> has been placed. We will confirm it shortly. Payment is collected on delivery.</p>
      ) : (
        <p className="mt-4 text-ink-soft">Your order has been placed.</p>
      )}
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/account/orders" className="btn btn-primary">View my orders</Link>
        <Link href="/products" className="btn btn-ghost">Keep shopping</Link>
      </div>
    </div>
  );
}
