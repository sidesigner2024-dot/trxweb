import type { Metadata } from "next";
import { getSessionUser } from "@/lib/data";
import { CheckoutForm } from "@/components/checkout/checkout-form";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Checkout", robots: { index: false } };

export default async function CheckoutPage() {
  const user = await getSessionUser();
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <h1 className="mb-8 text-4xl">Checkout</h1>
      <CheckoutForm defaults={{ name: user?.fullName ?? "", phone: user?.phone ?? "", email: user?.email ?? "" }} />
    </div>
  );
}
