import type { Metadata } from "next";
import { ProsePage } from "@/components/prose-page";

export const metadata: Metadata = { title: "FAQ", alternates: { canonical: "/faq" } };

const faqs: [string, string][] = [
  ["How do I pay?", "Checkout currently supports Cash on Delivery only. Online payment will appear only once a payment gateway has been set up and verified."],
  ["Can I personalise a product?", "Products marked “Personalisable” open the Customisation Studio, where you can add text and, where allowed, a logo. The preview is a guide, not an exact production proof."],
  ["Will I see my design before it is made?", "Personalised orders go to a design review. Our team may approve it or ask for changes, and you can see the status on your order page."],
  ["How do I track my order?", "Sign in and open Orders, or use Track order with your order number and the mobile number you used at checkout."],
  ["Can I cancel?", "You can cancel online while the order is still Pending. After that, please contact us."],
  ["What if the 3D view does not work on my phone?", "Every product is also available in the normal shop, and the showroom has a “Browse without 3D” option."],
];

export default function FaqPage() {
  return (
    <ProsePage title="Frequently asked questions">
      {faqs.map(([q, a]) => (
        <details key={q} className="card p-4 open:shadow-md">
          <summary className="cursor-pointer font-medium text-ink">{q}</summary>
          <p className="mt-2">{a}</p>
        </details>
      ))}
    </ProsePage>
  );
}
