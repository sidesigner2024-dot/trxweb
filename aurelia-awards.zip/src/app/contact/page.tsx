import type { Metadata } from "next";
import { ContactForm } from "@/components/contact-form";
import { getSettings } from "@/lib/data";
import { publicEnv } from "@/lib/env";

// Live data and per-user content: never prerender at build time.
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Contact us", alternates: { canonical: "/contact" } };

export default async function ContactPage() {
  const s = await getSettings();
  const c = s.contact ?? {};
  const wa = (c.whatsapp || publicEnv.whatsappNumber || "").replace(/\D/g, "");
  const items: [string, string | null][] = [["Phone", c.phone || null], ["Email", c.email || null], ["Address", c.address || null]];
  return (
    <div className="mx-auto grid max-w-5xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-2">
      <div>
        <h1 className="text-4xl">Contact us</h1>
        <dl className="mt-6 space-y-3 text-sm">
          {items.filter(([, v]) => v).map(([k, v]) => <div key={k}><dt className="text-ink-soft">{k}</dt><dd>{v}</dd></div>)}
        </dl>
        {wa && <a className="btn btn-primary mt-6" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a>}
        {!wa && !c.phone && !c.email && <p className="mt-6 text-sm text-ink-soft">Use the form to send us a message.</p>}
      </div>
      <ContactForm />
    </div>
  );
}
