"use server";
import { headers } from "next/headers";
import { createAdminClient } from "@/lib/supabase/admin";
import { isSupabaseConfigured } from "@/lib/env";
import { contactSchema } from "@/lib/validation";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export type ContactState = { ok?: boolean; error?: string } | undefined;

export async function sendContact(_: ContactState, form: FormData): Promise<ContactState> {
  if (!isSupabaseConfigured() || !process.env.SUPABASE_SERVICE_ROLE_KEY) return { error: "The contact form is not available yet. Please use WhatsApp or phone." };
  const parsed = contactSchema.safeParse(Object.fromEntries(form));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Please check your message." };
  if (!rateLimit(`contact:${clientIp(await headers())}`, 5, 60 * 60_000).ok) return { error: "Too many messages. Please try again later." };
  const { website: _h, email, phone, subject, ...rest } = parsed.data;
  void _h;
  const db = createAdminClient();
  const { error } = await db.from("contact_messages").insert({ ...rest, email: email || null, phone: phone || null, subject: subject || null });
  if (error) return { error: "We could not send your message. Please try again." };
  await db.from("notifications").insert({ audience: "staff", title: "New contact message", body: rest.name, link: "/admin/messages" });
  return { ok: true };
}
