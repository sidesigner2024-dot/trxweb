export function NotConfigured({ what = "the store" }: { what?: string }) {
  return (
    <div role="status" className="card mx-auto max-w-xl p-8 text-center">
      <h2 className="text-2xl">Not connected yet</h2>
      <p className="mt-3 text-ink-soft">
        {`The database for ${what} has not been connected. Add the Supabase keys from `}
        <code className="rounded bg-champagne/50 px-1">.env.example</code>
        {" and run the migrations (see README)."}
      </p>
    </div>
  );
}
