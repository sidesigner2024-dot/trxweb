import { ORDER_STATUS_LABELS } from "@/lib/format";

const FLOW = ["pending", "confirmed", "customization_review", "production", "ready_to_ship", "shipped", "delivered"];

export function OrderTimeline({ status }: { status: string }) {
  if (status === "cancelled" || status === "refunded") {
    return <p className="rounded-lg bg-champagne/50 px-4 py-3 text-sm">Status: <strong>{ORDER_STATUS_LABELS[status]}</strong></p>;
  }
  const idx = FLOW.indexOf(status);
  return (
    <ol className="grid gap-2 text-sm sm:grid-cols-7" aria-label="Order progress">
      {FLOW.map((s, i) => (
        <li key={s} aria-current={i === idx ? "step" : undefined}
          className={`rounded-lg px-2 py-2 text-center ${i <= idx ? "bg-gold/30 text-ink" : "bg-champagne/30 text-ink-soft"} ${i === idx ? "font-medium ring-1 ring-gold-deep" : ""}`}>
          {ORDER_STATUS_LABELS[s]}
        </li>
      ))}
    </ol>
  );
}
