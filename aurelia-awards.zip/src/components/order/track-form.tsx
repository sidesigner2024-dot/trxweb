"use client";
import { useState, useTransition } from "react";
import { trackOrder, type TrackResult } from "@/app/track/actions";
import { OrderTimeline } from "@/components/order/order-timeline";
import { ORDER_STATUS_LABELS } from "@/lib/format";

export function TrackForm() {
  const [result, setResult] = useState<TrackResult | null>(null);
  const [pending, start] = useTransition();
  return (
    <div className="space-y-6">
      <form className="card space-y-4 p-5" onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        start(async () => setResult(await trackOrder({ order_number: f.get("order_number"), phone: f.get("phone") })));
      }}>
        <div><label className="label" htmlFor="order_number">Order number</label><input id="order_number" name="order_number" placeholder="AW-1001" className="field" required /></div>
        <div><label className="label" htmlFor="phone">Mobile number used at checkout</label><input id="phone" name="phone" inputMode="tel" className="field" required /></div>
        <button className="btn btn-primary" disabled={pending}>{pending ? "Looking up…" : "Track order"}</button>
      </form>
      {result && !result.ok && <p role="alert" className="text-danger">{result.error}</p>}
      {result?.ok && (
        <div className="card space-y-4 p-5" aria-live="polite">
          <h2 className="text-xl">Order {result.order.number}</h2>
          <OrderTimeline status={result.order.status} />
          {result.order.trackingNumber && <p className="text-sm">Courier: {result.order.carrier ?? "—"} · Tracking: {result.order.trackingUrl ? <a className="underline" href={result.order.trackingUrl} target="_blank" rel="noopener noreferrer">{result.order.trackingNumber}</a> : result.order.trackingNumber}</p>}
          <ul className="space-y-1 text-sm">{result.order.events.map((e, i) => <li key={i}>{new Date(e.at).toLocaleString("en-GB")} — {ORDER_STATUS_LABELS[e.status]}</li>)}</ul>
        </div>
      )}
    </div>
  );
}
