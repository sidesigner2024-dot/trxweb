"use client";
import { useActionState } from "react";
import { sendContact } from "@/app/contact/actions";

export function ContactForm() {
  const [state, action, pending] = useActionState(sendContact, undefined);
  if (state?.ok) return <p role="status" className="card p-6 text-ok">Thank you — your message has been sent.</p>;
  return (
    <form action={action} className="card space-y-4 p-5">
      <div className="hidden" aria-hidden="true"><label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      <div><label className="label" htmlFor="name">Name</label><input id="name" name="name" className="field" required /></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" className="field" /></div>
        <div><label className="label" htmlFor="phone">Phone</label><input id="phone" name="phone" inputMode="tel" className="field" /></div>
      </div>
      <div><label className="label" htmlFor="subject">Subject</label><input id="subject" name="subject" className="field" /></div>
      <div><label className="label" htmlFor="message">Message</label><textarea id="message" name="message" rows={5} className="field" required /></div>
      <p className="text-xs text-ink-soft">Please give an email or a phone number so we can reply.</p>
      {state?.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      <button className="btn btn-primary" disabled={pending}>{pending ? "Sending…" : "Send message"}</button>
    </form>
  );
}
