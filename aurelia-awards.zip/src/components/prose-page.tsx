export function ProsePage({ title, draft, children }: { title: string; draft?: boolean; children: React.ReactNode }) {
  return (
    <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-4xl">{title}</h1>
      {draft && (
        <p role="note" className="mt-4 rounded-lg border border-gold bg-champagne/40 p-3 text-sm">
          Draft text: the business owner must review and adapt this page (ideally with legal advice) before launch.
        </p>
      )}
      <div className="mt-6 space-y-4 leading-relaxed text-ink-soft [&_h2]:mt-8 [&_h2]:text-2xl [&_h2]:text-ink [&_ul]:list-disc [&_ul]:pl-5">{children}</div>
    </article>
  );
}
