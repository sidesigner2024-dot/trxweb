"use client";
import { useActionState } from "react";
import Link from "next/link";
import { requestPasswordReset, signIn, signUp, updatePassword, type AuthState } from "@/app/auth/actions";

function Feedback({ state }: { state: AuthState }) {
  if (!state) return null;
  return (
    <>
      {state.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      {state.message && <p role="status" className="text-sm text-ok">{state.message}</p>}
    </>
  );
}
const fieldErr = (s: AuthState, k: string) => s?.fieldErrors?.[k]?.[0] ? <p role="alert" className="mt-1 text-sm text-danger">{s.fieldErrors[k][0]}</p> : null;

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(signIn, undefined);
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required className="field" /></div>
      <div><label className="label" htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="current-password" required className="field" /></div>
      <Feedback state={state} />
      <button className="btn btn-primary w-full" disabled={pending}>{pending ? "Signing in…" : "Sign in"}</button>
      <p className="text-center text-sm"><Link href="/forgot-password" className="underline">Forgot password?</Link></p>
    </form>
  );
}

export function RegisterForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(signUp, undefined);
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <div><label className="label" htmlFor="full_name">Full name</label><input id="full_name" name="full_name" autoComplete="name" required className="field" />{fieldErr(state, "full_name")}</div>
      <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required className="field" />{fieldErr(state, "email")}</div>
      <div><label className="label" htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="new-password" minLength={8} required className="field" />{fieldErr(state, "password")}</div>
      <Feedback state={state} />
      <button className="btn btn-primary w-full" disabled={pending}>{pending ? "Creating account…" : "Create account"}</button>
    </form>
  );
}

export function ForgotForm() {
  const [state, action, pending] = useActionState(requestPasswordReset, undefined);
  return (
    <form action={action} className="space-y-4">
      <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required className="field" /></div>
      <Feedback state={state} />
      <button className="btn btn-primary w-full" disabled={pending}>{pending ? "Sending…" : "Send reset link"}</button>
    </form>
  );
}

export function ResetForm() {
  const [state, action, pending] = useActionState(updatePassword, undefined);
  return (
    <form action={action} className="space-y-4">
      <div><label className="label" htmlFor="password">New password</label><input id="password" name="password" type="password" autoComplete="new-password" minLength={8} required className="field" /></div>
      <Feedback state={state} />
      <button className="btn btn-primary w-full" disabled={pending}>{pending ? "Saving…" : "Set new password"}</button>
    </form>
  );
}
