export function AuthShell({ title, children, footer }: { title: string; children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className="card p-6 sm:p-8">
        <h1 className="mb-6 text-3xl">{title}</h1>
        {children}
      </div>
      {footer && <p className="mt-4 text-center text-sm text-ink-soft">{footer}</p>}
    </div>
  );
}
