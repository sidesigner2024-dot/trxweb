"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { z } from "zod";
import { cartActions, useCart } from "@/lib/cart-store";
import { checkoutSchema } from "@/lib/validation";
import { BD_DISTRICTS } from "@/lib/districts";
import { formatBDT } from "@/lib/format";
import { placeOrder, quoteCheckout, type Quote } from "@/app/checkout/actions";

const formSchema = checkoutSchema.omit({ idempotency_key: true, items: true, payment_method: true });
type FormValues = z.input<typeof formSchema>;

/** One key per checkout attempt, kept in sessionStorage so a retry or double-click returns the same order. */
function idempotencyKey(): string {
  try {
    const existing = sessionStorage.getItem("aurelia.idem");
    if (existing) return existing;
    const fresh = crypto.randomUUID();
    sessionStorage.setItem("aurelia.idem", fresh);
    return fresh;
  } catch {
    return crypto.randomUUID();
  }
}

export function CheckoutForm({ defaults }: { defaults: { name: string; phone: string; email: string } }) {
  const router = useRouter();
  const lines = useCart();
  const [rawQuote, setQuote] = useState<Quote | null>(null);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [coupon, setCoupon] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState("");
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const { register, handleSubmit, control, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customer_name: defaults.name, customer_phone: defaults.phone, customer_email: defaults.email,
      address: { recipient_name: defaults.name, phone: defaults.phone, line1: "", city: "", district: "" },
    },
  });
  const district = useWatch({ control, name: "address.district" });

  const items = lines.map((l) => ({
    product_id: l.productId, variant_id: l.variantId, qty: l.qty,
    customization: l.customization ? { lines: l.customization.lines, ...(l.customization.logo_path ? { logo_path: l.customization.logo_path } : {}) } : null,
  }));
  const itemsSig = JSON.stringify(items);
  const quote = district && items.length > 0 ? rawQuote : null;

  useEffect(() => {
    if (items.length === 0 || !district) return;
    let cancelled = false;
    quoteCheckout({ items, coupon_code: appliedCoupon || undefined, district }).then((r) => {
      if (cancelled) return;
      if (r.ok) { setQuote(r.quote); setQuoteError(null); } else { setQuote(null); setQuoteError(r.error); }
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsSig, district, appliedCoupon]);

  async function applyCoupon() {
    const code = coupon.trim();
    if (!code) { setAppliedCoupon(""); return; }
    const r = await quoteCheckout({ items, coupon_code: code, district: district || "" });
    if (r.ok) { setQuote(r.quote); setQuoteError(null); setAppliedCoupon(code); } else { setQuoteError(r.error); }
  }

  const onSubmit = handleSubmit(async (values) => {
    setSubmitError(null);
    setBusy(true);
    try {
      const r = await placeOrder({ ...values, idempotency_key: idempotencyKey(), payment_method: "cod", coupon_code: appliedCoupon || undefined, items });
      if (r.ok) {
        sessionStorage.removeItem("aurelia.idem");
        cartActions.clear();
        router.push(`/checkout/success?order=${encodeURIComponent(r.orderNumber)}`);
      } else {
        setSubmitError(r.error);
      }
    } catch {
      setSubmitError("We could not reach the server. Your order was not placed — please try again.");
    } finally {
      setBusy(false);
    }
  });

  if (lines.length === 0) {
    return <div className="card p-10 text-center"><p className="text-ink-soft">Your cart is empty.</p><Link href="/products" className="btn btn-primary mt-6">Browse products</Link></div>;
  }

  const err = (m?: { message?: string }) => m?.message ? <p role="alert" className="mt-1 text-sm text-danger">{m.message}</p> : null;

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <div className="space-y-8">
        <fieldset className="card space-y-4 p-5">
          <legend className="px-1 text-xl">Contact</legend>
          <div><label className="label" htmlFor="customer_name">Full name</label><input id="customer_name" className="field" autoComplete="name" {...register("customer_name")} />{err(errors.customer_name)}</div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="customer_phone">Mobile number</label><input id="customer_phone" inputMode="tel" autoComplete="tel" className="field" {...register("customer_phone")} />{err(errors.customer_phone)}</div>
            <div><label className="label" htmlFor="customer_email">Email (optional)</label><input id="customer_email" type="email" autoComplete="email" className="field" {...register("customer_email")} />{err(errors.customer_email)}</div>
          </div>
        </fieldset>

        <fieldset className="card space-y-4 p-5">
          <legend className="px-1 text-xl">Delivery address</legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="a_name">Recipient</label><input id="a_name" className="field" {...register("address.recipient_name")} />{err(errors.address?.recipient_name)}</div>
            <div><label className="label" htmlFor="a_phone">Recipient mobile</label><input id="a_phone" inputMode="tel" className="field" {...register("address.phone")} />{err(errors.address?.phone)}</div>
          </div>
          <div><label className="label" htmlFor="a_line1">Address</label><input id="a_line1" autoComplete="street-address" className="field" {...register("address.line1")} />{err(errors.address?.line1)}</div>
          <div><label className="label" htmlFor="a_line2">Landmark / apartment (optional)</label><input id="a_line2" className="field" {...register("address.line2")} /></div>
          <div className="grid gap-4 sm:grid-cols-3">
            <div><label className="label" htmlFor="a_city">Area / city</label><input id="a_city" className="field" {...register("address.city")} />{err(errors.address?.city)}</div>
            <div>
              <label className="label" htmlFor="a_district">District</label>
              <select id="a_district" className="field" {...register("address.district")}>
                <option value="">Select…</option>
                {BD_DISTRICTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
              {err(errors.address?.district)}
            </div>
            <div><label className="label" htmlFor="a_postal">Postal code</label><input id="a_postal" inputMode="numeric" className="field" {...register("address.postal_code")} /></div>
          </div>
          <div><label className="label" htmlFor="notes">Order notes (optional)</label><textarea id="notes" rows={3} className="field" {...register("notes")} /></div>
        </fieldset>

        <fieldset className="card p-5">
          <legend className="px-1 text-xl">Payment</legend>
          <label className="flex items-start gap-3">
            <input type="radio" checked readOnly className="mt-1 accent-[#9c8355]" />
            <span><strong>Cash on Delivery</strong><br /><span className="text-sm text-ink-soft">Pay in cash when your order arrives. Online payment is not available yet.</span></span>
          </label>
        </fieldset>
      </div>

      <aside className="card h-fit space-y-4 p-5">
        <h2 className="text-xl">Order summary</h2>
        <ul className="space-y-2 text-sm">
          {(quote?.lines ?? lines.map((l) => ({ product_id: l.productId, name: l.name, variant_name: null, qty: l.qty, line_total: null as number | null }))).map((l, i) => (
            <li key={i} className="flex justify-between gap-3"><span>{l.name}{l.variant_name ? ` — ${l.variant_name}` : ""} × {l.qty}</span><span>{l.line_total != null ? formatBDT(l.line_total) : ""}</span></li>
          ))}
        </ul>
        <div className="flex gap-2">
          <label htmlFor="coupon" className="sr-only">Coupon code</label>
          <input id="coupon" className="field uppercase" placeholder="Coupon code" value={coupon} onChange={(e) => setCoupon(e.target.value)} />
          <button type="button" className="btn btn-ghost" onClick={applyCoupon}>Apply</button>
        </div>
        {quoteError && <p role="alert" className="text-sm text-danger">{quoteError}</p>}
        {!district && <p className="text-sm text-ink-soft">Choose your district to see delivery charges.</p>}
        {quote && (
          <dl className="space-y-1 border-t border-champagne pt-3 text-sm" aria-live="polite">
            <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatBDT(quote.subtotal)}</dd></div>
            {quote.discount > 0 && <div className="flex justify-between text-ok"><dt>Discount ({quote.coupon_code})</dt><dd>−{formatBDT(quote.discount)}</dd></div>}
            <div className="flex justify-between"><dt>Delivery ({quote.zone})</dt><dd>{quote.shipping === 0 ? "Free" : formatBDT(quote.shipping)}</dd></div>
            <div className="flex justify-between border-t border-champagne pt-2 text-base font-medium"><dt>Total</dt><dd>{formatBDT(quote.total)}</dd></div>
          </dl>
        )}
        {submitError && <p role="alert" className="text-sm text-danger">{submitError}</p>}
        <button className="btn btn-primary w-full" type="submit" disabled={busy || !quote}>{busy ? "Placing order…" : "Place order"}</button>
        <p className="text-xs text-ink-soft">The final total is calculated on our server when you place the order.</p>
      </aside>
    </form>
  );
}
