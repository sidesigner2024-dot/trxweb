"use client";
import { useState, useTransition } from "react";
import { setRole } from "@/app/admin/content-actions";

export function RoleSelect({ userId, role }: { userId: string; role: "customer" | "staff" | "admin" }) {
  const [value, setValue] = useState(role);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <span>
      <select aria-label="Role" className="field !min-h-9 !w-32 !py-1" value={value} disabled={pending}
        onChange={(e) => {
          const next = e.target.value as typeof role;
          if (!confirm(`Change this person's role to ${next}?`)) return;
          start(async () => { const r = await setRole(userId, next); if (r?.error) setError(r.error); else { setError(null); setValue(next); } });
        }}>
        <option value="customer">customer</option><option value="staff">staff</option><option value="admin">admin</option>
      </select>
      {error && <span role="alert" className="ml-2 text-xs text-danger">{error}</span>}
    </span>
  );
}
