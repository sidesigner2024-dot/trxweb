"use client";
import { ActionForm } from "@/components/admin/action-form";
import { saveProduct } from "@/app/admin/products/actions";

type P = Partial<{
  id: string; sku: string; name: string; slug: string; description: string; category_id: string | null;
  price_bdt: number | string; discount_price_bdt: number | string | null; material: string | null; dimensions: string | null;
  weight_grams: number | null; stock_qty: number; track_stock: boolean; production_days: number | null;
  is_customizable: boolean; allows_logo: boolean; is_featured: boolean; is_active: boolean; is_sample: boolean;
  seo_title: string | null; seo_description: string | null;
}>;

export function ProductForm({ product, categories }: { product?: P; categories: { id: string; name: string }[] }) {
  const p = product ?? {};
  const field = (name: string, label: string, props: React.InputHTMLAttributes<HTMLInputElement> = {}) => (
    <div><label className="label" htmlFor={name}>{label}</label><input id={name} name={name} className="field" defaultValue={(p as Record<string, unknown>)[name] as string ?? ""} {...props} /></div>
  );
  const check = (name: keyof P, label: string, def = false) => (
    <label className="flex items-center gap-2 text-sm"><input type="checkbox" name={name} defaultChecked={(p[name] as boolean | undefined) ?? def} className="size-4 accent-[#9c8355]" />{label}</label>
  );
  return (
    <ActionForm action={saveProduct} submitLabel={p.id ? "Save product" : "Create product"} className="card space-y-5 p-5">
      {p.id && <input type="hidden" name="id" value={p.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        {field("name", "Name", { required: true, maxLength: 160 })}
        {field("sku", "SKU", { required: true, maxLength: 60 })}
        {field("slug", "URL slug (blank = from name)", { maxLength: 80, pattern: "[a-z0-9]+(-[a-z0-9]+)*" })}
        <div><label className="label" htmlFor="category_id">Category</label>
          <select id="category_id" name="category_id" className="field" defaultValue={p.category_id ?? ""}><option value="">None</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
      </div>
      <div><label className="label" htmlFor="description">Description</label><textarea id="description" name="description" rows={5} className="field" defaultValue={p.description ?? ""} /></div>
      <div className="grid gap-4 sm:grid-cols-3">
        {field("price_bdt", "Price (BDT)", { type: "number", min: 0, step: "0.01", required: true })}
        {field("discount_price_bdt", "Discount price (BDT)", { type: "number", min: 0, step: "0.01" })}
        {field("stock_qty", "Stock quantity", { type: "number", min: 0, step: 1 })}
        {field("material", "Material")}
        {field("dimensions", "Size / dimensions")}
        {field("weight_grams", "Weight (grams)", { type: "number", min: 0, step: 1 })}
        {field("production_days", "Production time (days)", { type: "number", min: 0, step: 1 })}
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {check("track_stock", "Track stock (untick for made-to-order)", true)}
        {check("is_active", "Visible in the shop", true)}
        {check("is_featured", "Featured")}
        {check("is_customizable", "Can be personalised")}
        {check("allows_logo", "Accepts a customer logo")}
        {check("is_sample", "Sample content (shows a “Sample” label)")}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {field("seo_title", "SEO title (max 70)", { maxLength: 70 })}
        {field("seo_description", "SEO description (max 200)", { maxLength: 200 })}
      </div>
    </ActionForm>
  );
}
