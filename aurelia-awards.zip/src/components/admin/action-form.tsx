"use client";
import { useActionState, useTransition, useState } from "react";
import type { Result } from "@/lib/admin";

/** Form bound to a server action; shows its error/success message inline. */
export function ActionForm({
  action, children, submitLabel = "Save", className = "space-y-4", danger = false, confirmText, hideSubmit = false,
}: {
  action: (prev: Result, form: FormData) => Promise<Result>;
  children?: React.ReactNode; submitLabel?: string; className?: string; danger?: boolean; confirmText?: string; hideSubmit?: boolean;
}) {
  const [state, formAction, pending] = useActionState(action, undefined);
  return (
    <form action={formAction} className={className} onSubmit={(e) => { if (confirmText && !confirm(confirmText)) e.preventDefault(); }}>
      {children}
      {state?.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      {state?.ok && <p role="status" className="text-sm text-ok">Saved.</p>}
      {!hideSubmit && <button className={`btn ${danger ? "btn-ghost !border-danger !text-danger" : "btn-primary"}`} disabled={pending}>{pending ? "Working…" : submitLabel}</button>}
    </form>
  );
}

/** One-click server action (e.g. approve, delete) with confirmation and error display. */
export function ActionButton({
  action, label, confirmText, danger = false,
}: { action: () => Promise<Result>; label: string; confirmText?: string; danger?: boolean }) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  return (
    <span>
      <button type="button" disabled={pending} className={`text-sm underline ${danger ? "text-danger" : ""}`}
        onClick={() => { if (confirmText && !confirm(confirmText)) return; start(async () => { const r = await action(); setError(r?.error ?? null); }); }}>
        {pending ? "…" : label}
      </button>
      {error && <span role="alert" className="ml-2 text-xs text-danger">{error}</span>}
    </span>
  );
}
