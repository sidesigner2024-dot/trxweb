"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

/** File picker with a real progress bar (XHR) and clear failure messages. Refreshes the page on success. */
export function Uploader({
  kind, targetId, accept, label, hint, withAlt = false,
}: { kind: "image" | "model" | "banner"; targetId: string; accept: string; label: string; hint?: string; withAlt?: boolean }) {
  const router = useRouter();
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [alt, setAlt] = useState("");
  const id = `up-${kind}-${targetId}`;

  function send(file: File | undefined, input: HTMLInputElement) {
    if (!file) return;
    setError(null); setDone(false); setProgress(0);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/admin/upload");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) setProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onerror = () => { setProgress(null); setError("Network error. Please try again."); };
    xhr.onload = () => {
      setProgress(null);
      let body: { ok?: boolean; error?: string } = {};
      try { body = JSON.parse(xhr.responseText); } catch { /* keep default */ }
      if (xhr.status >= 200 && xhr.status < 300 && body.ok) { setDone(true); setAlt(""); input.value = ""; router.refresh(); }
      else setError(body.error ?? "Upload failed.");
    };
    const fd = new FormData();
    fd.append("file", file); fd.append("kind", kind); fd.append("target_id", targetId); if (withAlt) fd.append("alt", alt);
    xhr.send(fd);
  }

  return (
    <div className="space-y-2">
      <label htmlFor={id} className="label">{label}</label>
      {withAlt && <input aria-label="Description of the image (alt text)" className="field" placeholder="Describe the image (for accessibility)" value={alt} onChange={(e) => setAlt(e.target.value)} maxLength={200} />}
      <input id={id} type="file" accept={accept} className="field !py-2" disabled={progress !== null} onChange={(e) => send(e.target.files?.[0], e.target)} />
      {hint && <p className="text-xs text-ink-soft">{hint}</p>}
      {progress !== null && <div role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} className="h-1.5 overflow-hidden rounded bg-champagne"><div className="h-full bg-gold-deep" style={{ width: `${progress}%` }} /></div>}
      {error && <p role="alert" className="text-sm text-danger">{error}</p>}
      {done && <p role="status" className="text-sm text-ok">Uploaded.</p>}
    </div>
  );
}
