"use client";
import { useEffect, useMemo } from "react";
import { MeshReflectorMaterial } from "@react-three/drei";
import { ROOM } from "./types";
import { createMarbleTexture } from "./textures";

const W = ROOM.width, D = ROOM.depth, H = ROOM.height;

export function Room({ quality }: { quality: "low" | "high" }) {
  const marble = useMemo(() => createMarbleTexture(quality === "high" ? 1024 : 512, 4), [quality]);
  useEffect(() => () => marble.dispose(), [marble]);

  const wall = <meshStandardMaterial color="#f6f2ea" roughness={0.92} />;
  const trim = <meshStandardMaterial color="#e8dfd0" roughness={0.6} />;
  const gold = <meshStandardMaterial color="#c5aa7a" roughness={0.3} metalness={0.8} />;

  return (
    <group>
      {/* floor */}
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[W, D]} />
        {quality === "high" ? (
          <MeshReflectorMaterial map={marble} roughness={0.55} metalness={0} resolution={512} blur={[300, 80]} mixBlur={1} mixStrength={0.6}
            mirror={0.35} depthScale={0} color="#ffffff" />
        ) : (
          <meshStandardMaterial map={marble} roughness={0.22} metalness={0.05} />
        )}
      </mesh>

      {/* ceiling with recessed warm cove */}
      <mesh position={[0, H, 0]} rotation-x={Math.PI / 2}>
        <planeGeometry args={[W, D]} />
        <meshStandardMaterial color="#fbf9f4" roughness={1} />
      </mesh>
      <mesh position={[0, H - 0.12, 0]}>
        <boxGeometry args={[W - 3, 0.24, D - 3]} />
        <meshStandardMaterial color="#f3eee5" roughness={1} />
      </mesh>
      <mesh position={[0, H - 0.26, 0]} rotation-x={Math.PI / 2}>
        <planeGeometry args={[W - 3.4, D - 3.4]} />
        <meshStandardMaterial color="#fff6e4" emissive="#ffe9c0" emissiveIntensity={0.55} />
      </mesh>

      {/* walls */}
      <mesh position={[0, H / 2, -D / 2]}><planeGeometry args={[W, H]} />{wall}</mesh>
      <mesh position={[0, H / 2, D / 2]} rotation-y={Math.PI}><planeGeometry args={[W, H]} />{wall}</mesh>
      <mesh position={[-W / 2, H / 2, 0]} rotation-y={Math.PI / 2}><planeGeometry args={[D, H]} />{wall}</mesh>
      <mesh position={[W / 2, H / 2, 0]} rotation-y={-Math.PI / 2}><planeGeometry args={[D, H]} />{wall}</mesh>

      {/* wainscot rail + skirting on all walls */}
      {([
        [0, -D / 2 + 0.02, 0, W],
        [0, D / 2 - 0.02, Math.PI, W],
        [-W / 2 + 0.02, 0, Math.PI / 2, D],
        [W / 2 - 0.02, 0, -Math.PI / 2, D],
      ] as const).map(([x, z, ry, len], i) => (
        <group key={i} position={[x, 0, z]} rotation-y={ry}>
          <mesh position={[0, 0.09, 0.02]}><boxGeometry args={[len, 0.18, 0.04]} />{trim}</mesh>
          <mesh position={[0, 1.1, 0.015]}><boxGeometry args={[len, 0.05, 0.03]} />{gold}</mesh>
        </group>
      ))}

      {/* back wall feature panel (champagne) */}
      <mesh position={[0, 2.1, -D / 2 + 0.03]}><boxGeometry args={[7, 2.8, 0.05]} /><meshStandardMaterial color="#e8dfd0" roughness={0.85} /></mesh>
    </group>
  );
}
