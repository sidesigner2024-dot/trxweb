"use client";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Billboard, Edges, useGLTF, useTexture } from "@react-three/drei";
import * as THREE from "three";
import { baseHeight, PEDESTAL_HEIGHT, type ShowroomItem } from "./types";

/** Real GLB model, normalised to a consistent display size and sat on its base. */
function ModelContent({ url, scale }: { url: string; scale: number }) {
  const { scene } = useGLTF(url);
  const { object, factor } = useMemo(() => {
    const clone = scene.clone(true);
    const box = new THREE.Box3().setFromObject(clone);
    const size = box.getSize(new THREE.Vector3());
    const max = Math.max(size.x, size.y, size.z) || 1;
    const f = (0.7 / max) * scale;
    const center = box.getCenter(new THREE.Vector3());
    clone.position.set(-center.x, -box.min.y, -center.z);
    clone.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) { o.castShadow = true; o.receiveShadow = false; }
    });
    return { object: clone, factor: f };
  }, [scene, scale]);
  return <group scale={factor}><primitive object={object} /></group>;
}

/** Photo plaque. Deliberately looks like a framed photograph, not a 3D object. */
function PhotoContent({ url, alt }: { url: string; alt: string }) {
  const tex = useTexture(url);
  useEffect(() => { tex.colorSpace = THREE.SRGBColorSpace; }, [tex]);
  const aspect = tex.image ? (tex.image as HTMLImageElement).width / (tex.image as HTMLImageElement).height : 1;
  const h = 0.62, w = Math.min(0.9, h * aspect);
  return (
    <group position={[0, h / 2 + 0.04, 0]} name={alt}>
      <mesh castShadow><boxGeometry args={[w + 0.06, h + 0.06, 0.03]} /><meshStandardMaterial color="#c5aa7a" metalness={0.7} roughness={0.35} /></mesh>
      <mesh position={[0, 0, 0.017]}><planeGeometry args={[w, h]} /><meshBasicMaterial map={tex} toneMapped={false} /></mesh>
    </group>
  );
}

function EmptyPlaque() {
  return (
    <mesh position={[0, 0.34, 0]}><boxGeometry args={[0.5, 0.6, 0.03]} /><meshStandardMaterial color="#e8dfd0" roughness={0.8} /></mesh>
  );
}

function Content({ item }: { item: ShowroomItem }) {
  if (item.modelUrl) return <ModelContent url={item.modelUrl} scale={item.modelScale} />;
  if (item.imageUrl) return <PhotoContent url={item.imageUrl} alt={item.imageAlt} />;
  return <EmptyPlaque />;
}

function Base({ type }: { type: ShowroomItem["type"] }) {
  const stone = <meshStandardMaterial color="#f4efe6" roughness={0.45} />;
  if (type === "pedestal" || type === "cabinet") {
    return (
      <group>
        <mesh position={[0, PEDESTAL_HEIGHT / 2, 0]} castShadow receiveShadow><boxGeometry args={[0.9, PEDESTAL_HEIGHT, 0.9]} />{stone}</mesh>
        <mesh position={[0, PEDESTAL_HEIGHT + 0.015, 0]}><boxGeometry args={[0.96, 0.03, 0.96]} /><meshStandardMaterial color="#c5aa7a" metalness={0.8} roughness={0.3} /></mesh>
        {type === "cabinet" && (
          <mesh position={[0, PEDESTAL_HEIGHT + 0.65, 0]}>
            <boxGeometry args={[0.96, 1.3, 0.96]} />
            <meshPhysicalMaterial color="#ffffff" transparent opacity={0.12} roughness={0.04} metalness={0} envMapIntensity={1.2} side={THREE.DoubleSide} depthWrite={false} />
            <Edges color="#c5aa7a" />
          </mesh>
        )}
      </group>
    );
  }
  if (type === "shelf") return <mesh position={[0, -0.02, 0]} castShadow><boxGeometry args={[1, 0.04, 0.35]} /><meshStandardMaterial color="#d9cdb8" roughness={0.5} /></mesh>;
  return null; // wall mounted
}

export function DisplayItem({
  item, selected, onSelect, quality, reducedMotion,
}: { item: ShowroomItem; selected: boolean; onSelect: (id: string) => void; quality: "low" | "high"; reducedMotion: boolean }) {
  const ring = useRef<THREE.Mesh>(null);
  const [hover, setHover] = useState(false);
  const y = baseHeight(item.type, item.pos[1]);

  useEffect(() => {
    document.body.style.cursor = hover ? "pointer" : "auto";
    return () => { document.body.style.cursor = "auto"; };
  }, [hover]);

  useFrame(({ clock }) => {
    if (!ring.current || reducedMotion) return;
    ring.current.position.y = 1.15 + Math.sin(clock.elapsedTime * 1.6 + item.pos[0]) * 0.04;
  });

  return (
    <group position={[item.pos[0], item.pos[1], item.pos[2]]} rotation-y={item.rotY} scale={item.scale}>
      <Base type={item.type} />
      <group position={[0, y - item.pos[1], 0]}>
        <Suspense fallback={null}><Content item={item} /></Suspense>
      </group>
      {/* invisible hit target so thin models are easy to tap on mobile */}
      <mesh position={[0, y - item.pos[1] + 0.4, 0]} visible={false}
        onClick={(e) => { if (e.delta <= 6) { e.stopPropagation(); onSelect(item.id); } }}
        onPointerOver={(e) => { e.stopPropagation(); setHover(true); }} onPointerOut={() => setHover(false)}>
        <boxGeometry args={[1.1, 1.1, 1.1]} />
      </mesh>
      <Billboard position={[0, y - item.pos[1], 0]}>
        <mesh ref={ring} position={[0, 1.15, 0]}>
          <torusGeometry args={[0.07, 0.012, 8, 24]} />
          <meshBasicMaterial color={selected ? "#9c8355" : "#c5aa7a"} toneMapped={false} />
        </mesh>
      </Billboard>
      {quality === "high" && (
        <pointLight position={[0, y - item.pos[1] + 2.2, 0.5]} intensity={5} distance={5} decay={2} color="#fff1d6" />
      )}
    </group>
  );
}
