"use client";
import dynamic from "next/dynamic";
import Link from "next/link";
import { Component, useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { useProgress } from "@react-three/drei";
import { ProductPanel } from "./product-panel";
import type { FocusRequest, InputState } from "./scene";
import type { ShowroomRoom } from "./types";

const Scene = dynamic(() => import("./scene"), { ssr: false });

class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(err: unknown) { console.error("Showroom failed", err); }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

function webglAvailable(): boolean {
  try {
    const c = document.createElement("canvas");
    return Boolean(c.getContext("webgl2") || c.getContext("webgl"));
  } catch { return false; }
}

function usePrefersReducedMotion() {
  const [r, setR] = useState(false);
  useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    const u = () => setR(m.matches);
    u(); m.addEventListener("change", u);
    return () => m.removeEventListener("change", u);
  }, []);
  return r;
}

function Fallback({ reason }: { reason: string }) {
  return (
    <div role="alert" className="card mx-auto max-w-xl p-8 text-center">
      <h2 className="text-2xl">The 3D showroom is not available</h2>
      <p className="mt-3 text-ink-soft">{reason}</p>
      <Link href="/products" className="btn btn-primary mt-6">Browse the shop instead</Link>
    </div>
  );
}

export function ShowroomClient({ rooms }: { rooms: ShowroomRoom[] }) {
  const reduced = usePrefersReducedMotion();
  const [supported, setSupported] = useState<boolean | null>(null);
  const [quality, setQuality] = useState<"low" | "high">("low");
  const [roomId, setRoomId] = useState(rooms[0]?.id ?? "");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [focus, setFocus] = useState<FocusRequest>(null);
  const input = useRef<InputState>({ f: false, b: false, l: false, r: false });
  const nonce = useRef(0);
  const { active, progress } = useProgress();

  useEffect(() => {
    const ok = webglAvailable();
    const nav = navigator as Navigator & { deviceMemory?: number };
    const weak = (nav.deviceMemory ?? 8) <= 4 || (navigator.hardwareConcurrency ?? 8) <= 4 || window.matchMedia("(pointer: coarse)").matches;
    // Browser capability can only be read after mount; phones and weak devices start in the light mode.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setSupported(ok);
    setQuality(weak ? "low" : "high");
  }, []);

  const room = rooms.find((r) => r.id === roomId) ?? rooms[0];
  const selected = room?.items.find((i) => i.id === selectedId) ?? null;

  const select = useCallback((id: string) => { setSelectedId(id); setFocus({ id, nonce: ++nonce.current }); }, []);
  const close = useCallback(() => setSelectedId(null), []);
  const hold = (k: keyof InputState, v: boolean) => () => { input.current[k] = v; };

  if (rooms.length === 0 || !room) {
    return <Fallback reason="No showroom rooms have been set up yet. Products can still be browsed in the shop." />;
  }
  if (supported === false) return <Fallback reason="Your browser or device does not support WebGL, which the 3D view needs." />;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div className="relative h-[68dvh] min-h-[420px] overflow-hidden rounded-2xl border border-champagne bg-champagne/40">
        {supported && (
          <SceneBoundary fallback={<Fallback reason="Something went wrong while drawing the showroom." />}>
            <Scene key={`${room.id}-${quality}`} items={room.items} selectedId={selectedId} onSelect={select} quality={quality} reducedMotion={reduced} input={input} focus={focus} />
          </SceneBoundary>
        )}
        {(supported === null || active) && (
          <div role="status" className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-ivory/90">
            <p className="font-serif text-2xl">Opening the gallery…</p>
            <div className="h-1 w-48 overflow-hidden rounded bg-champagne"><div className="h-full bg-gold-deep transition-[width]" style={{ width: `${Math.max(8, progress)}%` }} /></div>
          </div>
        )}

        <div className="pointer-events-none absolute left-3 top-3 z-10 hidden max-w-[55%] sm:block rounded-lg bg-ivory/80 px-3 py-2 text-xs text-ink-soft backdrop-blur">
          Drag to look · W A S D / arrows to walk · tap the floor to move · tap a gold ring to inspect
        </div>
        <div className="absolute right-3 top-3 z-10 flex gap-2">
          <button type="button" className="btn btn-ghost !min-h-9 !bg-ivory/80 !px-3 !py-1 text-xs" onClick={() => setFocus({ reset: true, nonce: ++nonce.current })}>Reset view</button>
          <button type="button" className="btn btn-ghost !min-h-9 !bg-ivory/80 !px-3 !py-1 text-xs" aria-pressed={quality === "low"} onClick={() => setQuality((q) => (q === "low" ? "high" : "low"))}>
            {quality === "low" ? "Quality: Light" : "Quality: Full"}
          </button>
        </div>

        {/* on-screen walking pad for touch devices */}
        <div className="absolute bottom-4 left-4 z-10 grid grid-cols-3 gap-1 sm:hidden" role="group" aria-label="Walk controls">
          {([["", ""], ["f", "▲"], ["", ""], ["l", "◀"], ["b", "▼"], ["r", "▶"]] as const).map(([k, label], i) =>
            k ? (
              <button key={i} type="button" aria-label={{ f: "Walk forward", b: "Walk back", l: "Step left", r: "Step right" }[k]}
                className="size-11 rounded-full border border-champagne bg-ivory/85 text-ink-soft active:bg-gold/40"
                onPointerDown={hold(k, true)} onPointerUp={hold(k, false)} onPointerLeave={hold(k, false)} onPointerCancel={hold(k, false)}>{label}</button>
            ) : <span key={i} />,
          )}
        </div>

        {selected && <ProductPanel item={selected} onClose={close} />}
      </div>

      <aside className="space-y-4" aria-label="Showroom navigation">
        {rooms.length > 1 && (
          <div>
            <label className="label" htmlFor="room">Room</label>
            <select id="room" className="field" value={room.id} onChange={(e) => { setRoomId(e.target.value); setSelectedId(null); setFocus({ reset: true, nonce: ++nonce.current }); }}>
              {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </div>
        )}
        <p className="text-xs text-ink-soft sm:hidden">Drag to look · use the arrows to walk · tap the floor to move · tap a gold ring to inspect.</p>
        {room.description && <p className="text-sm text-ink-soft">{room.description}</p>}
        <div>
          <h2 className="text-lg">In this room</h2>
          {room.items.length === 0 ? (
            <p className="mt-2 text-sm text-ink-soft">No products have been placed in this room yet.</p>
          ) : (
            <ul className="mt-2 max-h-[40dvh] space-y-1 overflow-y-auto">
              {room.items.map((i) => (
                <li key={i.id}><button type="button" onClick={() => select(i.id)} aria-pressed={i.id === selectedId}
                  className={`w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-champagne/50 ${i.id === selectedId ? "bg-champagne/70" : ""}`}>{i.name}{i.modelUrl ? " · 3D" : ""}</button></li>
              ))}
            </ul>
          )}
        </div>
        <Link href="/products" className="btn btn-ghost w-full">Browse without 3D</Link>
      </aside>
    </div>
  );
}
