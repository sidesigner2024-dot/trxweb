"use client";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { formatBDT } from "@/lib/format";
import type { ShowroomItem } from "./types";

export function ProductPanel({ item, onClose }: { item: ShowroomItem; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    ref.current?.focus();
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [item.id, onClose]);

  return (
    <aside ref={ref} tabIndex={-1} role="dialog" aria-label={`${item.name} details`}
      className="showroom-panel absolute inset-x-0 bottom-0 z-20 max-h-[52%] overflow-y-auto rounded-t-2xl border border-champagne bg-ivory/95 p-5 shadow-2xl backdrop-blur sm:inset-y-4 sm:left-auto sm:right-4 sm:w-96 sm:max-h-none sm:rounded-2xl">
      <button type="button" onClick={onClose} className="absolute right-3 top-3 rounded-full p-2 text-xl leading-none text-ink-soft hover:text-ink" aria-label="Close details">×</button>
      <p className="text-xs uppercase tracking-widest text-gold-deep">{item.modelUrl ? "Interactive 3D model" : "Photo preview · no 3D model yet"}</p>
      <h2 className="mt-1 pr-8 text-2xl leading-snug">{item.name}</h2>
      {item.sample && <p className="mt-1 inline-block rounded-full bg-ink px-2 py-0.5 text-[11px] text-ivory">Sample content</p>}
      <p className="mt-3 flex items-baseline gap-2"><span className="text-xl">{formatBDT(item.priceBdt)}</span>{item.listPriceBdt != null && <s className="text-sm text-ink-soft">{formatBDT(item.listPriceBdt)}</s>}</p>
      <p className={`text-sm ${item.inStock ? "text-ok" : "text-danger"}`}>{item.inStock ? "Available" : "Out of stock"}</p>
      <dl className="mt-4 space-y-1 text-sm">
        {item.material && <div className="flex justify-between"><dt className="text-ink-soft">Material</dt><dd>{item.material}</dd></div>}
        {item.dimensions && <div className="flex justify-between"><dt className="text-ink-soft">Size</dt><dd>{item.dimensions}</dd></div>}
        {item.customizable && <div className="flex justify-between"><dt className="text-ink-soft">Personalisation</dt><dd>Available</dd></div>}
      </dl>
      <div className="mt-5 grid gap-2">
        <Link href={`/products/${item.slug}`} className="btn btn-primary">View details &amp; buy</Link>
        {item.customizable && <Link href={`/customize/${item.slug}`} className="btn btn-ghost">Personalise</Link>}
      </div>
    </aside>
  );
}
