import * as THREE from "three";

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/** Procedural ivory marble (veins + soft cloud + grout lines). Generated locally: no image downloads. */
export function createMarbleTexture(size = 1024, repeat = 1): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const r = rng(7);
  ctx.fillStyle = "#ece5d8";
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 40; i++) {
    const g = ctx.createRadialGradient(r() * size, r() * size, 0, r() * size, r() * size, size * (0.2 + r() * 0.4));
    g.addColorStop(0, `rgba(${225 + r() * 15},${218 + r() * 15},${204 + r() * 15},0.22)`);
    g.addColorStop(1, "rgba(241,236,226,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }

  for (let v = 0; v < 9; v++) {
    ctx.beginPath();
    let x = r() * size, y = r() * size;
    ctx.moveTo(x, y);
    const steps = 14 + Math.floor(r() * 10);
    for (let i = 0; i < steps; i++) {
      const nx = x + (r() - 0.35) * size * 0.22;
      const ny = y + (r() - 0.5) * size * 0.22;
      ctx.quadraticCurveTo(x + (r() - 0.5) * 80, y + (r() - 0.5) * 80, nx, ny);
      x = nx; y = ny;
    }
    ctx.strokeStyle = v % 3 === 0 ? "rgba(180,150,100,0.45)" : "rgba(120,112,100,0.38)";
    ctx.lineWidth = 0.8 + r() * 2.2;
    ctx.filter = `blur(${r() * 1.5}px)`;
    ctx.stroke();
  }
  ctx.filter = "none";

  ctx.strokeStyle = "rgba(140,130,115,0.55)";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, size, size); // tile joint on the repeat boundary

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}
