export type DisplayType = "pedestal" | "cabinet" | "wall" | "shelf";

export type ShowroomItem = {
  id: string;
  slug: string;
  name: string;
  priceBdt: number;
  listPriceBdt: number | null;
  imageUrl: string | null;
  imageAlt: string;
  modelUrl: string | null;
  modelScale: number;
  type: DisplayType;
  pos: [number, number, number];
  rotY: number;
  scale: number;
  inStock: boolean;
  customizable: boolean;
  material: string | null;
  dimensions: string | null;
  sample: boolean;
};

export type ShowroomRoom = { id: string; slug: string; name: string; description: string | null; items: ShowroomItem[] };

/** Room geometry in metres. Admin-placed positions must stay inside these bounds. */
export const ROOM = { width: 16, depth: 12, height: 4.6, walkMarginX: 0.8, walkMarginZ: 0.8 } as const;
export const PEDESTAL_HEIGHT = 0.95;

export function baseHeight(t: DisplayType, y: number): number {
  return t === "pedestal" || t === "cabinet" ? y + PEDESTAL_HEIGHT : y;
}
