"use client";
import { Suspense, useEffect, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import { Room } from "./room";
import { DisplayItem } from "./display-item";
import { baseHeight, ROOM, type ShowroomItem } from "./types";

export type InputState = { f: boolean; b: boolean; l: boolean; r: boolean };
export type FocusRequest = { id: string; nonce: number } | { reset: true; nonce: number } | null;

const START_POS = new THREE.Vector3(0, 1.6, 5.2);
/** First-person look: the orbit target stays 0.1 m in front of the camera, so dragging turns the head. */
const LOOK = 0.1;
const lookTarget = (from: THREE.Vector3, at: THREE.Vector3) => from.clone().addScaledVector(at.clone().sub(from).normalize(), LOOK);
const START_TARGET = lookTarget(START_POS, new THREE.Vector3(0, 1.2, 0));
const MAX_X = ROOM.width / 2 - ROOM.walkMarginX;
const MAX_Z = ROOM.depth / 2 - ROOM.walkMarginZ;

function Rig({ input, items, focus, reducedMotion }: { input: React.RefObject<InputState>; items: ShowroomItem[]; focus: FocusRequest; reducedMotion: boolean }) {
  const controls = useRef<React.ElementRef<typeof OrbitControls>>(null);
  const { camera } = useThree();
  const anim = useRef<{ t: number; fromP: THREE.Vector3; toP: THREE.Vector3; fromT: THREE.Vector3; toT: THREE.Vector3 } | null>(null);
  const walkTo = useRef<THREE.Vector3 | null>(null);
  const keys = useRef<InputState>({ f: false, b: false, l: false, r: false });
  const tmp = useRef({ fwd: new THREE.Vector3(), right: new THREE.Vector3(), move: new THREE.Vector3() });

  // keyboard: WASD / arrows
  useEffect(() => {
    const map: Record<string, keyof InputState> = { w: "f", arrowup: "f", s: "b", arrowdown: "b", a: "l", arrowleft: "l", d: "r", arrowright: "r" };
    const set = (e: KeyboardEvent, v: boolean) => {
      const t = e.target as HTMLElement | null;
      if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
      const k = map[e.key.toLowerCase()];
      if (k) { keys.current[k] = v; if (e.key.startsWith("Arrow")) e.preventDefault(); }
    };
    const down = (e: KeyboardEvent) => set(e, true);
    const up = (e: KeyboardEvent) => set(e, false);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, []);

  // camera transitions (focus a product, or reset)
  useEffect(() => {
    if (!focus || !controls.current) return;
    const c = controls.current;
    let toP: THREE.Vector3, toT: THREE.Vector3;
    if ("reset" in focus) {
      toP = START_POS.clone(); toT = START_TARGET.clone();
    } else {
      const item = items.find((i) => i.id === focus.id);
      if (!item) return;
      const y = baseHeight(item.type, item.pos[1]) + 0.35;
      const p = new THREE.Vector3(item.pos[0], y, item.pos[2]);
      const dir = item.type === "wall"
        ? new THREE.Vector3(Math.sin(item.rotY), 0, Math.cos(item.rotY))
        : new THREE.Vector3(camera.position.x - p.x, 0, camera.position.z - p.z);
      if (dir.lengthSq() < 0.01) dir.set(0, 0, 1);
      dir.normalize();
      toP = p.clone().addScaledVector(dir, 2.1).setY(1.45);
      toP.x = THREE.MathUtils.clamp(toP.x, -MAX_X, MAX_X);
      toP.z = THREE.MathUtils.clamp(toP.z, -MAX_Z, MAX_Z);
      toT = lookTarget(toP, p);
    }
    walkTo.current = null;
    if (reducedMotion) {
      camera.position.copy(toP); c.target.copy(toT); c.update(); anim.current = null;
    } else {
      anim.current = { t: 0, fromP: camera.position.clone(), toP, fromT: c.target.clone(), toT };
    }
  }, [focus, items, camera, reducedMotion]);

  useFrame((_, dtRaw) => {
    const c = controls.current;
    if (!c) return;
    const dt = Math.min(dtRaw, 0.05);
    const a = anim.current;
    if (a) {
      a.t = Math.min(1, a.t + dt / 0.9);
      const e = a.t * a.t * (3 - 2 * a.t);
      camera.position.lerpVectors(a.fromP, a.toP, e);
      c.target.lerpVectors(a.fromT, a.toT, e);
      if (a.t >= 1) anim.current = null;
      c.update();
      return;
    }
    const { fwd, right, move } = tmp.current;
    const k = keys.current, i = input.current;
    const f = (k.f || i.f ? 1 : 0) - (k.b || i.b ? 1 : 0);
    const r = (k.r || i.r ? 1 : 0) - (k.l || i.l ? 1 : 0);
    move.set(0, 0, 0);
    if (f || r) {
      walkTo.current = null;
      camera.getWorldDirection(fwd); fwd.y = 0; fwd.normalize();
      right.crossVectors(fwd, camera.up).normalize();
      move.addScaledVector(fwd, f).addScaledVector(right, r).normalize().multiplyScalar(2.2 * dt);
    } else if (walkTo.current) {
      move.set(walkTo.current.x - camera.position.x, 0, walkTo.current.z - camera.position.z);
      if (move.length() < 0.08) walkTo.current = null; else move.setLength(Math.min(2.6 * dt, move.length()));
    }
    if (move.lengthSq() > 0) {
      const before = camera.position.clone();
      camera.position.add(move);
      camera.position.x = THREE.MathUtils.clamp(camera.position.x, -MAX_X, MAX_X);
      camera.position.z = THREE.MathUtils.clamp(camera.position.z, -MAX_Z, MAX_Z);
      c.target.add(camera.position.clone().sub(before));
    }
    c.update();
  });

  return (
    <>
      <OrbitControls ref={controls} makeDefault enablePan={false} enableDamping dampingFactor={0.08}
        enableZoom={false} rotateSpeed={-0.45} minDistance={LOOK} maxDistance={LOOK} minPolarAngle={0.9} maxPolarAngle={2.1} target={START_TARGET.toArray()} />
      {/* click/tap the floor to walk there */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.001, 0]} visible={false}
        onClick={(e) => { if (e.delta <= 6) walkTo.current = new THREE.Vector3(THREE.MathUtils.clamp(e.point.x, -MAX_X, MAX_X), 0, THREE.MathUtils.clamp(e.point.z, -MAX_Z, MAX_Z)); }}>
        <planeGeometry args={[ROOM.width, ROOM.depth]} />
      </mesh>
    </>
  );
}

function ShadowSetup({ enabled }: { enabled: boolean }) {
  const gl = useThree((s) => s.gl);
  useEffect(() => { gl.shadowMap.enabled = enabled; gl.shadowMap.type = THREE.PCFSoftShadowMap; }, [gl, enabled]);
  return null;
}

export default function ShowroomScene({
  items, selectedId, onSelect, quality, reducedMotion, input, focus,
}: {
  items: ShowroomItem[]; selectedId: string | null; onSelect: (id: string) => void;
  quality: "low" | "high"; reducedMotion: boolean; input: React.RefObject<InputState>; focus: FocusRequest;
}) {
  const high = quality === "high";
  return (
    <Canvas
      dpr={high ? [1, 1.75] : [1, 1]}
      shadows={high}
      camera={{ position: START_POS.toArray(), fov: 62, near: 0.05, far: 60 }}
      gl={{ antialias: high, powerPreference: high ? "high-performance" : "low-power", toneMapping: THREE.ACESFilmicToneMapping }}
      aria-label="Interactive 3D showroom. Drag to look, W A S D or arrow keys to walk, tap the floor to move, tap a product to inspect it."
      role="application"
    >
      <ShadowSetup enabled={high} />
      <color attach="background" args={["#efe9de"]} />
      <fog attach="fog" args={["#efe9de", 14, 30]} />
      <ambientLight intensity={0.3} color="#fff6e6" />
      <hemisphereLight args={["#fffaf0", "#d9cdb8", 0.3]} />
      <directionalLight position={[3, 4.2, 4]} intensity={0.7} color="#fff1d6" castShadow={high} shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-9} shadow-camera-right={9} shadow-camera-top={7} shadow-camera-bottom={-7} shadow-bias={-0.0005} />
      {!high && [[-4, 4, -2], [4, 4, -2], [0, 4, 3]].map((p, i) => <pointLight key={i} position={p as [number, number, number]} intensity={14} distance={12} decay={2} color="#fff1d6" />)}
      <Suspense fallback={null}>
        <Environment resolution={high ? 128 : 32} frames={1} background={false}>
          <Lightformer form="rect" intensity={2.2} color="#fff3dc" position={[0, 4.4, 0]} rotation-x={Math.PI / 2} scale={[10, 6, 1]} />
          <Lightformer form="rect" intensity={1.2} color="#ffffff" position={[-7, 2, 0]} rotation-y={Math.PI / 2} scale={[8, 3, 1]} />
          <Lightformer form="rect" intensity={1.2} color="#ffffff" position={[7, 2, 0]} rotation-y={-Math.PI / 2} scale={[8, 3, 1]} />
        </Environment>
        <Room quality={quality} />
        {items.map((it, idx) => (
          <DisplayItem key={it.id} item={it} selected={it.id === selectedId} onSelect={onSelect}
            quality={high && idx < 8 ? "high" : "low"} reducedMotion={reducedMotion} />
        ))}
      </Suspense>
      <Rig input={input} items={items} focus={focus} reducedMotion={reducedMotion} />
    </Canvas>
  );
}
