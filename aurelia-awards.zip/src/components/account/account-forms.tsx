"use client";
import { useActionState, useTransition, useState } from "react";
import { addAddress, cancelOrder, deleteAddress, updateProfile } from "@/app/account/actions";
import { BD_DISTRICTS } from "@/lib/districts";

export function ProfileForm({ fullName, phone }: { fullName: string; phone: string }) {
  const [state, action, pending] = useActionState(updateProfile, undefined);
  return (
    <form action={action} className="card space-y-4 p-5">
      <h2 className="text-xl">Profile</h2>
      <div><label className="label" htmlFor="full_name">Full name</label><input id="full_name" name="full_name" defaultValue={fullName} className="field" required /></div>
      <div><label className="label" htmlFor="phone">Mobile</label><input id="phone" name="phone" defaultValue={phone} inputMode="tel" className="field" /></div>
      {state?.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      {state?.ok && <p role="status" className="text-sm text-ok">Saved.</p>}
      <button className="btn btn-primary" disabled={pending}>{pending ? "Saving…" : "Save profile"}</button>
    </form>
  );
}

export function AddressForm() {
  const [state, action, pending] = useActionState(addAddress, undefined);
  return (
    <form action={action} className="card space-y-3 p-5">
      <h2 className="text-xl">Add an address</h2>
      <input name="recipient_name" placeholder="Recipient" className="field" required aria-label="Recipient" />
      <input name="phone" placeholder="Mobile (01XXXXXXXXX)" inputMode="tel" className="field" required aria-label="Mobile" />
      <input name="line1" placeholder="Address" className="field" required aria-label="Address" />
      <div className="grid grid-cols-2 gap-3">
        <input name="city" placeholder="Area / city" className="field" required aria-label="City" />
        <select name="district" className="field" required aria-label="District" defaultValue="">
          <option value="" disabled>District</option>
          {BD_DISTRICTS.map((d) => <option key={d}>{d}</option>)}
        </select>
      </div>
      {state?.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      {state?.ok && <p role="status" className="text-sm text-ok">Address saved.</p>}
      <button className="btn btn-ghost" disabled={pending}>{pending ? "Saving…" : "Save address"}</button>
    </form>
  );
}

export function DeleteAddressButton({ id }: { id: string }) {
  const [pending, start] = useTransition();
  return <button type="button" disabled={pending} className="text-sm text-ink-soft underline" onClick={() => start(() => deleteAddress(id))}>Delete</button>;
}

export function CancelOrderButton({ orderId }: { orderId: string }) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  return (
    <div>
      <button type="button" className="btn btn-ghost" disabled={pending}
        onClick={() => { if (confirm("Cancel this order?")) start(async () => { const r = await cancelOrder(orderId); setError(r?.error ?? null); }); }}>
        {pending ? "Cancelling…" : "Cancel order"}
      </button>
      {error && <p role="alert" className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
}
