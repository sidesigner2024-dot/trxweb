"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { cartActions } from "@/lib/cart-store";
import { formatBDT } from "@/lib/format";
import type { CustomizationOption, ProductVariant } from "@/lib/types";
import { EngravingPreview, fontStack } from "./preview";

type Props = {
  product: { id: string; slug: string; name: string; imageUrl: string | null; basePrice: number; allowsLogo: boolean; trackStock: boolean; stockQty: number };
  variants: ProductVariant[];
  options: CustomizationOption[];
  initialVariant?: string;
  signedIn: boolean;
};

function uploadWithProgress(file: File, onProgress: (pct: number) => void): Promise<{ path?: string; error?: string }> {
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload/artwork");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onerror = () => resolve({ error: "Network error. Please try again." });
    xhr.onload = () => {
      try { resolve(JSON.parse(xhr.responseText)); } catch { resolve({ error: "Unexpected response from the server." }); }
    };
    const fd = new FormData();
    fd.append("file", file);
    xhr.send(fd);
  });
}

export function Studio({ product, variants, options, initialVariant, signedIn }: Props) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [variantId, setVariantId] = useState(variants.some((v) => v.id === initialVariant) ? initialVariant! : variants.length === 1 ? variants[0].id : "");
  const [qty, setQty] = useState(1);
  const [logo, setLogo] = useState<{ path: string; previewUrl: string | null; name: string } | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [added, setAdded] = useState(false);

  useEffect(() => () => { if (logo?.previewUrl) URL.revokeObjectURL(logo.previewUrl); }, [logo]);

  const variant = variants.find((v) => v.id === variantId);
  const unit = product.basePrice + Number(variant?.price_delta_bdt ?? 0);
  const set = (k: string, v: string) => { setValues((p) => ({ ...p, [k]: v })); setAdded(false); };

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError(null); setProgress(0);
    const r = await uploadWithProgress(file, setProgress);
    setProgress(null);
    if (r.path) setLogo({ path: r.path, previewUrl: file.type.startsWith("image/") ? URL.createObjectURL(file) : null, name: file.name });
    else setError(r.error ?? "Upload failed.");
  }

  function addToCart() {
    setError(null);
    for (const o of options) {
      const v = values[o.field_key]?.trim() ?? "";
      if (o.is_required && !v) return setError(`Please fill in “${o.label}”.`);
      if (v.length > o.max_length) return setError(`“${o.label}” is too long (max ${o.max_length}).`);
    }
    if (variants.length > 0 && !variant) return setError("Please choose an option.");
    if (product.trackStock && !variants.length && qty > product.stockQty) return setError(`Only ${product.stockQty} available.`);
    const lines = Object.fromEntries(Object.entries(values).map(([k, v]) => [k, v.trim()]).filter(([, v]) => v));
    cartActions.add({
      productId: product.id, variantId: variant?.id ?? null, qty,
      name: variant ? `${product.name} — ${variant.name}` : product.name, imageUrl: product.imageUrl, unitPriceDisplay: unit,
      customization: { lines, ...(logo ? { logo_path: logo.path } : {}) },
    });
    setAdded(true);
  }

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="lg:sticky lg:top-24 lg:self-start">
        <EngravingPreview options={options} values={values} logoUrl={logo?.previewUrl ?? null} />
      </div>
      <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); addToCart(); }} noValidate>
        {variants.length > 0 && (
          <div>
            <label className="label" htmlFor="variant">Option</label>
            <select id="variant" className="field" value={variantId} onChange={(e) => setVariantId(e.target.value)}>
              <option value="">Choose an option</option>
              {variants.map((v) => <option key={v.id} value={v.id} disabled={product.trackStock && v.stock_qty < 1}>{v.name}</option>)}
            </select>
          </div>
        )}
        {options.map((o) => {
          const id = `opt-${o.field_key}`;
          const label = <label className="label" htmlFor={id}>{o.label}{o.is_required ? " *" : ""}</label>;
          const common = { id, className: "field", value: values[o.field_key] ?? "", onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => set(o.field_key, e.target.value) };
          return (
            <div key={o.id}>
              {label}
              {o.field_type === "message" ? <textarea {...common} rows={3} maxLength={o.max_length} />
                : o.field_type === "date" ? <input {...common} type="date" />
                : o.field_type === "font" || o.field_type === "color" ? (
                  <select {...common}>
                    <option value="">Choose…</option>
                    {(o.choices ?? []).map((c) => <option key={c} value={c} style={o.field_type === "font" ? { fontFamily: fontStack(c) } : undefined}>{c}</option>)}
                  </select>
                ) : <input {...common} type="text" maxLength={o.max_length} />}
              {o.field_type !== "date" && o.field_type !== "font" && o.field_type !== "color" && (
                <p className="mt-1 text-xs text-ink-soft">{(values[o.field_key] ?? "").length}/{o.max_length}</p>
              )}
            </div>
          );
        })}

        {product.allowsLogo && (
          <div>
            <label className="label" htmlFor="logo">Logo or artwork (PNG, JPG, WebP or PDF, max 10 MB)</label>
            {signedIn ? (
              <>
                <input id="logo" type="file" accept="image/png,image/jpeg,image/webp,application/pdf" className="field !py-2" onChange={(e) => onFile(e.target.files?.[0])} disabled={progress !== null} />
                {progress !== null && <div role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} className="mt-2 h-1.5 overflow-hidden rounded bg-champagne"><div className="h-full bg-gold-deep" style={{ width: `${progress}%` }} /></div>}
                {logo && <p className="mt-2 text-sm text-ok">Uploaded: {logo.name} <button type="button" className="ml-2 underline" onClick={() => setLogo(null)}>Remove</button></p>}
                <p className="mt-1 text-xs text-ink-soft">Your file is stored privately and only visible to you and our team.</p>
              </>
            ) : <p className="text-sm text-ink-soft"><Link className="underline" href={`/login?next=/customize/${product.slug}`}>Sign in</Link> to upload a logo.</p>}
          </div>
        )}

        <div className="flex items-end gap-3">
          <div className="w-24"><label className="label" htmlFor="qty">Qty</label><input id="qty" type="number" min={1} max={99} className="field" value={qty} onChange={(e) => setQty(Math.max(1, Math.min(99, Number(e.target.value) || 1)))} /></div>
          <p className="pb-2 text-xl" aria-live="polite">{formatBDT(unit * qty)}</p>
        </div>

        {error && <p role="alert" className="text-sm text-danger">{error}</p>}
        <button type="submit" className="btn btn-primary w-full">Add personalised item to cart</button>
        {added && <p role="status" className="text-sm text-ok">Added. <Link href="/cart" className="underline">View cart</Link></p>}
        <p className="text-xs text-ink-soft">Our team reviews every personalised design and may contact you for changes before production.</p>
      </form>
    </div>
  );
}
