import type { CustomizationOption } from "@/lib/types";

/** Font names an admin may use in customization_options.choices, mapped to safe local font stacks. */
const FONT_STACKS: Record<string, string> = {
  serif: 'Georgia, "Times New Roman", serif',
  classic: '"Palatino Linotype", Palatino, serif',
  script: '"Brush Script MT", "Segoe Script", cursive',
  sans: '"Helvetica Neue", Arial, sans-serif',
  modern: '"Helvetica Neue", Arial, sans-serif',
  mono: '"Courier New", monospace',
};
export const fontStack = (name?: string) => FONT_STACKS[(name ?? "").toLowerCase()] ?? FONT_STACKS.serif;
export const safeColor = (v?: string) => (v && /^#[0-9a-f]{6}$/i.test(v) ? v : undefined);

export function formatDateValue(v: string): string {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(v) ? new Date(`${v}T00:00:00`) : null;
  return d && !Number.isNaN(d.getTime()) ? d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" }) : v;
}

export function EngravingPreview({
  options, values, logoUrl,
}: { options: CustomizationOption[]; values: Record<string, string>; logoUrl: string | null }) {
  const fontOpt = options.find((o) => o.field_type === "font");
  const colorOpt = options.find((o) => o.field_type === "color");
  const family = fontStack(fontOpt ? values[fontOpt.field_key] : undefined);
  const color = safeColor(colorOpt ? values[colorOpt.field_key] : undefined) ?? "#5a4a2a";
  const textOpts = options.filter((o) => ["text", "date", "message"].includes(o.field_type));

  return (
    <figure className="space-y-2">
      <div className="relative flex aspect-[4/3] flex-col items-center justify-center gap-2 overflow-hidden rounded-xl border border-gold bg-gradient-to-br from-[#f3e9d2] via-[#e6d5b0] to-[#cdb485] p-6 text-center shadow-inner"
        role="img" aria-label="Preview of your personalisation">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="Your uploaded logo" className="mb-1 max-h-20 max-w-[40%] object-contain" />
        )}
        {textOpts.map((o) => {
          const v = values[o.field_key]?.trim();
          if (!v) return <p key={o.id} className="text-xs italic opacity-40" style={{ fontFamily: family, color }}>{o.label}</p>;
          return (
            <p key={o.id} className={`break-words ${o.field_type === "message" ? "text-sm" : "text-xl"}`} style={{ fontFamily: family, color }}>
              {o.field_type === "date" ? formatDateValue(v) : v}
            </p>
          );
        })}
      </div>
      <figcaption className="text-xs text-ink-soft">
        This preview is a guide to wording and layout only. Final engraving size, position and font rendering can differ in production, and our team reviews every design before making it.
      </figcaption>
    </figure>
  );
}
