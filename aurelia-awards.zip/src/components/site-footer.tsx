import Link from "next/link";

const links = [
  { href: "/faq", label: "FAQ" },
  { href: "/track", label: "Track order" },
  { href: "/privacy", label: "Privacy" },
  { href: "/terms", label: "Terms" },
  { href: "/returns", label: "Returns & refunds" },
];

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-champagne bg-champagne/30">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-10 text-sm text-ink-soft sm:px-6 md:flex-row md:justify-between">
        <p>© {new Date().getFullYear()} Aurelia Awards. Prices in BDT.</p>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-gold-deep">
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </footer>
  );
}
