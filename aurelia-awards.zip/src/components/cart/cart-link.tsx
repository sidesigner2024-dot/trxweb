"use client";
import Link from "next/link";
import { useCart } from "@/lib/cart-store";

export function CartLink() {
  const count = useCart().reduce((n, l) => n + l.qty, 0);
  return (
    <Link href="/cart" className="btn btn-ghost !min-h-9 !px-4 !py-1" aria-label={`Cart, ${count} item${count === 1 ? "" : "s"}`}>
      Cart{count > 0 ? ` (${count})` : ""}
    </Link>
  );
}
