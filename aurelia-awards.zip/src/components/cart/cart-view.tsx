"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { cartActions, useCart } from "@/lib/cart-store";
import { formatBDT } from "@/lib/format";
import { verifyCart, type VerifiedLine } from "@/app/cart/actions";

export function CartView() {
  const lines = useCart();
  const [verified, setVerified] = useState<VerifiedLine[] | null>(null);
  const signature = useMemo(() => JSON.stringify(lines.map((l) => [l.productId, l.variantId])), [lines]);

  useEffect(() => {
    let cancelled = false;
    if (lines.length === 0) return;
    verifyCart(lines.map((l) => ({ productId: l.productId, variantId: l.variantId }))).then((v) => { if (!cancelled) setVerified(v); }).catch(() => { if (!cancelled) setVerified([]); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature]);

  if (lines.length === 0) {
    return (
      <div className="card p-10 text-center">
        <p className="text-ink-soft">Your cart is empty.</p>
        <Link href="/products" className="btn btn-primary mt-6">Continue shopping</Link>
      </div>
    );
  }

  const find = (productId: string, variantId: string | null) => verified?.find((v) => v.productId === productId && v.variantId === variantId);
  const rows = lines.map((l) => {
    const v = find(l.productId, l.variantId);
    return { line: l, v, unit: v?.available ? v.unitPrice : null };
  });
  const problem = rows.some((r) => r.v && !r.v.available);
  const subtotal = rows.reduce((s, r) => s + (r.unit ?? 0) * r.line.qty, 0);
  const priced = verified !== null && verified.length > 0;

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
      <ul className="space-y-4">
        {rows.map(({ line, v, unit }) => (
          <li key={line.key} className="card flex gap-4 p-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {line.imageUrl ? <img src={line.imageUrl} alt="" className="size-24 rounded-lg object-cover" /> : <div className="size-24 rounded-lg bg-champagne/40" />}
            <div className="flex-1">
              <p className="font-medium">{line.name}</p>
              {line.customization && Object.keys(line.customization.lines).length > 0 && (
                <p className="mt-1 text-xs text-ink-soft">
                  Personalised: {Object.values(line.customization.lines).filter(Boolean).join(" · ")}{line.customization.logo_path ? " · logo attached" : ""}
                </p>
              )}
              <p className="mt-1 text-sm text-ink-soft">
                {v && !v.available ? <span className="text-danger">No longer available — please remove</span> : unit != null ? formatBDT(unit) : "Checking price…"}
              </p>
              <div className="mt-3 flex items-center gap-3">
                <label className="sr-only" htmlFor={`q-${line.key}`}>Quantity</label>
                <input id={`q-${line.key}`} type="number" min={1} max={v?.stockLimit ?? 99} value={line.qty} className="field !w-20"
                  onChange={(e) => cartActions.setQty(line.key, Number(e.target.value) || 1)} />
                <button type="button" className="text-sm text-ink-soft underline" onClick={() => cartActions.remove(line.key)}>Remove</button>
              </div>
            </div>
            <p className="font-medium">{unit != null ? formatBDT(unit * line.qty) : ""}</p>
          </li>
        ))}
      </ul>
      <aside className="card h-fit p-5">
        <h2 className="text-xl">Summary</h2>
        <p className="mt-4 flex justify-between"><span>Subtotal</span><span>{priced ? formatBDT(subtotal) : "…"}</span></p>
        <p className="mt-2 text-xs text-ink-soft">Delivery and coupons are calculated at checkout. Prices are re-checked when you place the order.</p>
        <Link href="/checkout" aria-disabled={problem} className={`btn btn-primary mt-5 w-full ${problem ? "pointer-events-none opacity-50" : ""}`}>Checkout</Link>
        {problem && <p role="alert" className="mt-2 text-sm text-danger">Remove unavailable items to continue.</p>}
      </aside>
    </div>
  );
}
