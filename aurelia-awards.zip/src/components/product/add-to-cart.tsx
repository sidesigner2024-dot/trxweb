"use client";
import { useState } from "react";
import Link from "next/link";
import { cartActions } from "@/lib/cart-store";
import { formatBDT } from "@/lib/format";
import type { ProductVariant } from "@/lib/types";

type Props = {
  productId: string; slug: string; name: string; imageUrl: string | null;
  basePrice: number; variants: ProductVariant[]; trackStock: boolean; stockQty: number; isCustomizable: boolean;
};

export function AddToCart({ productId, slug, name, imageUrl, basePrice, variants, trackStock, stockQty, isCustomizable }: Props) {
  const [variantId, setVariantId] = useState<string>(variants.length === 1 ? variants[0].id : "");
  const [qty, setQty] = useState(1);
  const [message, setMessage] = useState<string | null>(null);
  const variant = variants.find((v) => v.id === variantId);
  const unit = basePrice + Number(variant?.price_delta_bdt ?? 0);
  const available = variants.length ? (variant ? variant.stock_qty : 1) : stockQty;
  const inStock = !trackStock || available > 0;
  const needsVariant = variants.length > 0 && !variant;

  function add() {
    if (needsVariant) return setMessage("Please choose an option first.");
    if (trackStock && qty > available) return setMessage(`Only ${available} available.`);
    cartActions.add({ productId, variantId: variant?.id ?? null, qty, name: variant ? `${name} — ${variant.name}` : name, imageUrl, unitPriceDisplay: unit });
    setMessage("Added to your cart.");
  }

  return (
    <div className="space-y-4">
      {variants.length > 0 && (
        <div>
          <label htmlFor="variant" className="label">Option</label>
          <select id="variant" className="field" value={variantId} onChange={(e) => { setVariantId(e.target.value); setMessage(null); }}>
            <option value="">Choose an option</option>
            {variants.map((v) => (
              <option key={v.id} value={v.id} disabled={trackStock && v.stock_qty < 1}>
                {v.name}{Number(v.price_delta_bdt) ? ` (${Number(v.price_delta_bdt) > 0 ? "+" : ""}${formatBDT(v.price_delta_bdt)})` : ""}{trackStock && v.stock_qty < 1 ? " — sold out" : ""}
              </option>
            ))}
          </select>
        </div>
      )}
      <p className="text-2xl font-medium" aria-live="polite">{formatBDT(unit)}</p>

      {isCustomizable ? (
        <Link href={`/customize/${slug}${variantId ? `?variant=${variantId}` : ""}`} className={`btn btn-primary w-full ${inStock ? "" : "pointer-events-none opacity-50"}`}>
          Personalise this piece
        </Link>
      ) : (
        <div className="flex items-end gap-3">
          <div className="w-24">
            <label htmlFor="qty" className="label">Qty</label>
            <input id="qty" type="number" min={1} max={99} className="field" value={qty} onChange={(e) => setQty(Math.max(1, Math.min(99, Number(e.target.value) || 1)))} />
          </div>
          <button type="button" className="btn btn-primary flex-1" disabled={!inStock} onClick={add}>
            {inStock ? "Add to cart" : "Out of stock"}
          </button>
        </div>
      )}
      {message && <p role="status" className="text-sm text-ink-soft">{message} {message.startsWith("Added") && <Link href="/cart" className="underline">View cart</Link>}</p>}
    </div>
  );
}
