"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toggleWishlist } from "@/app/actions/wishlist";

export function WishlistButton({ productId, initiallyWished }: { productId: string; initiallyWished: boolean }) {
  const [wished, setWished] = useState(initiallyWished);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const router = useRouter();

  return (
    <div>
      <button
        type="button"
        className="btn btn-ghost"
        aria-pressed={wished}
        disabled={pending}
        onClick={() =>
          start(async () => {
            setError(null);
            const r = await toggleWishlist(productId);
            if (r.ok) setWished(r.wished);
            else if (r.needsLogin) router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`);
            else setError(r.error ?? "Something went wrong.");
          })
        }
      >
        {wished ? "♥ In wishlist" : "♡ Add to wishlist"}
      </button>
      {error && <p role="alert" className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
}
