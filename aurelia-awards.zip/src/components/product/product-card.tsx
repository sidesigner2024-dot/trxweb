import Link from "next/link";
import Image from "next/image";
import { formatBDT, effectivePrice } from "@/lib/format";
import { hasModel, isInStock, sortedImages } from "@/lib/product-utils";
import { publicUrl } from "@/lib/storage-url";
import type { ProductSummary } from "@/lib/types";

export function ProductCard({ product }: { product: ProductSummary }) {
  const img = sortedImages(product.images)[0];
  const onSale = product.discount_price_bdt != null;
  const inStock = isInStock(product);
  return (
    <article className="card group overflow-hidden transition-shadow hover:shadow-lg">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-square bg-champagne/40">
          {img ? (
            <Image
              src={publicUrl("product-images", img.storage_path)}
              alt={img.alt_text || product.name}
              fill
              sizes="(min-width:1024px) 25vw, (min-width:640px) 33vw, 50vw"
              className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-ink-soft">No photo yet</div>
          )}
          <div className="absolute left-2 top-2 flex flex-wrap gap-1 text-[11px]">
            {product.is_sample && <span className="rounded-full bg-ink px-2 py-0.5 text-ivory">Sample</span>}
            {hasModel(product) && <span className="rounded-full bg-pure/90 px-2 py-0.5 text-gold-deep">3D</span>}
            {product.is_customizable && <span className="rounded-full bg-pure/90 px-2 py-0.5">Personalisable</span>}
          </div>
        </div>
        <div className="p-4">
          {product.category && <p className="text-xs uppercase tracking-widest text-gold-deep">{product.category.name}</p>}
          <h3 className="mt-1 line-clamp-2 text-lg leading-snug">{product.name}</h3>
          <p className="mt-2 flex items-baseline gap-2 text-sm">
            <span className="font-medium">{formatBDT(effectivePrice(product))}</span>
            {onSale && <s className="text-ink-soft">{formatBDT(product.price_bdt)}</s>}
            {!inStock && <span className="ml-auto text-danger">Out of stock</span>}
          </p>
        </div>
      </Link>
    </article>
  );
}
