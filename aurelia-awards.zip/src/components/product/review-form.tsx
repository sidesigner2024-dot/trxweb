"use client";
import { useActionState } from "react";
import { submitReview } from "@/app/actions/review";

export function ReviewForm({ productId }: { productId: string }) {
  const [state, action, pending] = useActionState(submitReview, undefined);
  if (state?.ok) return <p role="status" className="text-sm text-ok">Thank you. Your review will appear once our team approves it.</p>;
  return (
    <form action={action} className="card max-w-xl space-y-3 p-4">
      <h3 className="text-lg">Write a review</h3>
      <input type="hidden" name="product_id" value={productId} />
      <div><label className="label" htmlFor="rating">Rating</label><select id="rating" name="rating" className="field" required defaultValue=""><option value="" disabled>Choose…</option>{[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} star{n > 1 ? "s" : ""}</option>)}</select></div>
      <div><label className="label" htmlFor="rt">Title</label><input id="rt" name="title" className="field" maxLength={120} /></div>
      <div><label className="label" htmlFor="rb">Review</label><textarea id="rb" name="body" rows={3} className="field" maxLength={2000} /></div>
      {state?.error && <p role="alert" className="text-sm text-danger">{state.error}</p>}
      <button className="btn btn-ghost" disabled={pending}>{pending ? "Sending…" : "Submit review"}</button>
      <p className="text-xs text-ink-soft">Only customers with a delivered order of this product can review it.</p>
    </form>
  );
}
