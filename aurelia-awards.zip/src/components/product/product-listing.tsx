import Link from "next/link";
import { getCategories, listProducts } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/env";
import { NotConfigured } from "@/components/not-configured";
import { ProductCard } from "@/components/product/product-card";

export type ListingParams = Record<string, string | string[] | undefined>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const num = (v: string | undefined) => (v && Number.isFinite(Number(v)) ? Number(v) : undefined);

export async function ProductListing({ params, basePath, fixedCategory }: { params: ListingParams; basePath: string; fixedCategory?: string }) {
  if (!isSupabaseConfigured()) return <NotConfigured what="the product catalogue" />;
  const q = one(params.q) ?? "";
  const category = fixedCategory ?? one(params.category);
  const sort = one(params.sort) ?? "newest";
  const page = Math.max(1, Math.floor(num(one(params.page)) ?? 1));
  const min = num(one(params.min));
  const max = num(one(params.max));
  const customizable = one(params.customizable) === "1";
  const inStock = one(params.instock) === "1";

  const [{ items, total, pageSize }, categories] = await Promise.all([
    listProducts({ q, category, sort, page, min, max, customizable, inStock }),
    getCategories(),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const link = (p: number) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) { const s = one(v); if (s && k !== "page") sp.set(k, s); }
    if (p > 1) sp.set("page", String(p));
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
      <form method="get" action={basePath} className="card h-fit space-y-4 p-5" aria-label="Filter products">
        <div>
          <label htmlFor="q" className="label">Search</label>
          <input id="q" name="q" defaultValue={q} placeholder="Name, SKU or material" className="field" />
        </div>
        {!fixedCategory && (
          <div>
            <label htmlFor="category" className="label">Category</label>
            <select id="category" name="category" defaultValue={category ?? ""} className="field">
              <option value="">All categories</option>
              {categories.filter((c) => !c.parent_id).map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
            </select>
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <div><label htmlFor="min" className="label">Min ৳</label><input id="min" name="min" type="number" min={0} defaultValue={min} className="field" /></div>
          <div><label htmlFor="max" className="label">Max ৳</label><input id="max" name="max" type="number" min={0} defaultValue={max} className="field" /></div>
        </div>
        <div>
          <label htmlFor="sort" className="label">Sort by</label>
          <select id="sort" name="sort" defaultValue={sort} className="field">
            <option value="newest">Newest</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="name">Name</option>
          </select>
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="customizable" value="1" defaultChecked={customizable} className="size-4 accent-[#9c8355]" /> Personalisable only</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="instock" value="1" defaultChecked={inStock} className="size-4 accent-[#9c8355]" /> In stock only</label>
        <div className="flex gap-2">
          <button className="btn btn-primary flex-1" type="submit">Apply</button>
          <Link href={basePath} className="btn btn-ghost">Reset</Link>
        </div>
      </form>

      <section aria-live="polite">
        <p className="mb-4 text-sm text-ink-soft">{total} product{total === 1 ? "" : "s"}</p>
        {items.length === 0 ? (
          <div className="card p-10 text-center text-ink-soft">No products match these filters.</div>
        ) : (
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6">
            {items.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}
          </ul>
        )}
        {pages > 1 && (
          <nav aria-label="Pagination" className="mt-10 flex items-center justify-center gap-3">
            {page > 1 ? <Link className="btn btn-ghost" href={link(page - 1)}>Previous</Link> : <span />}
            <span className="text-sm text-ink-soft">Page {page} of {pages}</span>
            {page < pages ? <Link className="btn btn-ghost" href={link(page + 1)}>Next</Link> : <span />}
          </nav>
        )}
      </section>
    </div>
  );
}
