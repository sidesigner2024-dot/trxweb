import Link from "next/link";
import { CartLink } from "@/components/cart/cart-link";

const nav = [
  { href: "/showroom", label: "Showroom" },
  { href: "/products", label: "Shop" },
  { href: "/customize", label: "Customise" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-champagne bg-ivory/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="font-serif text-2xl tracking-wide">
          Aurelia <span className="text-gold-deep">Awards</span>
        </Link>
        <nav aria-label="Primary" className="hidden gap-7 text-sm tracking-wide md:flex">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className="text-ink-soft transition-colors hover:text-gold-deep">
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3 text-sm">
          <Link href="/account" className="text-ink-soft hover:text-gold-deep">Account</Link>
          <CartLink />
        </div>
      </div>
      <nav aria-label="Primary mobile" className="flex gap-5 overflow-x-auto border-t border-champagne px-4 py-2 text-sm md:hidden">
        {nav.map((n) => (
          <Link key={n.href} href={n.href} className="whitespace-nowrap text-ink-soft">
            {n.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
