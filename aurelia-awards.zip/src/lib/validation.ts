import { z } from "zod";

/** Bangladesh mobile numbers: 01XXXXXXXXX, optionally prefixed with +88 / 88. */
export const bdPhone = z
  .string()
  .trim()
  .regex(/^(?:\+?88)?01[3-9]\d{8}$/, "Enter a valid Bangladeshi mobile number (e.g. 01712345678)");

const text = (max: number) => z.string().trim().max(max);

export const customizationSchema = z
  .object({
    lines: z.record(z.string().regex(/^[a-z][a-z0-9_]{0,30}$/), text(500)).default({}),
    logo_path: text(300).optional(),
  })
  .strict();

export const cartLineSchema = z.object({
  product_id: z.uuid(),
  variant_id: z.uuid().nullable().optional(),
  qty: z.number().int().min(1).max(99),
  customization: customizationSchema.nullable().optional(),
});

export const addressSchema = z.object({
  recipient_name: text(120).min(1, "Recipient name is required"),
  phone: bdPhone,
  line1: text(200).min(1, "Address is required"),
  line2: text(200).optional(),
  city: text(80).min(1, "City is required"),
  district: text(80).min(1, "District is required"),
  postal_code: text(12).optional(),
});

export const checkoutSchema = z.object({
  idempotency_key: z.string().min(8).max(100),
  customer_name: text(120).min(1, "Name is required"),
  customer_phone: bdPhone,
  customer_email: z.email().max(200).optional().or(z.literal("")),
  address: addressSchema,
  payment_method: z.literal("cod"), // online payments are added only once a gateway is configured
  coupon_code: text(32).optional(),
  notes: text(1000).optional(),
  items: z.array(cartLineSchema).min(1, "Your cart is empty").max(50),
});
export type CheckoutInput = z.infer<typeof checkoutSchema>;

export const quoteSchema = z.object({
  items: z.array(cartLineSchema).min(1).max(50),
  coupon_code: text(32).optional(),
  district: text(80).optional(),
});

export const contactSchema = z
  .object({
    name: text(120).min(1, "Name is required"),
    email: z.email().max(200).optional().or(z.literal("")),
    phone: text(20).optional(),
    subject: text(160).optional(),
    message: text(4000).min(5, "Please write a short message"),
    website: z.string().max(0).optional(), // honeypot: real people leave this empty
  })
  .refine((v) => Boolean(v.email) || Boolean(v.phone), { message: "Give an email or phone so we can reply", path: ["email"] });

export const registerSchema = z.object({
  full_name: text(120).min(1, "Name is required"),
  email: z.email().max(200),
  password: z.string().min(8, "Use at least 8 characters").max(72),
});
export const loginSchema = z.object({ email: z.email(), password: z.string().min(1).max(72) });

export const trackSchema = z.object({
  order_number: z.string().trim().toUpperCase().regex(/^AW-\d{3,10}$/, "Order numbers look like AW-1001"),
  phone: bdPhone,
});

export const slug = z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Lowercase letters, numbers and dashes only");

export const productInputSchema = z
  .object({
    sku: text(60).min(1),
    name: text(160).min(1),
    slug,
    description: z.string().max(10000).default(""),
    category_id: z.uuid().nullable().optional(),
    subcategory_id: z.uuid().nullable().optional(),
    price_bdt: z.number().min(0).max(100_000_000),
    discount_price_bdt: z.number().min(0).nullable().optional(),
    material: text(120).nullable().optional(),
    dimensions: text(120).nullable().optional(),
    weight_grams: z.number().int().min(0).nullable().optional(),
    stock_qty: z.number().int().min(0).default(0),
    track_stock: z.boolean().default(true),
    production_days: z.number().int().min(0).max(365).nullable().optional(),
    is_customizable: z.boolean().default(false),
    allows_logo: z.boolean().default(false),
    is_featured: z.boolean().default(false),
    is_active: z.boolean().default(true),
    seo_title: text(70).nullable().optional(),
    seo_description: text(200).nullable().optional(),
  })
  .refine((p) => p.discount_price_bdt == null || p.discount_price_bdt < p.price_bdt, {
    message: "Discount price must be lower than the price",
    path: ["discount_price_bdt"],
  });
export type ProductInput = z.infer<typeof productInputSchema>;

/** File rules shared by the upload API routes. Limits mirror the storage bucket configuration. */
export const UPLOAD_RULES = {
  "product-images": { maxBytes: 5 * 1024 * 1024, types: ["image/jpeg", "image/png", "image/webp", "image/avif"], ext: ["jpg", "jpeg", "png", "webp", "avif"] },
  "product-models": { maxBytes: 25 * 1024 * 1024, types: ["model/gltf-binary", "application/octet-stream"], ext: ["glb"] },
  banners: { maxBytes: 5 * 1024 * 1024, types: ["image/jpeg", "image/png", "image/webp", "image/avif"], ext: ["jpg", "jpeg", "png", "webp", "avif"] },
  "customer-artwork": { maxBytes: 10 * 1024 * 1024, types: ["image/jpeg", "image/png", "image/webp", "application/pdf"], ext: ["jpg", "jpeg", "png", "webp", "pdf"] },
} as const;
export type UploadBucket = keyof typeof UPLOAD_RULES;

/** Magic-byte sniffing so a renamed file cannot pass as an image/GLB/PDF. */
export function sniffMime(bytes: Uint8Array): string | null {
  const b = bytes;
  if (b.length < 12) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  if (b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70 && b[8] === 0x61 && b[9] === 0x76 && b[10] === 0x69 && b[11] === 0x66) return "image/avif";
  if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return "application/pdf";
  if (b[0] === 0x67 && b[1] === 0x6c && b[2] === 0x54 && b[3] === 0x46) return "model/gltf-binary"; // "glTF"
  return null;
}

export function validateUpload(bucket: UploadBucket, file: { name: string; size: number; bytes: Uint8Array }):
  { ok: true; mime: string; ext: string } | { ok: false; error: string } {
  const rule = UPLOAD_RULES[bucket];
  if (file.size <= 0) return { ok: false, error: "The file is empty." };
  if (file.size > rule.maxBytes) return { ok: false, error: `File is too large (max ${Math.round(rule.maxBytes / 1048576)} MB).` };
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  if (!(rule.ext as readonly string[]).includes(ext)) return { ok: false, error: `Allowed file types: ${rule.ext.join(", ")}.` };
  const mime = sniffMime(file.bytes);
  if (!mime || !(rule.types as readonly string[]).includes(mime)) return { ok: false, error: "The file contents do not match an allowed type." };
  return { ok: true, mime, ext: ext === "jpeg" ? "jpg" : ext };
}
