/** Maps exceptions raised by the SQL order functions to messages safe to show customers. */
const MESSAGES: Record<string, (arg?: string) => string> = {
  EMPTY_CART: () => "Your cart is empty.",
  TOO_MANY_LINES: () => "Too many different items in one order. Please split it into two orders.",
  BAD_QUANTITY: () => "One of the quantities is not valid.",
  PRODUCT_UNAVAILABLE: () => "An item in your cart is no longer available. Please remove it and try again.",
  VARIANT_REQUIRED: (a) => `Please choose an option for ${a ?? "an item"}.`,
  VARIANT_UNAVAILABLE: (a) => `The selected option for ${a ?? "an item"} is no longer available.`,
  OUT_OF_STOCK: (a) => `${a ?? "An item"} does not have enough stock for this quantity.`,
  BAD_PRICE: () => "Pricing for an item is unavailable. Please contact us.",
  BAD_CUSTOMIZATION: () => "Your personalisation could not be read. Please re-enter it.",
  BAD_CUSTOMIZATION_FIELD: () => "Your personalisation contains a field this product does not support.",
  CUSTOMIZATION_NOT_ALLOWED: (a) => `${a ?? "This product"} cannot be personalised.`,
  CUSTOMIZATION_REQUIRED: (a) => `Please fill in “${a ?? "a required field"}”.`,
  CUSTOMIZATION_TOO_LONG: (a) => `“${a ?? "A field"}” is too long.`,
  CUSTOMIZATION_CHOICE_INVALID: (a) => `Please pick a valid choice for “${a ?? "a field"}”.`,
  LOGO_NOT_ALLOWED: (a) => `${a ?? "This product"} does not accept a logo.`,
  BAD_LOGO_PATH: () => "The uploaded logo could not be verified. Please upload it again.",
  COUPON_INVALID: () => "That coupon code is not valid or has expired.",
  COUPON_MIN_SUBTOTAL: (a) => `This coupon needs a minimum order of ৳${a ?? ""}.`,
  SHIPPING_NOT_CONFIGURED: () => "Delivery is not set up yet, so we cannot take orders online. Please contact us.",
  PAYMENT_METHOD_UNAVAILABLE: () => "That payment method is not available. Please choose Cash on Delivery.",
  ADDRESS_INCOMPLETE: () => "Please complete your delivery address.",
  CONTACT_INCOMPLETE: () => "Please enter your name and phone number.",
  AUTH_REQUIRED: () => "Please sign in to continue.",
  BAD_IDEMPOTENCY_KEY: () => "Something went wrong with your checkout session. Please refresh and try again.",
  CANCEL_NOT_ALLOWED: () => "This order can no longer be cancelled online. Please contact us.",
  ORDER_NOT_FOUND: () => "Order not found.",
  FORBIDDEN: () => "You do not have permission to do that.",
  BAD_TRANSITION: () => "That status change is not allowed from the order's current status.",
};

export function describeDbError(message: string | undefined | null): string {
  if (!message) return "Something went wrong. Please try again.";
  const match = /([A-Z_]{4,}):?\s*(.*)$/.exec(message.trim());
  const code = match?.[1];
  if (code && MESSAGES[code]) return MESSAGES[code](match?.[2]?.trim() || undefined);
  return "Something went wrong. Please try again.";
}
