import { describe, expect, it, beforeEach } from "vitest";
import { checkoutSchema, contactSchema, productInputSchema, sniffMime, trackSchema, validateUpload } from "@/lib/validation";
import { describeDbError } from "@/lib/db-errors";
import { rateLimit, resetRateLimits } from "@/lib/rate-limit";
import { formatBDT } from "@/lib/format";

const uuid = "3f2b8c1e-8a4d-4c1e-9d3a-1b2c3d4e5f60";
const base = {
  idempotency_key: "key-12345678",
  customer_name: "Rahim",
  customer_phone: "01712345678",
  address: { recipient_name: "Rahim", phone: "01712345678", line1: "Road 1", city: "Sylhet", district: "Sylhet" },
  payment_method: "cod" as const,
  items: [{ product_id: uuid, qty: 1 }],
};

describe("checkout validation", () => {
  it("accepts a valid COD order", () => expect(checkoutSchema.safeParse(base).success).toBe(true));
  it("rejects online payment until a gateway exists", () =>
    expect(checkoutSchema.safeParse({ ...base, payment_method: "online" }).success).toBe(false));
  it("rejects bad phone numbers, empty carts and absurd quantities", () => {
    expect(checkoutSchema.safeParse({ ...base, customer_phone: "12345" }).success).toBe(false);
    expect(checkoutSchema.safeParse({ ...base, items: [] }).success).toBe(false);
    expect(checkoutSchema.safeParse({ ...base, items: [{ product_id: uuid, qty: 1000 }] }).success).toBe(false);
  });
  it("accepts +88 phone prefixes", () =>
    expect(checkoutSchema.safeParse({ ...base, customer_phone: "+8801712345678" }).success).toBe(true));
  it("rejects unexpected customization keys", () => {
    const r = checkoutSchema.safeParse({ ...base, items: [{ product_id: uuid, qty: 1, customization: { lines: {}, price: 1 } }] });
    expect(r.success).toBe(false);
  });
});

describe("other schemas", () => {
  it("contact form needs a channel and rejects a filled honeypot", () => {
    expect(contactSchema.safeParse({ name: "A", message: "Hello there" }).success).toBe(false);
    expect(contactSchema.safeParse({ name: "A", phone: "01712345678", message: "Hello there" }).success).toBe(true);
    expect(contactSchema.safeParse({ name: "A", phone: "01712345678", message: "Hello there", website: "spam" }).success).toBe(false);
  });
  it("tracking normalises order numbers", () => {
    const r = trackSchema.parse({ order_number: " aw-1001 ", phone: "01712345678" });
    expect(r.order_number).toBe("AW-1001");
  });
  it("product discount must be below price", () => {
    const p = { sku: "A", name: "A", slug: "a", price_bdt: 100 };
    expect(productInputSchema.safeParse({ ...p, discount_price_bdt: 100 }).success).toBe(false);
    expect(productInputSchema.safeParse({ ...p, discount_price_bdt: 90 }).success).toBe(true);
  });
});

describe("upload validation", () => {
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0, 0]);
  const glb = new Uint8Array([0x67, 0x6c, 0x54, 0x46, 2, 0, 0, 0, 0, 0, 0, 0, 0]);
  it("accepts real PNG and GLB bytes", () => {
    expect(validateUpload("product-images", { name: "a.png", size: 100, bytes: png }).ok).toBe(true);
    expect(validateUpload("product-models", { name: "a.glb", size: 100, bytes: glb }).ok).toBe(true);
    expect(sniffMime(png)).toBe("image/png");
  });
  it("rejects renamed files, wrong types and oversize files", () => {
    expect(validateUpload("product-images", { name: "a.png", size: 100, bytes: glb }).ok).toBe(false);
    expect(validateUpload("product-images", { name: "a.exe", size: 100, bytes: png }).ok).toBe(false);
    expect(validateUpload("product-images", { name: "a.png", size: 6 * 1024 * 1024, bytes: png }).ok).toBe(false);
    expect(validateUpload("customer-artwork", { name: "a.svg", size: 100, bytes: png }).ok).toBe(false);
    expect(validateUpload("product-models", { name: "a.glb", size: 0, bytes: glb }).ok).toBe(false);
  });
});

describe("error mapping", () => {
  it("turns database codes into friendly messages", () => {
    expect(describeDbError("OUT_OF_STOCK:Gold Cup")).toContain("Gold Cup");
    expect(describeDbError("COUPON_INVALID")).toMatch(/coupon/i);
    expect(describeDbError("COUPON_MIN_SUBTOTAL:1000")).toContain("1000");
  });
  it("never leaks raw database errors", () => {
    expect(describeDbError('relation "orders" does not exist')).toBe("Something went wrong. Please try again.");
    expect(describeDbError(undefined)).toBe("Something went wrong. Please try again.");
  });
});

describe("rate limiter", () => {
  beforeEach(() => resetRateLimits());
  it("blocks after the limit and recovers after the window", () => {
    expect(rateLimit("k", 2, 1000, 0).ok).toBe(true);
    expect(rateLimit("k", 2, 1000, 10).ok).toBe(true);
    const blocked = rateLimit("k", 2, 1000, 20);
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfterSec).toBeGreaterThan(0);
    expect(rateLimit("k", 2, 1000, 1500).ok).toBe(true);
  });
  it("tracks keys independently", () => {
    rateLimit("a", 1, 1000, 0);
    expect(rateLimit("b", 1, 1000, 0).ok).toBe(true);
  });
});

describe("formatting", () => {
  it("formats taka", () => expect(formatBDT(1250)).toBe("৳1,250"));
  it("handles postgres numeric strings", () => expect(formatBDT("2060.00")).toBe("৳2,060"));
});

import { csvCell, toCsv } from "@/lib/csv";
describe("csv export", () => {
  it("neutralises spreadsheet formulas but keeps plain numbers", () => {
    expect(csvCell("=HYPERLINK(\"x\")")).toBe("\"'=HYPERLINK(\"\"x\"\")\"");
    expect(csvCell("+8801712345678")).toBe("'+8801712345678");
    expect(csvCell("-5")).toBe("-5");
    expect(csvCell("12.50")).toBe("12.50");
  });
  it("quotes commas and newlines and writes a BOM", () => {
    expect(csvCell("a,b")).toBe("\"a,b\"");
    expect(toCsv([["x", "y\nz"]]).startsWith("﻿")).toBe(true);
  });
});
