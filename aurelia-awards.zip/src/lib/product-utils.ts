import type { ProductSummary } from "@/lib/types";

export function hasModel(p: Pick<ProductSummary, "model">): boolean {
  return Array.isArray(p.model) ? p.model.length > 0 : Boolean(p.model);
}

export function isInStock(p: Pick<ProductSummary, "track_stock" | "stock_qty">): boolean {
  return !p.track_stock || p.stock_qty > 0;
}

export function sortedImages<T extends { sort_order: number }>(images: T[] | null | undefined): T[] {
  return [...(images ?? [])].sort((a, b) => a.sort_order - b.sort_order);
}
