import "server-only";
import { createClient } from "@supabase/supabase-js";
import { requireServiceRoleKey } from "@/lib/env";

/** Service-role client. Bypasses RLS. Server only; callers must authorize first. */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!url) throw new Error("NEXT_PUBLIC_SUPABASE_URL is not configured");
  return createClient(url, requireServiceRoleKey(), {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
