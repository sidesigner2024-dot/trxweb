/** Public URL for an object in a public bucket (product-images, product-models, banners). */
export function publicUrl(bucket: "product-images" | "product-models" | "banners", path: string): string {
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!base) return "";
  return `${base}/storage/v1/object/public/${bucket}/${path.split("/").map(encodeURIComponent).join("/")}`;
}
