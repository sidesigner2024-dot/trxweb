export type Category = {
  id: string; parent_id: string | null; name: string; slug: string;
  description: string | null; image_url: string | null; sort_order: number; is_active: boolean;
};

export type ProductImage = { id?: string; storage_path: string; alt_text: string; sort_order: number };
export type ProductVariant = { id: string; name: string; price_delta_bdt: number | string; stock_qty: number; is_active: boolean };
export type CustomizationOption = {
  id: string; field_key: string; label: string; field_type: "text" | "date" | "message" | "font" | "color";
  max_length: number; is_required: boolean; choices: string[] | null; sort_order: number;
};

export type ProductSummary = {
  id: string; slug: string; sku: string; name: string;
  price_bdt: number | string; discount_price_bdt: number | string | null;
  stock_qty: number; track_stock: boolean; is_customizable: boolean; is_sample: boolean; is_featured: boolean;
  category: { name: string; slug: string } | null;
  images: ProductImage[];
  model: { id: string }[] | { id: string } | null;
};

export type ProductDetail = Omit<ProductSummary, "model"> & {
  description: string; material: string | null; dimensions: string | null; weight_grams: number | null;
  production_days: number | null; allows_logo: boolean; seo_title: string | null; seo_description: string | null;
  category_id: string | null;
  variants: ProductVariant[];
  options: CustomizationOption[];
  model: { id: string; storage_path: string; scale: number | string } | null;
};

export type OrderRow = {
  id: string; order_number: string; status: string; payment_method: string; payment_status: string;
  subtotal_bdt: number | string; discount_bdt: number | string; shipping_bdt: number | string; total_bdt: number | string;
  coupon_code: string | null; customer_name: string; customer_phone: string; shipping_address: Record<string, string>;
  created_at: string;
};
