const bdt = new Intl.NumberFormat("en-BD", { maximumFractionDigits: 0 });

/** Formats a BDT amount, e.g. ৳1,250. Accepts numbers or numeric strings from Postgres. */
export function formatBDT(value: number | string | null | undefined): string {
  const n = typeof value === "string" ? Number(value) : (value ?? 0);
  return `৳${bdt.format(Number.isFinite(n) ? n : 0)}`;
}

export function effectivePrice(p: { price_bdt: number | string; discount_price_bdt?: number | string | null }): number {
  return Number(p.discount_price_bdt ?? p.price_bdt);
}

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  customization_review: "Customisation review",
  production: "In production",
  ready_to_ship: "Ready to ship",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
  refunded: "Refunded",
};
