import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/env";

export type Role = "customer" | "staff" | "admin";
export type AdminCtx = { supabase: Awaited<ReturnType<typeof createClient>>; userId: string; role: Role };
export type Result = { ok?: boolean; error?: string } | undefined;

/**
 * Authorization gate used by every admin page, action and route.
 * The role is read from the database for the verified session user, never from the browser.
 * RLS repeats the same checks, so a bug here still cannot grant data access on its own.
 */
export async function getAdminCtx(min: "staff" | "admin" = "staff"): Promise<AdminCtx | null> {
  if (!isSupabaseConfigured()) return null;
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  if (!data.user) return null;
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", data.user.id).maybeSingle();
  const role = (profile?.role as Role | undefined) ?? "customer";
  const ok = min === "admin" ? role === "admin" : role === "staff" || role === "admin";
  return ok ? { supabase, userId: data.user.id, role } : null;
}

/** For pages: redirect away when not allowed. */
export async function requireAdminPage(min: "staff" | "admin" = "staff"): Promise<AdminCtx> {
  const ctx = await getAdminCtx(min);
  if (!ctx) redirect("/login?next=/admin");
  return ctx;
}

/** For server actions: return an error result instead of redirecting. */
export async function guardAction(min: "staff" | "admin" = "staff"): Promise<{ ctx: AdminCtx } | { error: string }> {
  const ctx = await getAdminCtx(min);
  return ctx ? { ctx } : { error: "You do not have permission to do that." };
}

export async function audit(ctx: AdminCtx, action: string, entity: string, entityId?: string | null, details?: Record<string, unknown>) {
  await ctx.supabase.from("audit_logs").insert({ actor_id: ctx.userId, action, entity, entity_id: entityId ?? null, details: details ?? null });
}

export function slugify(s: string): string {
  return s.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g, "").trim().replace(/[\s_]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
}

export const str = (f: FormData, k: string) => { const v = f.get(k); return typeof v === "string" ? v.trim() : ""; };
export const num = (f: FormData, k: string): number | null => { const v = str(f, k); if (v === "") return null; const n = Number(v); return Number.isFinite(n) ? n : null; };
export const bool = (f: FormData, k: string) => f.get(k) === "on" || f.get(k) === "true";

/** Turns a Postgres/PostgREST error into a message safe to show staff. */
export function dbMessage(error: { code?: string; message?: string } | null | undefined): string {
  if (!error) return "Something went wrong.";
  if (error.code === "23505") return "That value is already in use (names, SKUs, slugs and codes must be unique).";
  if (error.code === "23503") return "This item is linked to other records and cannot be changed that way.";
  if (error.code === "23514") return "One of the values is outside the allowed range.";
  if (error.code === "42501") return "You do not have permission to do that.";
  return "Could not save. Please check the values and try again.";
}
