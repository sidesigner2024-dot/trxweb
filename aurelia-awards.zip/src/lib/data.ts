import "server-only";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/env";
import type { Category, ProductDetail, ProductSummary } from "@/lib/types";

export const PAGE_SIZE = 12;

const SUMMARY_COLUMNS =
  "id, slug, sku, name, price_bdt, discount_price_bdt, stock_qty, track_stock, is_customizable, is_sample, is_featured," +
  " category:categories!products_category_id_fkey(name, slug)," +
  " images:product_images(storage_path, alt_text, sort_order)," +
  " model:product_models(id)";

export type ProductQuery = {
  q?: string; category?: string; sort?: string; page?: number;
  min?: number; max?: number; customizable?: boolean; inStock?: boolean; featured?: boolean; limit?: number;
};

/** Strip characters that have meaning in PostgREST filter syntax. */
function cleanSearch(q: string): string {
  return q.replace(/[,()%*\\:"']/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export async function getCategories(): Promise<Category[]> {
  if (!isSupabaseConfigured()) return [];
  const supabase = await createClient();
  const { data } = await supabase.from("categories").select("*").eq("is_active", true).order("sort_order");
  return (data ?? []) as Category[];
}

export async function listProducts(query: ProductQuery = {}): Promise<{ items: ProductSummary[]; total: number; pageSize: number }> {
  if (!isSupabaseConfigured()) return { items: [], total: 0, pageSize: PAGE_SIZE };
  const supabase = await createClient();
  const pageSize = query.limit ?? PAGE_SIZE;
  const page = Math.max(1, query.page ?? 1);

  let categoryId: string | null = null;
  if (query.category) {
    const { data: cat } = await supabase.from("categories").select("id").eq("slug", query.category).maybeSingle();
    if (!cat) return { items: [], total: 0, pageSize };
    categoryId = cat.id as string;
  }

  let req = supabase.from("products").select(SUMMARY_COLUMNS, { count: "exact" }).eq("is_active", true);
  if (categoryId) req = req.or(`category_id.eq.${categoryId},subcategory_id.eq.${categoryId}`);
  const q = query.q ? cleanSearch(query.q) : "";
  if (q) req = req.or(`name.ilike.%${q}%,sku.ilike.%${q}%,material.ilike.%${q}%`);
  if (query.min != null) req = req.gte("price_bdt", query.min);
  if (query.max != null) req = req.lte("price_bdt", query.max);
  if (query.customizable) req = req.eq("is_customizable", true);
  if (query.featured) req = req.eq("is_featured", true);
  if (query.inStock) req = req.or("track_stock.eq.false,stock_qty.gt.0");

  switch (query.sort) {
    case "price-asc": req = req.order("price_bdt", { ascending: true }); break;
    case "price-desc": req = req.order("price_bdt", { ascending: false }); break;
    case "name": req = req.order("name", { ascending: true }); break;
    default: req = req.order("created_at", { ascending: false });
  }
  const from = (page - 1) * pageSize;
  const { data, count, error } = await req.range(from, from + pageSize - 1);
  if (error) return { items: [], total: 0, pageSize };
  return { items: (data ?? []) as unknown as ProductSummary[], total: count ?? 0, pageSize };
}

export async function getProductBySlug(slug: string): Promise<ProductDetail | null> {
  if (!isSupabaseConfigured()) return null;
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select(
      "*, category:categories!products_category_id_fkey(name, slug)," +
        " images:product_images(id, storage_path, alt_text, sort_order)," +
        " model:product_models(id, storage_path, scale)," +
        " variants:product_variants(id, name, price_delta_bdt, stock_qty, is_active)," +
        " options:customization_options(id, field_key, label, field_type, max_length, is_required, choices, sort_order)",
    )
    .eq("slug", slug)
    .eq("is_active", true)
    .maybeSingle();
  if (!data) return null;
  const row = data as unknown as Omit<ProductDetail, "model"> & { model: ProductDetail["model"] | NonNullable<ProductDetail["model"]>[] };
  const model = Array.isArray(row.model) ? (row.model[0] ?? null) : row.model;
  return {
    ...row,
    model,
    images: [...(row.images ?? [])].sort((a, b) => a.sort_order - b.sort_order),
    variants: (row.variants ?? []).filter((v) => v.is_active),
    options: [...(row.options ?? [])].sort((a, b) => a.sort_order - b.sort_order),
  };
}

export async function getRelatedProducts(categoryId: string | null, excludeId: string): Promise<ProductSummary[]> {
  if (!isSupabaseConfigured() || !categoryId) return [];
  const supabase = await createClient();
  const { data } = await supabase
    .from("products").select(SUMMARY_COLUMNS).eq("is_active", true).eq("category_id", categoryId).neq("id", excludeId).limit(4);
  return (data ?? []) as unknown as ProductSummary[];
}

export async function getSettings(): Promise<Record<string, Record<string, string>>> {
  if (!isSupabaseConfigured()) return {};
  const supabase = await createClient();
  const { data } = await supabase.from("site_settings").select("key, value");
  return Object.fromEntries((data ?? []).map((r) => [r.key as string, r.value as Record<string, string>]));
}

export async function getBanners() {
  if (!isSupabaseConfigured()) return [];
  const supabase = await createClient();
  const { data } = await supabase
    .from("banners").select("id, title, subtitle, image_path, link_url").eq("is_active", true).order("sort_order");
  return (data ?? []) as { id: string; title: string; subtitle: string | null; image_path: string | null; link_url: string | null }[];
}

/** Current user + role, or null. Role is read from the database, never from client-supplied data. */
export async function getSessionUser() {
  if (!isSupabaseConfigured()) return null;
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  if (!data.user) return null;
  const { data: profile } = await supabase.from("profiles").select("full_name, phone, role").eq("id", data.user.id).maybeSingle();
  return {
    id: data.user.id,
    email: data.user.email ?? "",
    fullName: (profile?.full_name as string) ?? "",
    phone: (profile?.phone as string | null) ?? null,
    role: ((profile?.role as string) ?? "customer") as "customer" | "staff" | "admin",
  };
}
