"use client";
import { useSyncExternalStore } from "react";

/**
 * Client-side cart. Holds only identifiers, quantity and customization input.
 * Display fields (name, price) are for rendering only: the server re-reads
 * every price, stock level and coupon from the database at checkout.
 */
export type CartCustomization = {
  lines: Record<string, string>;
  logo_path?: string; // private storage path returned by the upload API
};

export type CartLine = {
  key: string;
  productId: string;
  variantId: string | null;
  qty: number;
  name: string;
  imageUrl: string | null;
  unitPriceDisplay: number;
  customization?: CartCustomization;
};

const STORAGE_KEY = "aurelia.cart.v1";
const EMPTY: CartLine[] = [];
let cache: CartLine[] | null = null;
const listeners = new Set<() => void>();

function read(): CartLine[] {
  if (cache) return cache;
  try {
    const raw = typeof window === "undefined" ? null : window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? (JSON.parse(raw) as CartLine[]) : EMPTY;
    cache = Array.isArray(parsed) ? parsed : EMPTY;
  } catch {
    cache = EMPTY;
  }
  return cache;
}

function write(next: CartLine[]) {
  cache = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage unavailable (private mode). Cart still works for this session.
  }
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) {
      cache = null;
      cb();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(cb);
    window.removeEventListener("storage", onStorage);
  };
}

export function useCart(): CartLine[] {
  return useSyncExternalStore(subscribe, read, () => EMPTY);
}

export const cartActions = {
  add(line: Omit<CartLine, "key">) {
    const key = [line.productId, line.variantId ?? "-", JSON.stringify(line.customization ?? null)].join("|");
    const current = read();
    const existing = current.find((l) => l.key === key);
    if (existing) {
      write(current.map((l) => (l.key === key ? { ...l, qty: Math.min(l.qty + line.qty, 99) } : l)));
    } else {
      write([...current, { ...line, key }]);
    }
  },
  setQty(key: string, qty: number) {
    const q = Math.max(1, Math.min(99, Math.floor(qty)));
    write(read().map((l) => (l.key === key ? { ...l, qty: q } : l)));
  },
  remove(key: string) {
    write(read().filter((l) => l.key !== key));
  },
  clear() {
    write(EMPTY);
  },
};
