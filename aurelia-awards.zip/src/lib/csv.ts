/**
 * CSV builder. Cells that start with = + - @ (or tab/CR) are prefixed with an apostrophe so spreadsheet
 * programs cannot run them as formulas (CSV injection), since names and notes come from customers.
 * A UTF-8 BOM is added so Excel shows Bangla text correctly.
 */
export function csvCell(v: unknown): string {
  let s = v == null ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(rows: unknown[][]): string {
  return "﻿" + rows.map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n";
}
