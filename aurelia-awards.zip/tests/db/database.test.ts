import { beforeAll, describe, expect, it } from "vitest";
import { asUser, createDb, createUser, type Db } from "./harness";

let db: Db;
let customer: string, other: string, staff: string, admin: string;
let catId: string, plainProduct: string, limited: string, custom: string, variantProduct: string, variantA: string;

async function one<T = Record<string, unknown>>(sql: string, params: unknown[] = []) {
  const r = await db.query<T>(sql, params);
  return r.rows[0];
}

function payload(items: unknown[], extra: Record<string, unknown> = {}) {
  return {
    idempotency_key: crypto.randomUUID(),
    customer_name: "Test Buyer",
    customer_phone: "01700000000",
    payment_method: "cod",
    address: { recipient_name: "Test Buyer", phone: "01700000000", line1: "1 Test Road", city: "Sylhet", district: "Sylhet" },
    items,
    ...extra,
  };
}

async function place(userId: string, p: Record<string, unknown>) {
  return asUser(db, userId, async () => {
    const r = await db.query<{ place_order: { order_id: string; order_number: string; total: string; duplicate: boolean } }>(
      `select public.place_order($1::jsonb)`,
      [JSON.stringify(p)],
    );
    return r.rows[0].place_order;
  });
}

beforeAll(async () => {
  db = await createDb();
  customer = await createUser(db, "c@test.dev");
  other = await createUser(db, "o@test.dev");
  staff = await createUser(db, "s@test.dev", "staff");
  admin = await createUser(db, "a@test.dev", "admin");
  catId = (await one<{ id: string }>(`select id from public.categories where slug='medals'`)).id;

  const mk = async (sku: string, price: number, stock: number, extra = "") =>
    (await one<{ id: string }>(
      `insert into public.products (sku, name, slug, price_bdt, stock_qty, category_id ${extra ? "," + extra.split("|")[0] : ""})
       values ($1, $1, lower($1), $2, $3, $4 ${extra ? "," + extra.split("|")[1] : ""}) returning id`,
      [sku, price, stock, catId],
    )).id;
  plainProduct = await mk("PLAIN", 1000, 50);
  limited = await mk("LIMITED", 500, 2);
  custom = await mk("CUSTOM", 2000, 10, "is_customizable, allows_logo|true, true");
  await db.query(
    `insert into public.customization_options (product_id, field_key, label, field_type, max_length, is_required, choices) values
     ($1,'name','Recipient name','text',20,true,null),
     ($1,'font','Font','font',30,false,'["Serif","Script"]')`,
    [custom],
  );
  variantProduct = await mk("VARIANT", 3000, 0);
  variantA = (await one<{ id: string }>(
    `insert into public.product_variants (product_id, name, price_delta_bdt, stock_qty) values ($1,'Large',250,3) returning id`,
    [variantProduct],
  )).id;
  await db.query(`insert into public.products (sku,name,slug,price_bdt,is_active) values ('HIDDEN','Hidden','hidden',10,false)`);
  await db.query(`insert into public.coupons (code,type,value,min_subtotal_bdt,max_uses) values ('SAVE10','percent',10,1000,1)`);
});

describe("migrations", () => {
  it("apply cleanly and seed the 12 required categories", async () => {
    const r = await one<{ n: string }>(`select count(*) n from public.categories`);
    expect(Number(r.n)).toBe(12);
  });
  it("create a profile automatically for each auth user", async () => {
    const r = await one<{ role: string }>(`select role from public.profiles where id=$1`, [customer]);
    expect(r.role).toBe("customer");
  });
});

describe("row level security", () => {
  it("anonymous visitors see active products only", async () => {
    const rows = await asUser(db, null, async () => (await db.query<{ sku: string }>(`select sku from public.products`)).rows);
    expect(rows.map((r) => r.sku)).not.toContain("HIDDEN");
    expect(rows.map((r) => r.sku)).toContain("PLAIN");
  });
  it("staff can see hidden products", async () => {
    const rows = await asUser(db, staff, async () => (await db.query<{ sku: string }>(`select sku from public.products`)).rows);
    expect(rows.map((r) => r.sku)).toContain("HIDDEN");
  });
  it("customers cannot create or edit products", async () => {
    await expect(
      asUser(db, customer, () => db.query(`insert into public.products (sku,name,slug,price_bdt) values ('X','X','x',1)`)),
    ).rejects.toThrow(/row-level security/);
    const res = await asUser(db, customer, () => db.query(`update public.products set price_bdt = 1 where sku='PLAIN'`));
    expect(res.affectedRows).toBe(0);
  });
  it("customers cannot promote themselves; admins can promote others", async () => {
    await expect(
      asUser(db, customer, () => db.query(`update public.profiles set role='admin' where id=$1`, [customer])),
    ).rejects.toThrow(/FORBIDDEN/);
    await expect(
      asUser(db, staff, () => db.query(`update public.profiles set role='admin' where id=$1`, [staff])),
    ).rejects.toThrow(/FORBIDDEN/);
    await asUser(db, admin, () => db.query(`update public.profiles set role='staff' where id=$1`, [other]));
    expect((await one<{ role: string }>(`select role from public.profiles where id=$1`, [other])).role).toBe("staff");
    await db.query(`update public.profiles set role='customer' where id=$1`, [other]);
  });
  it("customers only read their own profile and addresses", async () => {
    const rows = await asUser(db, customer, async () => (await db.query(`select id from public.profiles`)).rows);
    expect(rows).toHaveLength(1);
  });
  it("coupons and audit logs are hidden from customers; settings are public", async () => {
    expect(await asUser(db, customer, async () => (await db.query(`select 1 from public.coupons`)).rows)).toHaveLength(0);
    expect(await asUser(db, customer, async () => (await db.query(`select 1 from public.audit_logs`)).rows)).toHaveLength(0);
    expect((await asUser(db, null, async () => (await db.query(`select 1 from public.site_settings`)).rows)).length).toBeGreaterThan(0);
  });
  it("customers cannot write orders directly", async () => {
    await expect(
      asUser(db, customer, () =>
        db.query(
          `insert into public.orders (user_id, idempotency_key, payment_method, subtotal_bdt, total_bdt, customer_name, customer_phone, shipping_address)
           values ($1,'abcdefgh1','cod',1,1,'x','y','{}')`,
          [customer],
        ),
      ),
    ).rejects.toThrow(/row-level security/);
  });
});

describe("storage policies", () => {
  it("customers can upload artwork only into their own folder", async () => {
    await asUser(db, customer, () =>
      db.query(`insert into storage.objects (bucket_id, name) values ('customer-artwork', $1)`, [`${customer}/logo.png`]));
    await expect(
      asUser(db, customer, () =>
        db.query(`insert into storage.objects (bucket_id, name) values ('customer-artwork', $1)`, [`${other}/logo.png`])),
    ).rejects.toThrow(/row-level security/);
  });
  it("other customers cannot read private artwork, staff can", async () => {
    const seen = (u: string) =>
      asUser(db, u, async () => (await db.query(`select name from storage.objects where bucket_id='customer-artwork'`)).rows.length);
    expect(await seen(other)).toBe(0);
    expect(await seen(staff)).toBeGreaterThan(0);
  });
  it("only staff can write catalogue media", async () => {
    await expect(
      asUser(db, customer, () => db.query(`insert into storage.objects (bucket_id, name) values ('product-images','a.png')`)),
    ).rejects.toThrow(/row-level security/);
    await asUser(db, staff, () => db.query(`insert into storage.objects (bucket_id, name) values ('product-images','a.png')`));
  });
});

describe("checkout", () => {
  it("refuses to take orders until shipping is configured", async () => {
    await expect(place(customer, payload([{ product_id: plainProduct, qty: 1 }]))).rejects.toThrow(/SHIPPING_NOT_CONFIGURED/);
  });

  describe("with shipping configured", () => {
    beforeAll(async () => {
      await db.query(`insert into public.shipping_zones (name, districts, fee_bdt, is_default) values ('Standard','{}',100,true)`);
      await db.query(`insert into public.shipping_zones (name, districts, fee_bdt) values ('Local','{Sylhet}',60)`);
    });

    it("computes totals on the server and decrements stock", async () => {
      const r = await place(customer, payload([{ product_id: plainProduct, qty: 2 }]));
      expect(Number(r.total)).toBe(2060); // 2 x 1000 + 60 local shipping
      expect((await one<{ stock_qty: number }>(`select stock_qty from public.products where id=$1`, [plainProduct])).stock_qty).toBe(48);
      const o = await one<{ status: string; payment_status: string; subtotal_bdt: string }>(
        `select status, payment_status, subtotal_bdt from public.orders where id=$1`, [r.order_id]);
      expect(o.status).toBe("pending");
      expect(o.payment_status).toBe("unpaid");
      expect(Number(o.subtotal_bdt)).toBe(2000);
    });

    it("ignores any client-supplied prices or totals", async () => {
      const r = await place(customer, payload([{ product_id: plainProduct, qty: 1, unit_price: 1, price: 1 }], { total: 1, subtotal: 1 }));
      expect(Number(r.total)).toBe(1060);
    });

    it("returns the same order for a repeated idempotency key", async () => {
      const p = payload([{ product_id: plainProduct, qty: 1 }]);
      const a = await place(customer, p);
      const b = await place(customer, p);
      expect(b.order_id).toBe(a.order_id);
      expect(b.duplicate).toBe(true);
    });

    it("never oversells", async () => {
      await place(customer, payload([{ product_id: limited, qty: 2 }]));
      await expect(place(customer, payload([{ product_id: limited, qty: 1 }]))).rejects.toThrow(/OUT_OF_STOCK/);
      expect((await one<{ stock_qty: number }>(`select stock_qty from public.products where id=$1`, [limited])).stock_qty).toBe(0);
    });

    it("rolls back stock when a later line fails", async () => {
      const before = (await one<{ stock_qty: number }>(`select stock_qty from public.products where id=$1`, [plainProduct])).stock_qty;
      await expect(
        place(customer, payload([{ product_id: plainProduct, qty: 1 }, { product_id: limited, qty: 1 }])),
      ).rejects.toThrow(/OUT_OF_STOCK/);
      const after = (await one<{ stock_qty: number }>(`select stock_qty from public.products where id=$1`, [plainProduct])).stock_qty;
      expect(after).toBe(before);
    });

    it("requires a variant when the product has variants, and prices it", async () => {
      await expect(place(customer, payload([{ product_id: variantProduct, qty: 1 }]))).rejects.toThrow(/VARIANT_REQUIRED/);
      const r = await place(customer, payload([{ product_id: variantProduct, variant_id: variantA, qty: 2 }]));
      expect(Number(r.total)).toBe(2 * 3250 + 60);
      expect((await one<{ stock_qty: number }>(`select stock_qty from public.product_variants where id=$1`, [variantA])).stock_qty).toBe(1);
    });

    it("rejects hidden products, bad quantities, empty carts and online payment", async () => {
      const hidden = (await one<{ id: string }>(`select id from public.products where sku='HIDDEN'`)).id;
      await expect(place(customer, payload([{ product_id: hidden, qty: 1 }]))).rejects.toThrow(/PRODUCT_UNAVAILABLE/);
      await expect(place(customer, payload([{ product_id: plainProduct, qty: 0 }]))).rejects.toThrow(/BAD_QUANTITY/);
      await expect(place(customer, payload([]))).rejects.toThrow(/EMPTY_CART/);
      await expect(place(customer, payload([{ product_id: plainProduct, qty: 1 }], { payment_method: "online" })))
        .rejects.toThrow(/PAYMENT_METHOD_UNAVAILABLE/);
    });

    it("requires a signed-in customer", async () => {
      await expect(
        asUser(db, null, () => db.query(`select public.place_order($1::jsonb)`, [JSON.stringify(payload([{ product_id: plainProduct, qty: 1 }]))])),
      ).rejects.toThrow(/permission denied/);
    });

    it("applies coupons, enforces minimum and usage limits", async () => {
      const cheap = (await one<{ id: string }>(`insert into public.products (sku,name,slug,price_bdt,stock_qty) values ('CHEAP','Cheap','cheap',100,50) returning id`)).id;
      await expect(place(customer, payload([{ product_id: plainProduct, qty: 1 }], { coupon_code: "NOPE" }))).rejects.toThrow(/COUPON_INVALID/);
      await expect(place(customer, payload([{ product_id: cheap, qty: 1 }], { coupon_code: "SAVE10" }))).rejects.toThrow(/COUPON_MIN_SUBTOTAL/);
      const r = await place(customer, payload([{ product_id: plainProduct, qty: 2 }], { coupon_code: "save10" }));
      expect(Number(r.total)).toBe(2000 - 200 + 60);
      await expect(place(customer, payload([{ product_id: plainProduct, qty: 2 }], { coupon_code: "SAVE10" }))).rejects.toThrow(/COUPON_INVALID/);
    });

    it("validates customization against admin-defined options", async () => {
      const mk = (c: unknown) => payload([{ product_id: custom, qty: 1, customization: c }]);
      await expect(place(customer, mk(null))).rejects.toThrow(/CUSTOMIZATION_REQUIRED/);
      await expect(place(customer, mk({ lines: { name: "x".repeat(21) } }))).rejects.toThrow(/CUSTOMIZATION_TOO_LONG/);
      await expect(place(customer, mk({ lines: { name: "Ann", font: "Comic" } }))).rejects.toThrow(/CHOICE_INVALID/);
      await expect(place(customer, mk({ lines: { name: "Ann", evil: "1" } }))).rejects.toThrow(/BAD_CUSTOMIZATION_FIELD/);
      await expect(place(customer, mk({ lines: { name: "Ann" }, logo_path: `${other}/logo.png` }))).rejects.toThrow(/BAD_LOGO_PATH/);
      await expect(
        place(customer, payload([{ product_id: plainProduct, qty: 1, customization: { lines: { name: "A" } } }])),
      ).rejects.toThrow(/CUSTOMIZATION_NOT_ALLOWED/);
      const ok = await place(customer, mk({ lines: { name: "Ann", font: "Script" }, logo_path: `${customer}/logo.png` }));
      const d = await one<{ status: string; data: { name: string } }>(
        `select cd.status, cd.data from public.custom_designs cd join public.order_items oi on oi.id=cd.order_item_id where oi.order_id=$1`, [ok.order_id]);
      expect(d.status).toBe("pending");
      expect(d.data.name).toBe("Ann");
    });

    it("notifies the customer and staff", async () => {
      const r = await place(customer, payload([{ product_id: plainProduct, qty: 1 }]));
      const mine = await asUser(db, customer, async () => (await db.query(`select title from public.notifications`)).rows);
      expect(mine.length).toBeGreaterThan(0);
      const staffN = await asUser(db, staff, async () => (await db.query(`select link from public.notifications where audience='staff'`)).rows);
      expect(JSON.stringify(staffN)).toContain(r.order_id);
      expect(await asUser(db, other, async () => (await db.query(`select 1 from public.notifications`)).rows)).toHaveLength(0);
    });

    it("keeps orders private between customers", async () => {
      expect(await asUser(db, other, async () => (await db.query(`select 1 from public.orders`)).rows)).toHaveLength(0);
      expect((await asUser(db, customer, async () => (await db.query(`select 1 from public.orders`)).rows)).length).toBeGreaterThan(0);
      expect((await asUser(db, staff, async () => (await db.query(`select 1 from public.orders`)).rows)).length).toBeGreaterThan(0);
    });

    describe("order lifecycle", () => {
      let orderId: string;
      beforeAll(async () => {
        const p = await one<{ id: string }>(`insert into public.products (sku,name,slug,price_bdt,stock_qty) values ('LIFE','Life','life',100,5) returning id`);
        orderId = (await place(customer, payload([{ product_id: p.id, qty: 2 }]))).order_id;
      });
      const setStatus = (u: string, s: string) =>
        asUser(db, u, () => db.query(`select public.set_order_status($1, $2::public.order_status, 'note')`, [orderId, s]));

      it("only staff may change status", async () => {
        await expect(setStatus(customer, "confirmed")).rejects.toThrow(/FORBIDDEN/);
      });
      it("rejects invalid transitions", async () => {
        await expect(setStatus(staff, "delivered")).rejects.toThrow(/BAD_TRANSITION/);
      });
      it("walks the happy path, records events and COD payment on delivery", async () => {
        for (const s of ["confirmed", "production", "ready_to_ship", "shipped", "delivered"]) await setStatus(staff, s);
        const o = await one<{ status: string; payment_status: string }>(`select status, payment_status from public.orders where id=$1`, [orderId]);
        expect(o).toEqual({ status: "delivered", payment_status: "paid" });
        const ev = await one<{ n: string }>(`select count(*) n from public.order_events where order_id=$1`, [orderId]);
        expect(Number(ev.n)).toBe(6);
        const pay = await one<{ status: string }>(`select status from public.payments where order_id=$1`, [orderId]);
        expect(pay.status).toBe("succeeded");
        const audit = await asUser(db, admin, async () => (await db.query(`select 1 from public.audit_logs where entity_id=$1`, [orderId])).rows);
        expect(audit.length).toBeGreaterThan(0);
      });
      it("hides gateway payloads from customers", async () => {
        await expect(asUser(db, customer, () => db.query(`select raw from public.payments`))).rejects.toThrow(/permission denied/);
        expect((await asUser(db, customer, async () => (await db.query(`select status from public.payments`)).rows)).length).toBeGreaterThan(0);
      });
      it("verified buyers can review; others cannot", async () => {
        const pid = (await one<{ id: string }>(`select id from public.products where sku='LIFE'`)).id;
        await asUser(db, customer, () => db.query(`insert into public.reviews (product_id,user_id,rating) values ($1,$2,5)`, [pid, customer]));
        await expect(
          asUser(db, other, () => db.query(`insert into public.reviews (product_id,user_id,rating) values ($1,$2,5)`, [pid, other])),
        ).rejects.toThrow(/row-level security/);
        expect(await asUser(db, null, async () => (await db.query(`select 1 from public.reviews`)).rows)).toHaveLength(0); // unapproved
      });
    });

    it("customers can cancel only pending orders and stock is restored (coupon too)", async () => {
      const p = await one<{ id: string }>(`insert into public.products (sku,name,slug,price_bdt,stock_qty) values ('CANCEL','Cancel','cancel',100,5) returning id`);
      const r = await place(customer, payload([{ product_id: p.id, qty: 3 }]));
      await expect(
        asUser(db, other, () => db.query(`select public.cancel_my_order($1)`, [r.order_id])),
      ).rejects.toThrow(/ORDER_NOT_FOUND/);
      await asUser(db, customer, () => db.query(`select public.cancel_my_order($1)`, [r.order_id]));
      expect((await one<{ stock_qty: number }>(`select stock_qty from public.products where id=$1`, [p.id])).stock_qty).toBe(5);
      const r2 = await place(customer, payload([{ product_id: p.id, qty: 1 }]));
      await asUser(db, staff, () => db.query(`select public.set_order_status($1,'confirmed')`, [r2.order_id]));
      await expect(
        asUser(db, customer, () => db.query(`select public.cancel_my_order($1)`, [r2.order_id])),
      ).rejects.toThrow(/CANCEL_NOT_ALLOWED/);
    });

    it("lets customers resubmit designs only after a revision request", async () => {
      const r = await place(customer, payload([{ product_id: custom, qty: 1, customization: { lines: { name: "Bo" } } }]));
      const d = await one<{ id: string }>(
        `select cd.id from public.custom_designs cd join public.order_items oi on oi.id=cd.order_item_id where oi.order_id=$1`, [r.order_id]);
      await expect(
        asUser(db, customer, () => db.query(`update public.custom_designs set data='{"name":"Hacked"}' where id=$1`, [d.id])),
      ).resolves.toMatchObject({ affectedRows: 0 });
      await asUser(db, staff, () => db.query(`update public.custom_designs set status='revision_requested', admin_note='Shorter name' where id=$1`, [d.id]));
      await asUser(db, customer, () => db.query(`update public.custom_designs set data='{"name":"B"}', status='pending' where id=$1`, [d.id]));
      await expect(
        asUser(db, customer, () => db.query(`update public.custom_designs set status='approved' where id=$1`, [d.id])),
      ).resolves.toMatchObject({ affectedRows: 0 });
    });
  });
});

describe("admin permissions", () => {
  it("staff cannot manage coupons, shipping or settings; admins can", async () => {
    await expect(asUser(db, staff, () => db.query(`insert into public.coupons (code,type,value) values ('STAFFMADE','fixed',5)`))).rejects.toThrow(/row-level security/);
    expect((await asUser(db, staff, () => db.query(`update public.site_settings set value='{}' where key='general'`))).affectedRows).toBe(0);
    await expect(asUser(db, staff, () => db.query(`insert into public.shipping_zones (name,fee_bdt) values ('x',1)`))).rejects.toThrow(/row-level security/);
    await asUser(db, admin, () => db.query(`insert into public.coupons (code,type,value) values ('ADMINMADE','fixed',5)`));
    await asUser(db, admin, () => db.query(`update public.site_settings set value='{"site_name":"X"}' where key='general'`));
  });
  it("staff can manage banners, categories and showroom; customers cannot", async () => {
    await asUser(db, staff, () => db.query(`insert into public.banners (title) values ('Sale')`));
    await asUser(db, staff, () => db.query(`insert into public.showroom_rooms (name, slug) values ('Main','main')`));
    await expect(asUser(db, customer, () => db.query(`insert into public.banners (title) values ('Hack')`))).rejects.toThrow(/row-level security/);
    await expect(asUser(db, customer, () => db.query(`insert into public.showroom_rooms (name, slug) values ('Hack','hack')`))).rejects.toThrow(/row-level security/);
  });
  it("visitors see active banners and rooms; inactive ones stay hidden", async () => {
    await db.query(`insert into public.banners (title, is_active) values ('Hidden banner', false)`);
    const titles = (await asUser(db, null, async () => (await db.query<{ title: string }>(`select title from public.banners`)).rows)).map((r) => r.title);
    expect(titles).toContain("Sale");
    expect(titles).not.toContain("Hidden banner");
  });
  it("staff alerts are invisible to customers; audit entries must be attributed to the writer", async () => {
    expect(await asUser(db, customer, async () => (await db.query(`select 1 from public.notifications where audience='staff'`)).rows)).toHaveLength(0);
    await expect(asUser(db, staff, () => db.query(`insert into public.audit_logs (actor_id, action, entity) values ($1,'x','y')`, [admin]))).rejects.toThrow(/row-level security/);
    await asUser(db, staff, () => db.query(`insert into public.audit_logs (actor_id, action, entity) values ($1,'x','y')`, [staff]));
    expect(await asUser(db, staff, async () => (await db.query(`select 1 from public.audit_logs`)).rows)).toHaveLength(0); // staff cannot read the log
  });
  it("contact messages cannot be inserted by visitors directly (only via the server route)", async () => {
    await expect(asUser(db, null, () => db.query(`insert into public.contact_messages (name, email, message) values ('a','a@b.c','hello')`))).rejects.toThrow(/permission denied|row-level security/);
  });
  it("shipping zones are readable by visitors; wishlists are private", async () => {
    expect((await asUser(db, null, async () => (await db.query(`select 1 from public.shipping_zones`)).rows)).length).toBeGreaterThan(0);
    const pid = (await one<{ id: string }>(`select id from public.products where sku='PLAIN'`)).id;
    await asUser(db, customer, () => db.query(`insert into public.wishlists (user_id, product_id) values ($1,$2)`, [customer, pid]));
    expect(await asUser(db, other, async () => (await db.query(`select 1 from public.wishlists`)).rows)).toHaveLength(0);
    await expect(asUser(db, other, () => db.query(`insert into public.wishlists (user_id, product_id) values ($1,$2)`, [customer, pid]))).rejects.toThrow(/row-level security/);
  });
});
