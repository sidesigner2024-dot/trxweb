-- OPTIONAL development sample data. NOT a migration: run it manually in the SQL editor only on a
-- test project. Every row is flagged is_sample = true, so the shop labels it "Sample" and
-- it is obvious in the admin list. Prices are placeholders, not real offers.
-- Remove with:  delete from public.products where is_sample;

insert into public.products (sku, name, slug, description, category_id, price_bdt, stock_qty, material, dimensions, is_customizable, allows_logo, is_featured, production_days, is_sample)
select v.sku, v.name, v.slug, 'Sample listing for development previews.', c.id, v.price, v.stock, v.material, v.dims, v.custom, v.custom, true, v.days, true
from (values
  ('SAMPLE-TRO-001','Sample Gold Cup Trophy','sample-gold-cup-trophy','luxury-trophies',4500,12,'Brass, marble base','30 cm',true,5),
  ('SAMPLE-CRE-001','Sample Wooden Crest','sample-wooden-crest','wooden-crests',3200,20,'Teak wood','25 x 20 cm',true,4),
  ('SAMPLE-CRY-001','Sample Crystal Award','sample-crystal-award','crystal-awards',5800,8,'Optical crystal','22 cm',true,6)
) as v(sku,name,slug,cat,price,stock,material,dims,custom,days)
join public.categories c on c.slug = v.cat
on conflict (sku) do nothing;

-- Personalisation fields for the sample products
insert into public.customization_options (product_id, field_key, label, field_type, max_length, is_required, choices, sort_order)
select p.id, o.key, o.label, o.type, o.maxlen, o.req, o.choices::jsonb, o.sort
from public.products p
cross join (values
  ('recipient','Recipient name','text',40,true,null,1),
  ('title','Award title','text',60,false,null,2),
  ('award_date','Date','date',10,false,null,3),
  ('message','Message','message',140,false,null,4),
  ('font','Font','font',20,false,'["Serif","Script","Sans"]',5)
) as o(key,label,type,maxlen,req,choices,sort)
where p.is_sample
on conflict (product_id, field_key) do nothing;
