-- 0002_rls.sql : role helpers, guard triggers, Row Level Security policies.
-- Every table has RLS enabled. Tables with no policy for a role are inaccessible to that role.

create or replace function public.current_app_role() returns text
language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = '' as $$
  select coalesce((select role in ('staff','admin') from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false)
$$;

-- anon must be able to evaluate these because public-read policies call them; with no signed-in user they return false/null.
revoke execute on function public.current_app_role(), public.is_staff(), public.is_admin() from public;
grant execute on function public.current_app_role(), public.is_staff(), public.is_admin() to anon, authenticated;

-- ---- guard: only admins may change roles (SQL editor / service role have no auth.uid()) ----
create or replace function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'FORBIDDEN: only admins can change roles';
  end if;
  if new.id is distinct from old.id then raise exception 'FORBIDDEN'; end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.profiles_guard();

-- ---- guard: customers may only resubmit a design after staff requested a revision ----
create or replace function public.custom_designs_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null or public.is_staff() then
    if public.is_staff() and new.status is distinct from old.status then
      new.reviewed_by := auth.uid();
      new.reviewed_at := now();
    end if;
    return new;
  end if;
  if old.status <> 'revision_requested' or new.status <> 'pending'
     or new.order_item_id is distinct from old.order_item_id
     or new.admin_note is distinct from old.admin_note
     or new.reviewed_by is distinct from old.reviewed_by
     or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'FORBIDDEN: designs can only be resubmitted after a revision request';
  end if;
  if new.logo_path is not null and new.logo_path <> coalesce(old.logo_path, '')
     and new.logo_path not like auth.uid()::text || '/%' then
    raise exception 'FORBIDDEN: logo must be in your own upload folder';
  end if;
  return new;
end $$;
create trigger custom_designs_guard before update on public.custom_designs
  for each row execute function public.custom_designs_guard();

-- ---- enable RLS everywhere ----
alter table public.roles enable row level security;
alter table public.profiles enable row level security;
alter table public.addresses enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.product_models enable row level security;
alter table public.product_variants enable row level security;
alter table public.customization_options enable row level security;
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;
alter table public.wishlists enable row level security;
alter table public.coupons enable row level security;
alter table public.shipping_zones enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_events enable row level security;
alter table public.payments enable row level security;
alter table public.shipments enable row level security;
alter table public.custom_designs enable row level security;
alter table public.reviews enable row level security;
alter table public.notifications enable row level security;
alter table public.contact_messages enable row level security;
alter table public.showroom_rooms enable row level security;
alter table public.showroom_displays enable row level security;
alter table public.banners enable row level security;
alter table public.site_settings enable row level security;
alter table public.audit_logs enable row level security;

-- ---- roles / profiles / addresses ----
create policy roles_read on public.roles for select to authenticated using (true);

create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_staff());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());
revoke update on public.profiles from authenticated;
grant update (full_name, phone, role) on public.profiles to authenticated;

create policy addresses_own on public.addresses for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy addresses_staff_read on public.addresses for select to authenticated using (public.is_staff());

-- ---- catalogue: public read of active rows, staff manage ----
create policy categories_read on public.categories for select using (is_active or public.is_staff());
create policy categories_staff on public.categories for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy products_read on public.products for select using (is_active or public.is_staff());
create policy products_staff on public.products for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy product_images_read on public.product_images for select
  using (public.is_staff() or exists (select 1 from public.products p where p.id = product_id and p.is_active));
create policy product_images_staff on public.product_images for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy product_models_read on public.product_models for select
  using (public.is_staff() or exists (select 1 from public.products p where p.id = product_id and p.is_active));
create policy product_models_staff on public.product_models for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy product_variants_read on public.product_variants for select
  using (public.is_staff() or (is_active and exists (select 1 from public.products p where p.id = product_id and p.is_active)));
create policy product_variants_staff on public.product_variants for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy customization_options_read on public.customization_options for select
  using (public.is_staff() or exists (select 1 from public.products p where p.id = product_id and p.is_active));
create policy customization_options_staff on public.customization_options for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- ---- carts / wishlists: owner only ----
create policy carts_own on public.carts for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_items_own on public.cart_items for all to authenticated
  using (exists (select 1 from public.carts c where c.id = cart_id and c.user_id = auth.uid()))
  with check (exists (select 1 from public.carts c where c.id = cart_id and c.user_id = auth.uid()));
create policy wishlists_own on public.wishlists for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---- coupons / shipping ----
create policy coupons_admin on public.coupons for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy coupons_staff_read on public.coupons for select to authenticated using (public.is_staff());
create policy shipping_read on public.shipping_zones for select using (is_active or public.is_staff());
create policy shipping_admin on public.shipping_zones for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---- orders: customers read their own; all writes go through SECURITY DEFINER functions ----
create policy orders_read on public.orders for select to authenticated
  using (user_id = auth.uid() or public.is_staff());
create policy order_items_read on public.order_items for select to authenticated
  using (public.is_staff() or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy order_events_read on public.order_events for select to authenticated
  using (public.is_staff() or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));

create policy payments_read on public.payments for select to authenticated
  using (public.is_staff() or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
revoke select on public.payments from authenticated;
grant select (id, order_id, provider, provider_ref, amount_bdt, status, created_at) on public.payments to authenticated;

create policy shipments_read on public.shipments for select to authenticated
  using (public.is_staff() or exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy shipments_staff on public.shipments for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy custom_designs_read on public.custom_designs for select to authenticated
  using (public.is_staff() or exists (
    select 1 from public.order_items oi join public.orders o on o.id = oi.order_id
    where oi.id = order_item_id and o.user_id = auth.uid()));
create policy custom_designs_staff_update on public.custom_designs for update to authenticated
  using (public.is_staff()) with check (public.is_staff());
create policy custom_designs_owner_resubmit on public.custom_designs for update to authenticated
  using (status = 'revision_requested' and exists (
    select 1 from public.order_items oi join public.orders o on o.id = oi.order_id
    where oi.id = order_item_id and o.user_id = auth.uid()))
  with check (status = 'pending');

-- ---- reviews ----
create policy reviews_read on public.reviews for select
  using (is_approved or user_id = auth.uid() or public.is_staff());
create policy reviews_insert on public.reviews for insert to authenticated
  with check (
    user_id = auth.uid() and is_approved = false and exists (
      select 1 from public.order_items oi join public.orders o on o.id = oi.order_id
      where o.user_id = auth.uid() and oi.product_id = reviews.product_id and o.status = 'delivered'))
;
create policy reviews_staff_update on public.reviews for update to authenticated
  using (public.is_staff()) with check (public.is_staff());
create policy reviews_delete on public.reviews for delete to authenticated
  using (user_id = auth.uid() or public.is_staff());

-- ---- notifications ----
create policy notifications_read on public.notifications for select to authenticated
  using (user_id = auth.uid() or (audience = 'staff' and public.is_staff()));
create policy notifications_mark_read on public.notifications for update to authenticated
  using (user_id = auth.uid() or (audience = 'staff' and public.is_staff()))
  with check (user_id = auth.uid() or (audience = 'staff' and public.is_staff()));
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;

-- ---- contact messages: inserted by the server route (service role); staff manage ----
create policy contact_staff_read on public.contact_messages for select to authenticated using (public.is_staff());
create policy contact_staff_update on public.contact_messages for update to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- ---- showroom / banners / settings ----
create policy showroom_rooms_read on public.showroom_rooms for select using (is_active or public.is_staff());
create policy showroom_rooms_staff on public.showroom_rooms for all to authenticated
  using (public.is_staff()) with check (public.is_staff());
create policy showroom_displays_read on public.showroom_displays for select using (is_active or public.is_staff());
create policy showroom_displays_staff on public.showroom_displays for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy banners_read on public.banners for select
  using (public.is_staff() or (is_active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())));
create policy banners_staff on public.banners for all to authenticated
  using (public.is_staff()) with check (public.is_staff());

create policy settings_read on public.site_settings for select using (true);
create policy settings_admin on public.site_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---- audit logs: admins read; staff append rows attributed to themselves ----
create policy audit_admin_read on public.audit_logs for select to authenticated using (public.is_admin());
create policy audit_staff_insert on public.audit_logs for insert to authenticated
  with check (public.is_staff() and actor_id = auth.uid());
