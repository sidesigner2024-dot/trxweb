-- 0004_orders.sql : authoritative pricing, atomic order placement and status transitions.
-- The browser never supplies prices, totals, discounts or payment state. Everything is recomputed
-- here, inside one transaction, with row locks to prevent overselling.

-- ---------- pricing (read-only, no side effects) ----------
create or replace function public.price_items(p_items jsonb, p_coupon text, p_district text)
returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  it jsonb; prod record; var record; opt record; cpn record; zone record;
  v_lines jsonb := '[]'::jsonb;
  v_qty int; v_unit numeric(12,2); v_subtotal numeric(12,2) := 0;
  v_has_variants boolean; v_discount numeric(12,2) := 0; v_shipping numeric(12,2);
  v_custom jsonb; v_lines_obj jsonb; v_val text; v_key text; v_stock int;
  v_variant_name text; v_variant_id uuid; v_coupon_code text := null;
begin
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'EMPTY_CART';
  end if;
  if jsonb_array_length(p_items) > 50 then raise exception 'TOO_MANY_LINES'; end if;

  for it in select * from jsonb_array_elements(p_items) loop
    v_qty := (it->>'qty')::int;
    if v_qty is null or v_qty < 1 or v_qty > 99 then raise exception 'BAD_QUANTITY'; end if;

    select * into prod from public.products where id = (it->>'product_id')::uuid and is_active;
    if not found then raise exception 'PRODUCT_UNAVAILABLE'; end if;

    v_unit := coalesce(prod.discount_price_bdt, prod.price_bdt);
    v_variant_name := null;
    v_variant_id := null;
    select exists (select 1 from public.product_variants where product_id = prod.id and is_active) into v_has_variants;
    if v_has_variants then
      if coalesce(it->>'variant_id','') = '' then raise exception 'VARIANT_REQUIRED:%', prod.name; end if;
      select * into var from public.product_variants
        where id = (it->>'variant_id')::uuid and product_id = prod.id and is_active;
      if not found then raise exception 'VARIANT_UNAVAILABLE:%', prod.name; end if;
      v_unit := v_unit + var.price_delta_bdt;
      v_variant_name := var.name;
      v_variant_id := var.id;
      v_stock := var.stock_qty;
    else
      if coalesce(it->>'variant_id','') <> '' then raise exception 'VARIANT_UNAVAILABLE:%', prod.name; end if;
      v_stock := prod.stock_qty;
    end if;
    if v_unit < 0 then raise exception 'BAD_PRICE'; end if;
    if prod.track_stock and v_stock < v_qty then raise exception 'OUT_OF_STOCK:%', prod.name; end if;

    -- customization is validated against the options the admin configured for this product
    v_custom := coalesce(nullif(it->'customization', 'null'::jsonb), '{}'::jsonb);
    if jsonb_typeof(v_custom) <> 'object' then raise exception 'BAD_CUSTOMIZATION'; end if;
    if char_length(v_custom::text) > 4000 then raise exception 'BAD_CUSTOMIZATION'; end if;
    v_lines_obj := coalesce(v_custom->'lines', '{}'::jsonb);
    if jsonb_typeof(v_lines_obj) <> 'object' then raise exception 'BAD_CUSTOMIZATION'; end if;

    if not prod.is_customizable then
      if v_custom <> '{}'::jsonb then raise exception 'CUSTOMIZATION_NOT_ALLOWED:%', prod.name; end if;
    else
      if coalesce(v_custom->>'logo_path','') <> '' and not prod.allows_logo then
        raise exception 'LOGO_NOT_ALLOWED:%', prod.name;
      end if;
      for v_key in select jsonb_object_keys(v_lines_obj) loop
        if not exists (select 1 from public.customization_options where product_id = prod.id and field_key = v_key) then
          raise exception 'BAD_CUSTOMIZATION_FIELD:%', v_key;
        end if;
      end loop;
      for opt in select * from public.customization_options where product_id = prod.id loop
        v_val := nullif(btrim(v_lines_obj->>opt.field_key), '');
        if opt.is_required and v_val is null then raise exception 'CUSTOMIZATION_REQUIRED:%', opt.label; end if;
        if v_val is not null and char_length(v_val) > opt.max_length then
          raise exception 'CUSTOMIZATION_TOO_LONG:%', opt.label;
        end if;
        if v_val is not null and opt.field_type in ('font','color') and opt.choices is not null
           and not (opt.choices ? v_val) then
          raise exception 'CUSTOMIZATION_CHOICE_INVALID:%', opt.label;
        end if;
      end loop;
    end if;

    v_lines := v_lines || jsonb_build_array(jsonb_build_object(
      'product_id', prod.id, 'variant_id', v_variant_id, 'name', prod.name, 'variant_name', v_variant_name,
      'sku', prod.sku, 'unit_price', v_unit, 'qty', v_qty, 'line_total', v_unit * v_qty,
      'track_stock', prod.track_stock, 'customization', nullif(v_custom, '{}'::jsonb)));
    v_subtotal := v_subtotal + v_unit * v_qty;
  end loop;

  if coalesce(p_coupon, '') <> '' then
    select * into cpn from public.coupons
      where code = upper(btrim(p_coupon)) and is_active
        and (starts_at is null or starts_at <= now())
        and (expires_at is null or expires_at > now())
        and (max_uses is null or used_count < max_uses);
    if not found then raise exception 'COUPON_INVALID'; end if;
    if v_subtotal < cpn.min_subtotal_bdt then raise exception 'COUPON_MIN_SUBTOTAL:%', cpn.min_subtotal_bdt; end if;
    v_discount := case when cpn.type = 'percent' then round(v_subtotal * cpn.value / 100, 2)
                       else least(cpn.value, v_subtotal) end;
    v_coupon_code := cpn.code;
  end if;

  select * into zone from public.shipping_zones
    where is_active and lower(coalesce(p_district,'')) = any (select lower(d) from unnest(districts) d)
    order by fee_bdt limit 1;
  if not found then
    select * into zone from public.shipping_zones where is_active and is_default limit 1;
  end if;
  if not found then raise exception 'SHIPPING_NOT_CONFIGURED'; end if;
  v_shipping := case when zone.free_over_bdt is not null and (v_subtotal - v_discount) >= zone.free_over_bdt
                     then 0 else zone.fee_bdt end;

  return jsonb_build_object(
    'lines', v_lines, 'subtotal', v_subtotal, 'discount', v_discount, 'shipping', v_shipping,
    'total', v_subtotal - v_discount + v_shipping, 'coupon_code', v_coupon_code, 'zone', zone.name);
end $$;
revoke execute on function public.price_items(jsonb, text, text) from public, anon, authenticated;

-- Totals preview for the checkout page. Uses the same pricing code as placing the order.
create or replace function public.quote_order(p_items jsonb, p_coupon text, p_district text)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  return public.price_items(p_items, p_coupon, p_district);
end $$;
revoke execute on function public.quote_order(jsonb, text, text) from public, anon;
grant execute on function public.quote_order(jsonb, text, text) to authenticated;

-- ---------- order status machine ----------
create or replace function public._order_transition_allowed(p_from public.order_status, p_to public.order_status)
returns boolean language sql immutable as $$
  select case p_from
    when 'pending'              then p_to in ('confirmed','cancelled')
    when 'confirmed'            then p_to in ('customization_review','production','cancelled')
    when 'customization_review' then p_to in ('confirmed','production','cancelled')
    when 'production'           then p_to in ('ready_to_ship','cancelled')
    when 'ready_to_ship'        then p_to in ('shipped','cancelled')
    when 'shipped'              then p_to in ('delivered')
    when 'delivered'            then p_to in ('refunded')
    else false end
$$;

create or replace function public._apply_order_status(p_order_id uuid, p_to public.order_status, p_actor uuid, p_note text)
returns void language plpgsql security definer set search_path = '' as $$
declare o record; it record; v_label text;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if not public._order_transition_allowed(o.status, p_to) then
    raise exception 'BAD_TRANSITION:% to %', o.status, p_to;
  end if;

  if p_to = 'cancelled' then
    for it in
      select oi.product_id, oi.variant_id, oi.quantity, p.track_stock
      from public.order_items oi left join public.products p on p.id = oi.product_id
      where oi.order_id = o.id
    loop
      if it.product_id is not null and it.track_stock then
        if it.variant_id is not null then
          update public.product_variants set stock_qty = stock_qty + it.quantity where id = it.variant_id;
        else
          update public.products set stock_qty = stock_qty + it.quantity where id = it.product_id;
        end if;
      end if;
    end loop;
    if o.coupon_code is not null then
      update public.coupons set used_count = greatest(used_count - 1, 0) where code = o.coupon_code;
    end if;
  end if;

  update public.orders set
    status = p_to,
    payment_status = case
      when p_to = 'delivered' and o.payment_method = 'cod' then 'paid'   -- cash is collected on delivery
      when p_to = 'refunded' and o.payment_status = 'paid' then 'refunded'
      else o.payment_status end
  where id = o.id;

  if p_to = 'delivered' and o.payment_method = 'cod' then
    insert into public.payments (order_id, provider, amount_bdt, status) values (o.id, 'cod', o.total_bdt, 'succeeded');
  end if;
  if p_to = 'refunded' and o.payment_status = 'paid' then
    insert into public.payments (order_id, provider, amount_bdt, status)
    values (o.id, case when o.payment_method = 'cod' then 'cod' else 'manual' end, o.total_bdt, 'refunded');
  end if;
  if p_to = 'shipped' then
    update public.shipments set shipped_at = coalesce(shipped_at, now()) where order_id = o.id;
  elsif p_to = 'delivered' then
    update public.shipments set delivered_at = coalesce(delivered_at, now()) where order_id = o.id;
  end if;

  insert into public.order_events (order_id, actor_id, from_status, to_status, note)
  values (o.id, p_actor, o.status, p_to, nullif(btrim(coalesce(p_note, '')), ''));

  v_label := initcap(replace(p_to::text, '_', ' '));
  insert into public.notifications (user_id, audience, title, body, link)
  values (o.user_id, 'user', 'Order ' || o.order_number || ': ' || v_label,
          'Your order status changed to ' || v_label || '.', '/account/orders/' || o.id);
  insert into public.audit_logs (actor_id, action, entity, entity_id, details)
  values (p_actor, 'order.status', 'order', o.id::text,
          jsonb_build_object('from', o.status, 'to', p_to, 'order_number', o.order_number));
end $$;
revoke execute on function public._apply_order_status(uuid, public.order_status, uuid, text) from public, anon, authenticated;

create or replace function public.set_order_status(p_order_id uuid, p_to public.order_status, p_note text default null)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_staff() then raise exception 'FORBIDDEN'; end if;
  perform public._apply_order_status(p_order_id, p_to, auth.uid(), p_note);
end $$;
revoke execute on function public.set_order_status(uuid, public.order_status, text) from public, anon;
grant execute on function public.set_order_status(uuid, public.order_status, text) to authenticated;

create or replace function public.cancel_my_order(p_order_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_status public.order_status;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select status into v_status from public.orders where id = p_order_id and user_id = auth.uid();
  if not found then raise exception 'ORDER_NOT_FOUND'; end if;
  if v_status <> 'pending' then raise exception 'CANCEL_NOT_ALLOWED'; end if;
  perform public._apply_order_status(p_order_id, 'cancelled', auth.uid(), 'Cancelled by customer');
end $$;
revoke execute on function public.cancel_my_order(uuid) from public, anon;
grant execute on function public.cancel_my_order(uuid) to authenticated;

-- ---------- place order ----------
create or replace function public.place_order(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_key text := p_payload->>'idempotency_key';
  v_addr jsonb := p_payload->'address';
  v_method text := coalesce(p_payload->>'payment_method', 'cod');
  v_priced jsonb; v_order public.orders; v_line record; v_item_id uuid; v_custom jsonb;
  v_has_custom boolean := false; v_updated int;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if v_key is null or char_length(v_key) < 8 or char_length(v_key) > 100 then raise exception 'BAD_IDEMPOTENCY_KEY'; end if;

  -- Same key from the same customer returns the original order instead of creating a duplicate.
  select * into v_order from public.orders where user_id = v_uid and idempotency_key = v_key;
  if found then
    return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number,
                              'total', v_order.total_bdt, 'duplicate', true);
  end if;

  -- Only Cash on Delivery is accepted until a payment gateway is configured and verified server-side.
  if v_method <> 'cod' then raise exception 'PAYMENT_METHOD_UNAVAILABLE'; end if;

  if v_addr is null or jsonb_typeof(v_addr) <> 'object'
     or coalesce(btrim(v_addr->>'recipient_name'), '') = '' or coalesce(btrim(v_addr->>'phone'), '') = ''
     or coalesce(btrim(v_addr->>'line1'), '') = '' or coalesce(btrim(v_addr->>'city'), '') = ''
     or coalesce(btrim(v_addr->>'district'), '') = '' then
    raise exception 'ADDRESS_INCOMPLETE';
  end if;
  if char_length(v_addr::text) > 1500 then raise exception 'ADDRESS_INCOMPLETE'; end if;
  if coalesce(btrim(p_payload->>'customer_name'), '') = '' or coalesce(btrim(p_payload->>'customer_phone'), '') = '' then
    raise exception 'CONTACT_INCOMPLETE';
  end if;

  -- Lock the products involved in a stable order so concurrent checkouts serialise instead of overselling.
  perform 1 from public.products
    where id in (select (e->>'product_id')::uuid from jsonb_array_elements(p_payload->'items') e)
    order by id for update;

  v_priced := public.price_items(p_payload->'items', p_payload->>'coupon_code', v_addr->>'district');

  -- Customer-uploaded logos must live in the customer's own folder.
  for v_line in select value as l from jsonb_array_elements(v_priced->'lines') loop
    if coalesce(v_line.l->'customization'->>'logo_path', '') <> ''
       and (v_line.l->'customization'->>'logo_path') not like v_uid::text || '/%' then
      raise exception 'BAD_LOGO_PATH';
    end if;
  end loop;

  begin
    insert into public.orders (user_id, idempotency_key, payment_method, subtotal_bdt, discount_bdt, shipping_bdt,
                               total_bdt, coupon_code, customer_name, customer_phone, customer_email,
                               shipping_address, notes)
    values (v_uid, v_key, v_method, (v_priced->>'subtotal')::numeric, (v_priced->>'discount')::numeric,
            (v_priced->>'shipping')::numeric, (v_priced->>'total')::numeric, v_priced->>'coupon_code',
            left(btrim(p_payload->>'customer_name'), 120), left(btrim(p_payload->>'customer_phone'), 20),
            nullif(left(btrim(coalesce(p_payload->>'customer_email', '')), 200), ''),
            v_addr, nullif(left(btrim(coalesce(p_payload->>'notes', '')), 1000), ''))
    returning * into v_order;
  exception when unique_violation then
    select * into v_order from public.orders where user_id = v_uid and idempotency_key = v_key;
    if found then
      return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number,
                                'total', v_order.total_bdt, 'duplicate', true);
    end if;
    raise;
  end;

  -- Lines are processed in a fixed order to avoid deadlocks between concurrent orders.
  for v_line in
    select value as l from jsonb_array_elements(v_priced->'lines')
    order by value->>'product_id', coalesce(value->>'variant_id', '')
  loop
    if (v_line.l->>'track_stock')::boolean then
      if v_line.l->>'variant_id' is not null then
        update public.product_variants set stock_qty = stock_qty - (v_line.l->>'qty')::int
          where id = (v_line.l->>'variant_id')::uuid and stock_qty >= (v_line.l->>'qty')::int;
      else
        update public.products set stock_qty = stock_qty - (v_line.l->>'qty')::int
          where id = (v_line.l->>'product_id')::uuid and stock_qty >= (v_line.l->>'qty')::int;
      end if;
      get diagnostics v_updated = row_count;
      if v_updated = 0 then raise exception 'OUT_OF_STOCK:%', v_line.l->>'name'; end if;
    end if;

    v_custom := v_line.l->'customization';
    insert into public.order_items (order_id, product_id, variant_id, product_name, variant_name, sku,
                                    unit_price_bdt, quantity, line_total_bdt, customization)
    values (v_order.id, (v_line.l->>'product_id')::uuid, (v_line.l->>'variant_id')::uuid, v_line.l->>'name',
            v_line.l->>'variant_name', v_line.l->>'sku', (v_line.l->>'unit_price')::numeric,
            (v_line.l->>'qty')::int, (v_line.l->>'line_total')::numeric, v_custom)
    returning id into v_item_id;

    if v_custom is not null then
      insert into public.custom_designs (order_item_id, data, logo_path)
      values (v_item_id, coalesce(v_custom->'lines', '{}'::jsonb), nullif(v_custom->>'logo_path', ''));
      v_has_custom := true;
    end if;
  end loop;

  if v_priced->>'coupon_code' is not null then
    update public.coupons set used_count = used_count + 1
      where code = v_priced->>'coupon_code' and (max_uses is null or used_count < max_uses);
    get diagnostics v_updated = row_count;
    if v_updated = 0 then raise exception 'COUPON_INVALID'; end if;
  end if;

  insert into public.shipments (order_id) values (v_order.id);
  insert into public.order_events (order_id, actor_id, from_status, to_status, note)
  values (v_order.id, v_uid, null, 'pending', 'Order placed');
  insert into public.notifications (user_id, audience, title, body, link)
  values (v_uid, 'user', 'Order ' || v_order.order_number || ' received',
          'We have received your order and will confirm it shortly.', '/account/orders/' || v_order.id);
  insert into public.notifications (audience, title, body, link)
  values ('staff', 'New order ' || v_order.order_number,
          case when v_has_custom then 'Includes custom designs to review.' else 'Awaiting confirmation.' end,
          '/admin/orders/' || v_order.id);

  return jsonb_build_object('order_id', v_order.id, 'order_number', v_order.order_number,
                            'total', v_order.total_bdt, 'duplicate', false);
end $$;
revoke execute on function public.place_order(jsonb) from public, anon;
grant execute on function public.place_order(jsonb) to authenticated;
