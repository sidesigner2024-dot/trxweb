-- 0003_storage.sql : buckets and storage access policies.
-- Public buckets serve catalogue media. Private buckets are only reachable through these policies
-- (or short-lived signed URLs created server-side).

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('product-images',    'product-images',    true,  5242880,  array['image/jpeg','image/png','image/webp','image/avif']),
  ('product-models',    'product-models',    true,  26214400, array['model/gltf-binary','application/octet-stream']),
  ('banners',           'banners',           true,  5242880,  array['image/jpeg','image/png','image/webp','image/avif']),
  ('customer-artwork',  'customer-artwork',  false, 10485760, array['image/jpeg','image/png','image/webp','application/pdf']),
  ('order-attachments', 'order-attachments', false, 10485760, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Public catalogue media: anyone may read, only staff may write.
create policy "catalogue media read" on storage.objects for select
  using (bucket_id in ('product-images','product-models','banners'));
create policy "catalogue media staff insert" on storage.objects for insert to authenticated
  with check (bucket_id in ('product-images','product-models','banners') and public.is_staff());
create policy "catalogue media staff update" on storage.objects for update to authenticated
  using (bucket_id in ('product-images','product-models','banners') and public.is_staff());
create policy "catalogue media staff delete" on storage.objects for delete to authenticated
  using (bucket_id in ('product-images','product-models','banners') and public.is_staff());

-- Customer artwork: objects live under "<user_id>/..." and are private to that user and staff.
create policy "artwork owner insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'customer-artwork' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "artwork owner or staff read" on storage.objects for select to authenticated
  using (bucket_id = 'customer-artwork' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_staff()));
create policy "artwork owner delete" on storage.objects for delete to authenticated
  using (bucket_id = 'customer-artwork' and (storage.foldername(name))[1] = auth.uid()::text);

-- Order attachments (proofs, invoices): objects live under "<order_id>/...".
-- Staff write; the customer who owns the order can read.
create policy "attachments staff write" on storage.objects for insert to authenticated
  with check (bucket_id = 'order-attachments' and public.is_staff());
create policy "attachments staff update" on storage.objects for update to authenticated
  using (bucket_id = 'order-attachments' and public.is_staff());
create policy "attachments staff delete" on storage.objects for delete to authenticated
  using (bucket_id = 'order-attachments' and public.is_staff());
create policy "attachments owner or staff read" on storage.objects for select to authenticated
  using (bucket_id = 'order-attachments' and (
    public.is_staff() or exists (
      select 1 from public.orders o
      where o.id::text = (storage.foldername(name))[1] and o.user_id = auth.uid())));
