-- 0001_schema.sql : core tables, constraints, indexes, triggers.
-- Run migrations in numeric order (see README "Database setup").

create type public.order_status as enum (
  'pending','confirmed','customization_review','production',
  'ready_to_ship','shipped','delivered','cancelled','refunded'
);

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- roles & profiles ----------
create table public.roles (
  name text primary key,
  description text not null
);
insert into public.roles (name, description) values
  ('customer','Shopper account'),
  ('staff','Manages catalogue, orders, messages and showroom'),
  ('admin','Full access including staff roles, coupons, settings and audit logs');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '' check (char_length(full_name) <= 120),
  phone text check (phone is null or char_length(phone) between 6 and 20),
  role text not null default 'customer' references public.roles(name),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'full_name', ''), 120));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  label text check (label is null or char_length(label) <= 40),
  recipient_name text not null check (char_length(recipient_name) between 1 and 120),
  phone text not null check (char_length(phone) between 6 and 20),
  line1 text not null check (char_length(line1) between 1 and 200),
  line2 text check (line2 is null or char_length(line2) <= 200),
  city text not null check (char_length(city) between 1 and 80),
  district text not null check (char_length(district) between 1 and 80),
  postal_code text check (postal_code is null or char_length(postal_code) <= 12),
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);
create index addresses_user_idx on public.addresses (user_id);

-- ---------- catalogue ----------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  name text not null check (char_length(name) between 1 and 80),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text,
  image_url text,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index categories_parent_idx on public.categories (parent_id);
create trigger categories_updated before update on public.categories
  for each row execute function public.set_updated_at();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique check (char_length(sku) between 1 and 60),
  name text not null check (char_length(name) between 1 and 160),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text not null default '',
  category_id uuid references public.categories(id) on delete set null,
  subcategory_id uuid references public.categories(id) on delete set null,
  price_bdt numeric(12,2) not null check (price_bdt >= 0),
  discount_price_bdt numeric(12,2),
  material text,
  dimensions text,
  weight_grams int check (weight_grams is null or weight_grams >= 0),
  stock_qty int not null default 0 check (stock_qty >= 0),
  track_stock boolean not null default true,        -- false = made to order, no stock limit
  production_days int check (production_days is null or production_days >= 0),
  is_customizable boolean not null default false,
  allows_logo boolean not null default false,
  is_featured boolean not null default false,
  is_active boolean not null default true,
  is_sample boolean not null default false,          -- true = development sample content, labelled in the UI
  seo_title text check (seo_title is null or char_length(seo_title) <= 70),
  seo_description text check (seo_description is null or char_length(seo_description) <= 200),
  search_vector tsvector generated always as (
    to_tsvector('simple', coalesce(name,'') || ' ' || coalesce(sku,'') || ' ' || coalesce(material,'') || ' ' || coalesce(description,''))
  ) stored,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint discount_below_price check (discount_price_bdt is null or (discount_price_bdt >= 0 and discount_price_bdt < price_bdt))
);
create index products_category_idx on public.products (category_id);
create index products_active_featured_idx on public.products (is_active, is_featured);
create index products_search_idx on public.products using gin (search_vector);
create trigger products_updated before update on public.products
  for each row execute function public.set_updated_at();

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  storage_path text not null,                         -- path inside the product-images bucket
  alt_text text not null default '' check (char_length(alt_text) <= 200),
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index product_images_product_idx on public.product_images (product_id, sort_order);

create table public.product_models (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null unique references public.products(id) on delete cascade,
  storage_path text not null,                         -- .glb path inside the product-models bucket
  file_size_bytes bigint check (file_size_bytes is null or file_size_bytes > 0),
  scale numeric(8,4) not null default 1 check (scale > 0),
  created_at timestamptz not null default now()
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  sku text unique,
  price_delta_bdt numeric(12,2) not null default 0,
  stock_qty int not null default 0 check (stock_qty >= 0),
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index product_variants_product_idx on public.product_variants (product_id);

create table public.customization_options (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  field_key text not null check (field_key ~ '^[a-z][a-z0-9_]{0,30}$'),
  label text not null check (char_length(label) between 1 and 80),
  field_type text not null check (field_type in ('text','date','message','font','color')),
  max_length int not null default 60 check (max_length between 1 and 500),
  is_required boolean not null default false,
  choices jsonb,                                       -- allowed values for font/color types
  sort_order int not null default 0,
  unique (product_id, field_key)
);

-- ---------- cart & wishlist ----------
create table public.carts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  updated_at timestamptz not null default now()
);
create table public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references public.carts(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete cascade,
  quantity int not null check (quantity between 1 and 99),
  customization jsonb check (customization is null or char_length(customization::text) <= 4000)
);
create index cart_items_cart_idx on public.cart_items (cart_id);

create table public.wishlists (
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

-- ---------- commerce settings ----------
create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code = upper(code) and code ~ '^[A-Z0-9_-]{3,32}$'),
  type text not null check (type in ('percent','fixed')),
  value numeric(12,2) not null check (value > 0),
  min_subtotal_bdt numeric(12,2) not null default 0 check (min_subtotal_bdt >= 0),
  max_uses int check (max_uses is null or max_uses > 0),
  used_count int not null default 0 check (used_count >= 0),
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint percent_range check (type <> 'percent' or value <= 100)
);

create table public.shipping_zones (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  districts text[] not null default '{}',
  fee_bdt numeric(12,2) not null check (fee_bdt >= 0),
  free_over_bdt numeric(12,2) check (free_over_bdt is null or free_over_bdt > 0),
  is_default boolean not null default false,
  is_active boolean not null default true
);
create unique index shipping_zones_one_default on public.shipping_zones (is_default) where is_default;

-- ---------- orders ----------
create sequence public.order_number_seq start 1001;

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('AW-' || nextval('public.order_number_seq')),
  user_id uuid not null references public.profiles(id) on delete restrict,
  idempotency_key text not null check (char_length(idempotency_key) between 8 and 100),
  status public.order_status not null default 'pending',
  payment_method text not null check (payment_method in ('cod','online')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','paid','failed','refunded')),
  subtotal_bdt numeric(12,2) not null check (subtotal_bdt >= 0),
  discount_bdt numeric(12,2) not null default 0 check (discount_bdt >= 0),
  shipping_bdt numeric(12,2) not null default 0 check (shipping_bdt >= 0),
  total_bdt numeric(12,2) not null check (total_bdt >= 0),
  coupon_code text,
  customer_name text not null,
  customer_phone text not null,
  customer_email text,
  shipping_address jsonb not null,                    -- snapshot at order time
  notes text check (notes is null or char_length(notes) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
create index orders_user_idx on public.orders (user_id, created_at desc);
create index orders_status_idx on public.orders (status, created_at desc);
create trigger orders_updated before update on public.orders
  for each row execute function public.set_updated_at();

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  product_name text not null,
  variant_name text,
  sku text not null,
  unit_price_bdt numeric(12,2) not null check (unit_price_bdt >= 0),
  quantity int not null check (quantity between 1 and 99),
  line_total_bdt numeric(12,2) not null check (line_total_bdt >= 0),
  customization jsonb check (customization is null or char_length(customization::text) <= 4000)
);
create index order_items_order_idx on public.order_items (order_id);

create table public.order_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  from_status public.order_status,
  to_status public.order_status not null,
  note text check (note is null or char_length(note) <= 1000),
  created_at timestamptz not null default now()
);
create index order_events_order_idx on public.order_events (order_id, created_at);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  provider text not null,                              -- 'cod' or a configured gateway name
  provider_ref text,
  amount_bdt numeric(12,2) not null check (amount_bdt >= 0),
  status text not null check (status in ('pending','succeeded','failed','refunded')),
  raw jsonb,                                           -- gateway payload; never exposed to customers
  created_at timestamptz not null default now()
);
create index payments_order_idx on public.payments (order_id);

create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  carrier text check (carrier is null or char_length(carrier) <= 80),
  tracking_number text check (tracking_number is null or char_length(tracking_number) <= 80),
  tracking_url text check (tracking_url is null or tracking_url ~ '^https?://'),
  note text check (note is null or char_length(note) <= 500),
  shipped_at timestamptz,
  delivered_at timestamptz,
  updated_at timestamptz not null default now()
);
create trigger shipments_updated before update on public.shipments
  for each row execute function public.set_updated_at();

create table public.custom_designs (
  id uuid primary key default gen_random_uuid(),
  order_item_id uuid not null unique references public.order_items(id) on delete cascade,
  data jsonb not null check (char_length(data::text) <= 4000),
  logo_path text,                                      -- private customer-artwork bucket path
  status text not null default 'pending' check (status in ('pending','approved','revision_requested')),
  admin_note text check (admin_note is null or char_length(admin_note) <= 1000),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index custom_designs_status_idx on public.custom_designs (status);
create trigger custom_designs_updated before update on public.custom_designs
  for each row execute function public.set_updated_at();

-- ---------- engagement ----------
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  title text check (title is null or char_length(title) <= 120),
  body text check (body is null or char_length(body) <= 2000),
  is_approved boolean not null default false,
  created_at timestamptz not null default now(),
  unique (product_id, user_id)
);
create index reviews_product_idx on public.reviews (product_id) where is_approved;

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,  -- null when audience = 'staff'
  audience text not null default 'user' check (audience in ('user','staff')),
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now(),
  constraint audience_target check ((audience = 'user' and user_id is not null) or (audience = 'staff' and user_id is null))
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);
create index notifications_staff_idx on public.notifications (created_at desc) where audience = 'staff';

create table public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  email text check (email is null or char_length(email) <= 200),
  phone text check (phone is null or char_length(phone) <= 20),
  subject text check (subject is null or char_length(subject) <= 160),
  message text not null check (char_length(message) between 1 and 4000),
  status text not null default 'new' check (status in ('new','read','replied')),
  created_at timestamptz not null default now(),
  constraint contact_has_channel check (email is not null or phone is not null)
);

-- ---------- showroom & site content ----------
create table public.showroom_rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text,
  category_id uuid references public.categories(id) on delete set null,
  sort_order int not null default 0,
  is_active boolean not null default true
);

create table public.showroom_displays (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.showroom_rooms(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  display_type text not null default 'pedestal' check (display_type in ('pedestal','cabinet','wall','shelf')),
  pos_x numeric(8,3) not null default 0,
  pos_y numeric(8,3) not null default 0,
  pos_z numeric(8,3) not null default 0,
  rotation_y numeric(8,3) not null default 0,
  scale numeric(8,3) not null default 1 check (scale > 0),
  sort_order int not null default 0,
  is_active boolean not null default true
);
create index showroom_displays_room_idx on public.showroom_displays (room_id);
create index showroom_displays_product_idx on public.showroom_displays (product_id);

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  subtitle text check (subtitle is null or char_length(subtitle) <= 240),
  image_path text,                                     -- path inside the banners bucket
  link_url text check (link_url is null or link_url ~ '^(/|https?://)'),
  sort_order int not null default 0,
  is_active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.site_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
create trigger site_settings_updated before update on public.site_settings
  for each row execute function public.set_updated_at();

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs (created_at desc);
create index audit_logs_entity_idx on public.audit_logs (entity, entity_id);
