-- 0005_seed_reference.sql : reference data every installation needs (not sample products).
-- Categories are the twelve required store categories; all are editable from the admin dashboard.

insert into public.categories (name, slug, sort_order) values
  ('Luxury Trophies','luxury-trophies',1),
  ('Sports Cups','sports-cups',2),
  ('Wooden Crests','wooden-crests',3),
  ('Recognition Plaques','recognition-plaques',4),
  ('Crystal Awards','crystal-awards',5),
  ('Glass Awards','glass-awards',6),
  ('Medals','medals',7),
  ('Corporate Gifts','corporate-gifts',8),
  ('Personalized Gifts','personalized-gifts',9),
  ('Memorial Gifts','memorial-gifts',10),
  ('Badges and Shields','badges-and-shields',11),
  ('Custom Awards','custom-awards',12)
on conflict (slug) do nothing;

-- Site settings start empty on purpose: contact details, social links and the brand name are
-- business facts only the owner can supply. Edit them in Admin > Settings.
insert into public.site_settings (key, value) values
  ('general', '{"site_name": "Aurelia Awards", "tagline": ""}'),
  ('contact', '{"phone": "", "email": "", "whatsapp": "", "address": ""}'),
  ('social',  '{"facebook": "", "instagram": "", "youtube": ""}')
on conflict (key) do nothing;

-- Shipping zones are deliberately NOT seeded. Checkout stays closed ("shipping not configured")
-- until the owner adds at least one default zone in Admin > Shipping.
