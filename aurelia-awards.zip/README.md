# Aurelia Awards — 3D showroom & e-commerce

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind 4 · React Three Fiber · Supabase (Postgres, Auth, Storage) · Zod · React Hook Form. Prices in BDT, Cash on Delivery.

> Replace "Aurelia Awards" with your real brand: it appears in `src/app/layout.tsx`, the header/footer, and the settings table (Admin → Settings).

## What works / what does not (read this first)

**Implemented and tested here**
- Database schema, constraints, RLS, storage policies, atomic order placement (server-side pricing, stock locking, coupons, idempotency, status machine). **56 automated tests** run the real migrations against an in-process Postgres (`npm test`).
- Shop, search/filter/sort/pagination, product pages (JSON-LD), cart, checkout (COD), accounts, wishlist, order history, guest + account order tracking, contact form, reviews, static pages.
- 3D showroom (rendered and checked in headless Chromium on desktop and phone-size viewports), customisation studio, admin dashboard, CSV export, audit log.

**Not implemented / needs you**
- **Online payment**: not built. Checkout accepts Cash on Delivery only and the database *rejects* any other method. A gateway (e.g. SSLCommerz, bKash) needs your merchant credentials plus a server-verified callback; add it as a new migration + route, never trust a browser redirect.
- **Email notifications**: not built. In-app notifications work. `RESEND_API_KEY` in `.env.example` is a placeholder only.
- **Not tested against a live Supabase project, a real Android device, or Vercel** (no access from the build environment). The SQL is tested on Postgres (PGlite); Supabase-specific pieces (Auth emails, Storage API, PostgREST embedding) are written to the documented APIs but need your smoke test (see *Manual test checklist*).
- **Rate limiting** is in-memory per serverless instance (slows bursts, not a hard guarantee). Add Vercel WAF rate limits or Upstash for real protection.
- **Showroom placement** in admin is numeric (coordinates), not drag-and-drop.
- **GLB loading** uses drei's `useGLTF`; compressed (Draco/meshopt) models fetch decoders from a public CDN. Prefer uncompressed, lightweight GLBs or self-host decoders.
- Legal pages (Privacy, Terms, Returns) are **drafts** marked as such. Have them reviewed. The About page and contact details are empty until you fill them in Admin → Settings.
- Shipping fees are **not pre-filled**: checkout stays closed until you add a default zone.
- Cloudinary is not used (Supabase Storage + Next image optimisation cover it).

## Setup

```bash
npm install
cp .env.example .env.local   # fill in values; never commit it
npm run dev
```

### 1. Supabase project
Create a project at supabase.com. Copy the Project URL, `anon` key and `service_role` key into `.env.local`.
`SUPABASE_SERVICE_ROLE_KEY` is used only in server code (order tracking and contact form) and must never get a `NEXT_PUBLIC_` prefix.

### 2. Run the migrations (in order)
Supabase Dashboard → SQL Editor → run each file from `supabase/migrations/`:
1. `0001_schema.sql` tables, constraints, indexes
2. `0002_rls.sql` roles, guards, Row Level Security
3. `0003_storage.sql` buckets and storage policies
4. `0004_orders.sql` pricing, `place_order`, status machine
5. `0005_seed_reference.sql` the 12 categories and empty settings

(Or with the Supabase CLI: `supabase link` then `supabase db push`.)
Optional: `supabase/sample_data.sql` adds 3 products flagged **Sample**; delete with `delete from products where is_sample;`.

### 3. Auth settings
Authentication → URL Configuration: set Site URL to your domain and add `https://YOUR-DOMAIN/auth/callback` (and `http://localhost:3000/auth/callback`) to Redirect URLs. Configure an SMTP provider for production auth emails (Supabase's built-in sender is rate-limited).

### 4. Make the first admin
Register on the site, then in the SQL editor:
```sql
update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
```
Further staff/admins are managed in Admin → Customers & staff. Roles can only be changed by admins (database trigger enforces this).

### 5. Business setup (Admin)
Shipping (at least one default zone), Settings (contact, WhatsApp, about), Showroom (create a room, place products), Banners, Products (photos, optional GLB).

### Storage buckets (created by migration 0003)
| Bucket | Access | Limit |
|---|---|---|
| product-images, banners | public read, staff write | 5 MB, jpg/png/webp/avif |
| product-models | public read, staff write | 25 MB, .glb |
| customer-artwork | **private**: owner + staff only | 10 MB, jpg/png/webp/pdf |
| order-attachments | **private**: staff write, owning customer read | 10 MB |

Uploads are also checked server-side by extension **and file signature**.

## Deploy to Vercel
1. Push to GitHub, import the repo in Vercel (framework: Next.js).
2. Add the environment variables from `.env.example` (Production + Preview).
3. Deploy. Set `NEXT_PUBLIC_SITE_URL` to the final URL, then redeploy.
4. **Domain**: Vercel → Settings → Domains → add your domain, create the DNS record Vercel shows (A/CNAME) at your registrar, wait for the certificate. Update Supabase Site URL and redirect URLs.
5. Run the manual checklist below on the live site.

## Backup & maintenance
- Supabase paid plans include daily backups; on free plans schedule `pg_dump` (Dashboard → Database → connection string) weekly and store it off-site.
- Storage files are **not** in database dumps: copy the buckets periodically.
- Review Admin → Audit log for unexpected actions; rotate the service-role key if it is ever exposed.
- Keep dependencies current: `npm audit`, `npm outdated`, and re-run `npm test` after upgrades.

## Tests
```bash
npm run typecheck && npm run lint && npm test
```
`tests/db` covers RLS, storage policies, order placement, overselling, coupons, customization rules, status transitions, cancellation/stock return, reviews and admin permissions. `src/lib/*.test.ts` covers validation, upload sniffing, rate limiting, CSV safety and error mapping.

## Manual test checklist (live Supabase)
1. Register → confirm email → sign in → sign out → reset password.
2. As admin: create a product, upload 2 photos and a small `.glb`, add a variant and personalisation fields.
3. Showroom: create a room, place the product (cabinet), open `/showroom` on desktop and an Android phone: drag to look, walk (keys / on-screen pad / tap floor), tap the ring, open the panel, "View details".
4. Product without a GLB shows "Photo preview · no 3D model yet".
5. Customisation studio: fill fields, upload a logo, add to cart, check the preview note.
6. Checkout as a customer (add a shipping zone first): coupon, totals match, place order, refresh/double-click does not duplicate it.
7. Admin: order appears + alert, review the design (request changes → customer sees note), move status through to Delivered (COD payment recorded), add tracking.
8. Guest tracking at `/track` with order number + phone.
9. As a customer, try `/admin` (redirects) and another customer's order URL (404).
10. Cancel a Pending order: stock is returned.
11. Export CSV from Admin → Reports; open in Excel (Bangla text readable).
12. Lighthouse on `/products` and `/showroom` (mobile).
